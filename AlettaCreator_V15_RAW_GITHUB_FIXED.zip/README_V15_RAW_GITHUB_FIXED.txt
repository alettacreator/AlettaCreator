ALETTA CREATOR V15 - RAW GITHUB FIXED

1. Upload Aletta_Creator_V15_RAW_GITHUB_DIAGNOSTIC.lua to a GitHub repository.
2. Open the file on GitHub and click Raw.
3. Use: loadstring(game:HttpGet("RAW_URL"))()
4. API is already set to https://alettacreatorapi.vercel.app

This build keeps the V14 source embedded unchanged and executes it only after API key verification.
It also wraps V14 execution with xpcall so the actual V14 traceback is visible instead of silent random callback errors.
