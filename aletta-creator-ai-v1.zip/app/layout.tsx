import "./globals.css";
import { Sidebar } from "@/components/layout/Sidebar";

export const metadata = {
  title: "Aletta Creator AI",
  description: "AI development workspace for Aletta Creator"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-[#0e0a16]">
      <Sidebar />
      <main className="min-h-screen md:ml-64">{children}</main>
    </div>
  );
}
