"use client";

import { useState } from "react";
import { CodeEditor } from "@/components/editor/CodeEditor";
import { Button } from "@/components/ui/Button";

const template = `-- Aletta Creator generated template
local Feature = {}

Feature.Enabled = false

function Feature:Enable()
    self.Enabled = true
    print("Feature enabled")
end

function Feature:Disable()
    self.Enabled = false
    print("Feature disabled")
end

return Feature
`;

export default function Generator() {
  const [name, setName] = useState("AlettaFeature");
  const [category, setCategory] = useState("General");
  const [description, setDescription] = useState("");
  const [code, setCode] = useState(template);

  async function generate() {
    const res = await fetch("/api/generate", {
      method: "POST", headers: {"Content-Type":"application/json"},
      body: JSON.stringify({ name, category, description })
    });
    const data = await res.json();
    setCode(data.code || "");
  }

  return <div className="p-5 md:p-8"><div className="mx-auto max-w-6xl">
    <h1 className="text-3xl font-black">Code Generator</h1>
    <p className="mb-6 mt-2 text-[#aaa3b5]">Generate struktur Luau untuk project Aletta Creator.</p>
    <div className="grid gap-5 lg:grid-cols-[360px_1fr]">
      <div className="rounded-2xl border border-white/10 bg-[#14101e] p-5 space-y-4">
        <label className="block text-sm">Feature Name<input value={name} onChange={e=>setName(e.target.value)} className="mt-2 w-full rounded-xl bg-[#261e36] p-3 outline-none"/></label>
        <label className="block text-sm">Category<select value={category} onChange={e=>setCategory(e.target.value)} className="mt-2 w-full rounded-xl bg-[#261e36] p-3 outline-none"><option>General</option><option>Survivor</option><option>Killer</option><option>ESP</option><option>Animation</option><option>Settings</option></select></label>
        <label className="block text-sm">Description<textarea value={description} onChange={e=>setDescription(e.target.value)} placeholder="Jelaskan kebutuhan..." className="mt-2 min-h-32 w-full rounded-xl bg-[#261e36] p-3 outline-none"/></label>
        <Button onClick={generate} className="w-full">✦ Generate</Button>
      </div>
      <CodeEditor value={code} onChange={setCode}/>
    </div>
  </div></div>;
}
