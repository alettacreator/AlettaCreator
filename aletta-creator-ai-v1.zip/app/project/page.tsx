"use client";

import { useEffect, useState } from "react";
import { Button } from "@/components/ui/Button";

type Project = { id:string; name:string; description:string; _count?:{scripts:number} };

export default function Projects() {
  const [projects,setProjects]=useState<Project[]>([]);
  const [name,setName]=useState("");
  const [description,setDescription]=useState("");

  async function load(){const r=await fetch("/api/projects");setProjects(await r.json())}
  useEffect(()=>{load()},[]);

  async function create(){
    if(!name.trim()) return;
    await fetch("/api/projects",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name,description})});
    setName("");setDescription("");load();
  }

  return <div className="p-5 md:p-8"><div className="mx-auto max-w-6xl">
    <h1 className="text-3xl font-black">Projects</h1><p className="mb-6 mt-2 text-[#aaa3b5]">Kelola project pengembangan Aletta Creator.</p>
    <div className="mb-6 grid gap-3 md:grid-cols-[1fr_2fr_auto]"><input value={name} onChange={e=>setName(e.target.value)} placeholder="Project name" className="rounded-xl bg-[#261e36] p-3 outline-none"/><input value={description} onChange={e=>setDescription(e.target.value)} placeholder="Description" className="rounded-xl bg-[#261e36] p-3 outline-none"/><Button onClick={create}>Create</Button></div>
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">{projects.map(p=><div key={p.id} className="rounded-2xl border border-white/10 bg-[#14101e] p-5"><b>{p.name}</b><p className="mt-2 text-sm text-[#aaa3b5]">{p.description||"No description"}</p><div className="mt-4 text-xs text-[#aaa3b5]">{p._count?.scripts ?? 0} scripts</div></div>)}</div>
  </div></div>;
}
