--// ALETTA CREATOR V15 - WEB KEY GATE / RAW GITHUB
--// Basis runtime: Aletta Creator V14 asli.
--// API: https://alettacreatorapi.vercel.app
--// Upload file ini ke GitHub, lalu gunakan URL RAW dengan loadstring.

local Players = game:GetService("Players")
local HttpService = game:GetService("HttpService")
local player = Players.LocalPlayer
if not player then return end
local playerGui = player:WaitForChild("PlayerGui", 15)
if not playerGui then return end

local API_BASE = "https://alettacreatorapi.vercel.app"
local ENV = nil
pcall(function()
    if type(getgenv) == "function" then ENV = getgenv() end
end)
if type(ENV) ~= "table" then ENV = _G end

-- Prevent duplicate V15 execution.
if ENV and ENV.__ALETTA_V15_RUNNING then
    return
end
ENV.__ALETTA_V15_RUNNING = true

local function trim(s)
    return tostring(s or ""):gsub("^%s+", ""):gsub("%s+$", "")
end

local function getRequest()
    local candidates = {}
    local function add(fn)
        if type(fn) == "function" then table.insert(candidates, fn) end
    end
    pcall(function() add(ENV.request) end)
    pcall(function() add(ENV.http_request) end)
    pcall(function() add(ENV.httprequest) end)
    pcall(function() if ENV.syn then add(ENV.syn.request) end end)
    pcall(function() if ENV.http then add(ENV.http.request) end end)
    return candidates[1]
end

local function getHWID()
    local fallback = "RBX-" .. tostring(player.UserId) .. "-" .. tostring(game.PlaceId)
    local ok, svc = pcall(function() return game:GetService("RbxAnalyticsService") end)
    if ok and svc then
        local ok2, id = pcall(function() return svc:GetClientId() end)
        if ok2 and id and tostring(id) ~= "" then return tostring(id) end
    end
    return fallback
end

local function make(className, props, parent)
    local ok, obj = pcall(function() return Instance.new(className) end)
    if not ok or not obj then return nil end
    for k,v in pairs(props or {}) do
        pcall(function() obj[k] = v end)
    end
    if parent then obj.Parent = parent end
    return obj
end

local function corner(obj, radius)
    if not obj then return end
    local c = Instance.new("UICorner")
    c.CornerRadius = UDim.new(0, radius)
    c.Parent = obj
end

local oldGate = playerGui:FindFirstChild("AlettaCreatorV15KeyGate")
if oldGate then oldGate:Destroy() end

local gate = make("ScreenGui", {
    Name="AlettaCreatorV15KeyGate",
    ResetOnSpawn=false,
    IgnoreGuiInset=true,
    DisplayOrder=2147483647,
    ZIndexBehavior=Enum.ZIndexBehavior.Global
}, playerGui)

local backdrop = make("Frame", {
    Size=UDim2.fromScale(1,1),
    BackgroundColor3=Color3.fromRGB(7,4,12),
    BackgroundTransparency=0.08,
    BorderSizePixel=0
}, gate)

local card = make("Frame", {
    Size=UDim2.new(0,420,0,300),
    Position=UDim2.new(0.5,-210,0.5,-150),
    BackgroundColor3=Color3.fromRGB(18,12,28),
    BorderSizePixel=0
}, backdrop)
corner(card,14)

local stroke=make("UIStroke", {Color=Color3.fromRGB(150,80,255),Thickness=2}, card)

make("TextLabel", {
    Size=UDim2.new(1,-32,0,34), Position=UDim2.fromOffset(16,15),
    BackgroundTransparency=1, Text="ALETTA CREATOR V15", Font=Enum.Font.GothamBold,
    TextSize=22, TextColor3=Color3.new(1,1,1), TextXAlignment=Enum.TextXAlignment.Left
}, card)

make("TextLabel", {
    Size=UDim2.new(1,-32,0,24), Position=UDim2.fromOffset(16,49),
    BackgroundTransparency=1, Text="Premium Web Key System", Font=Enum.Font.Gotham,
    TextSize=13, TextColor3=Color3.fromRGB(190,180,205), TextXAlignment=Enum.TextXAlignment.Left
}, card)

local input=make("TextBox", {
    Size=UDim2.new(1,-32,0,44), Position=UDim2.fromOffset(16,84),
    BackgroundColor3=Color3.fromRGB(38,30,54), BorderSizePixel=0,
    PlaceholderText="Masukkan Key...", PlaceholderColor3=Color3.fromRGB(125,115,140),
    Text="", ClearTextOnFocus=false, Font=Enum.Font.GothamMedium, TextSize=13,
    TextColor3=Color3.new(1,1,1)
}, card)
corner(input,8)

local verify=make("TextButton", {
    Size=UDim2.new(1,-32,0,44), Position=UDim2.fromOffset(16,138),
    BackgroundColor3=Color3.fromRGB(150,80,255), BorderSizePixel=0,
    Text="VERIFY KEY", Font=Enum.Font.GothamBold, TextSize=14, TextColor3=Color3.new(1,1,1)
}, card)
corner(verify,8)

local status=make("TextLabel", {
    Size=UDim2.new(1,-32,0,92), Position=UDim2.fromOffset(16,194),
    BackgroundTransparency=1, Text="Masukkan key lalu tekan VERIFY KEY.", Font=Enum.Font.Gotham,
    TextSize=12, TextWrapped=true, TextColor3=Color3.fromRGB(190,180,205),
    TextXAlignment=Enum.TextXAlignment.Left, TextYAlignment=Enum.TextYAlignment.Top
}, card)

local busy=false
local verified=false

local function verifyKey()
    if busy then return end
    local key=trim(input.Text)
    if key=="" then status.Text="Masukkan key terlebih dahulu."; return end

    local req=getRequest()
    if type(req)~="function" then
        status.Text="HTTP request tidak tersedia pada executor.\nGunakan executor yang menyediakan request/http_request."
        return
    end

    busy=true
    verify.Active=false
    verify.Text="CHECKING..."
    status.Text="Menghubungkan ke Aletta API..."

    local body=HttpService:JSONEncode({
        key=key,
        userId=tostring(player.UserId),
        hwid=getHWID()
    })

    local ok,res=pcall(function()
        return req({
            Url=API_BASE.."/api/verify",
            Method="POST",
            Headers={ ["Content-Type"]="application/json" },
            Body=body
        })
    end)

    if not ok or type(res)~="table" then
        status.Text="Request API gagal.\n"..tostring(res or "unknown error")
        verify.Text="VERIFY KEY"; verify.Active=true; busy=false
        return
    end

    local raw=res.Body or res.body or ""
    local jsonOK,data=pcall(function() return HttpService:JSONDecode(raw) end)
    if not jsonOK or type(data)~="table" then
        status.Text="Response API tidak valid.\nHTTP: "..tostring(res.StatusCode or res.status_code or "?")
        verify.Text="VERIFY KEY"; verify.Active=true; busy=false
        return
    end

    if data.success==true then
        verified=true
        ENV.__ALETTA_V15_KEY_VALID=true
        ENV.__ALETTA_V15_KEY_TYPE=tostring(data.type or "UNKNOWN")
        ENV.__ALETTA_V15_KEY_EXPIRES=data.expiresAt
        status.Text="KEY VALID\nType: "..tostring(data.type or "UNKNOWN")
        task.wait(0.35)
        if gate then gate:Destroy() end
    else
        local e=tostring(data.error or "VERIFY_FAILED")
        local map={
            KEY_NOT_FOUND="Key tidak ditemukan.",
            KEY_REVOKED="Key sudah direvoke.",
            KEY_EXPIRED="Key sudah expired.",
            USER_MISMATCH="Key terikat ke UserId lain.",
            HWID_MISMATCH="Key terikat ke perangkat lain.",
            MISSING_FIELDS="Data verifikasi tidak lengkap."
        }
        status.Text=map[e] or ("Verifikasi gagal: "..e)
        verify.Text="VERIFY KEY"; verify.Active=true; busy=false
    end
end

verify.Activated:Connect(verifyKey)
input.FocusLost:Connect(function(enterPressed) if enterPressed then verifyKey() end end)

-- Wait until the key is accepted. V14 is NOT touched before this point.
while gate and gate.Parent and not verified do
    task.wait(0.1)
end
if not verified then
    ENV.__ALETTA_V15_RUNNING=nil
    return
end

-- =========================================================
-- EXACT ALETTA CREATOR V14 RUNTIME
-- =========================================================
-- The V14 source is embedded unchanged below. This isolates the key gate
-- from the V14 runtime and lets loadstring report the real V14 traceback.

local V14_SOURCE = [=[
--// Aletta Creator GUI - Fremium Edition
--// Single LocalScript
--// Dibersihkan dari:
--// 1. FeatureManager:Toggle yang belum ada
--// 2. pemanggilan Hooks"..." yang salah
--// 3. emoji LOCK
--// 4. tombol ^ -> asset gambar Aletta
--// 5. moved global -> local
--// 6. beberapa koneksi/cleanup yang rawan error
--//
--// Catatan:
--// Fitur yang membutuhkan otorisasi server/game-specific tetap menjadi
--// placeholder/test state. Jangan gunakan client untuk bypass validasi server.

local Players = game:GetService("Players")
local UIS = game:GetService("UserInputService")
local TweenService = game:GetService("TweenService")
local SoundService = game:GetService("SoundService")
local ContentProvider = game:GetService("ContentProvider")
local RunService = game:GetService("RunService")
local Lighting = game:GetService("Lighting")
local TeleportService = game:GetService("TeleportService")
local GuiService = game:GetService("GuiService")
local VirtualUser = game:GetService("VirtualUser")

--// SINGLE EXECUTE / KEEP LOADED
--// Jika aktif, execute kedua tidak membuat GUI/fitur baru.
--// Jika toggle dimatikan dari Config, execute ulang tetap diperbolehkan.
local AlettaRuntime = nil
pcall(function()
    if type(getgenv) == "function" then
        AlettaRuntime = getgenv()
    elseif type(shared) == "table" then
        AlettaRuntime = shared
    end
end)

if AlettaRuntime and AlettaRuntime.AlettaCreatorRuntime then
    local runtime = AlettaRuntime.AlettaCreatorRuntime
    local existing = runtime.Gui
    if runtime.SingleExecute ~= false and existing and existing.Parent then
        return
    end
    AlettaRuntime.AlettaCreatorRuntime = nil
end

local player = Players.LocalPlayer
if not player then
    warn("[Aletta] LocalPlayer belum tersedia.")
    return
end

local playerGui = player:WaitForChild("PlayerGui", 15)
if not playerGui then
    warn("[Aletta] PlayerGui tidak ditemukan.")
    return
end

local camera = workspace.CurrentCamera

local ACCENT = Color3.fromRGB(150, 80, 255)
local GRAY = Color3.fromRGB(175, 175, 175)
local OFF = Color3.fromRGB(70, 70, 70)
local BG = Color3.fromRGB(14, 10, 22)
local PANEL = Color3.fromRGB(20, 16, 30)
local FIELD = Color3.fromRGB(38, 30, 54)
local TEXT = Color3.fromRGB(255, 255, 255)

-- Asset gambar tombol buka/tutup GUI.
local BACKGROUND_ID = "rbxassetid://114593611204629"
local LOGO_ID = ""
local HEADER_LOGO_ID = LOGO_ID
local LOAD_SOUND_ID = "rbxassetid://83169454697282"
local ICON_ID = LOGO_ID

-- Hapus GUI lama jika script dijalankan ulang.
for _, name in ipairs({"AlettaCreatorGUI", "AlettaCrosshair", "AlettaESPLabels", "AlettaMWIndicator"}) do
    local old = playerGui:FindFirstChild(name)
    if old then
        old:Destroy()
    end
end

local Values = {}
Values["Auto Sprint Mobile"] = false
Values["ESP Range"] = 600
Values["ESP Distance"] = 600
if Values["Target SCP / Zombie"] == nil then Values["Target SCP / Zombie"] = true end
Values["Parry Radius"] = 13
Values["Safety Parry"] = false
Values["Aggressive Parry"] = false
Values["Auto Parry"] = false
Values["Show FOV Circle"] = true
Values["FOV Radius (pixels)"] = 120
Values["Predict Killer"] = false
Values["Moonwalk Held"] = false
Values["Hold RMB to Aim"] = true
Values["Show FOV Circle"] = true
Values["Pistol Show FOV"] = true
Values["Pistol FOV Radius"] = 120
Values["Veil Show FOV"] = true
Values["Show Mobile Target Shortcut"] = false
Values["Block Aim Knocked"] = true

local Hooks = {}
local Defaults = {}
local Controls = {}
local FeatureConnections = {}

local function disconnectList(name)
    local list = FeatureConnections[name]
    if not list then return end

    for _, connection in ipairs(list) do
        if connection and connection.Disconnect then
            pcall(function()
                connection:Disconnect()
            end)
        end
    end

    FeatureConnections[name] = nil
end

local function addConnection(name, connection)
    if not connection then return nil end
    FeatureConnections[name] = FeatureConnections[name] or {}
    table.insert(FeatureConnections[name], connection)
    return connection
end

local FeatureManager = {}

function FeatureManager:Set(name, enabled)
    enabled = enabled == true
    Values[name] = enabled

    disconnectList(name)

    local hook = Hooks[name]
    if hook then
        task.spawn(function()
            local ok, err = pcall(hook, enabled)
            if not ok then
                warn("[Aletta] " .. tostring(name) .. ": " .. tostring(err))
            end
        end)
    end
end

function FeatureManager:Get(name)
    return Values[name] == true
end

function FeatureManager:Toggle(name)
    self:Set(name, not self:Get(name))
end

function FeatureManager:Stop(name)
    self:Set(name, false)
end

function FeatureManager:Connect(name, signal, callback)
    if signal and signal.Connect then
        return addConnection(name, signal:Connect(callback))
    end
end

function FeatureManager:StopAll()
    local names = {}
    for name in pairs(FeatureConnections) do
        table.insert(names, name)
    end
    for _, name in ipairs(names) do
        disconnectList(name)
    end
end

local function T(label, default)
    return {type = "toggle", label = label, default = default == true}
end

local function I(label, default, placeholder)
    return {
        type = "input",
        label = label,
        default = tostring(default or ""),
        placeholder = placeholder
    }
end

local function D(label, options, default)
    return {type = "dropdown", label = label, options = options, default = default}
end

local function K(label, default)
    return {type = "hotkey", label = label, default = default}
end

local function B(label)
    return {type = "button", label = label}
end

local function L(text, height)
    return {type = "label", label = text, height = height}
end

local function S(label, min, max, default)
    return {type = "slider", label = label, min = min, max = max, default = default}
end

local function C(label, name)
    local d = "Default " .. name
    return D(label, {"Default " .. name, "Red", "Green", "Blue", "Purple", "White", "Yellow", "Orange"}, d)
end

local function TC(label, default)
    return D(label, {"Purple", "Cyan", "Red", "Yellow", "Orange", "Blue", "Green", "White", "Pink"}, default)
end

-- =========================================================
-- CONFIG GUI
-- =========================================================

local CONFIG = {
    {
        name = "Survivor",
        features = {
            {name = "Survivor Controls", controls = {
                L("Semua menu Survivor tersedia di bawah ini. Scroll untuk melihat seluruh fitur.", 42)
            }},
            {name = "Escape & Pallet", controls = {
                B("Auto Escape [ 1x Click ]"),
                B("Drop All Pallets [ 1x Click ]"),
                T("Anti Block Window", true),
                T("Pallet Save Team", true),
                T("Safe Mode", true),
                S("Radius Pallet", 0, 24, 12)
            }},
            {name = "Auto Menu", controls = {
                T("Self Proges Heal"),
                T("Auto Heal Team")
            }},
            {name = "Parry Menu", controls = {
                T("Auto Parry"),
                T("Fake Parry [Keybind R]"),
                T("Safety Parry"),
                T("Aggressive Parry"),
                S("ESP Range", 0, 600, 600),
                S("Parry Radius", 2, 100, 13),
                L("Auto Parry Cooldown  •  120 detik\n   Radius dapat diatur langsung dari slider di atas.", 42),
                S("Face Sensitivity", 0, 11, 5),
                L("Ignore Skills\n   - Hidden S1\n   - Abyssal S1", 58)
            }},
            {name = "Flee Menu", controls = {
                T("Flee Killer"),
                S("Jarak Auto Flee", 0, 120, 60),
                T("Auto Sprint Mobile"),
                T("Anti Fail Gene"),
                D("Teleport Destination", {"Gate", "Generator", "Pallet", "Hook", "Teammate", "Killer"}, "Gate"),
                B("Instant Teleport [ Teleport ke Bagian Yang di Tuju ]"),
                T("Auto Crouch Dodge"),
                T("Auto Bandage"),
                T("Auto Crouch Veil"),
                T("Anti Slow")
            }},
            {name = "Perks Mod", controls = {
                D("Perks Mod", {"Default", "SpeedBoost", "Quick Recovery", "Flowstate", "Perfect Vault"}, "Default"),
                T("SpeedBoost"),
                S("Speed Boost Value", 0, 24, 12)
            }},
            {name = "Vault Mod", controls = {
                T("Perfect Vault"),
                T("Flowstate"),
                S("Flowstate Cooldown", 0, 55, 27),
                T("Quick Recovery"),
                S("Quick Recovery Cooldown", 40, 300, 170)
            }},
            {name = "Skill Generator", controls = {
                T("Bypass Generator"),
                D("Bypass Mode", {"Normal", "Legit", "Perfect", "Instant"}, "Normal")
            }},
            {name = "Camera Menu", controls = {
                T("Custom FOV"),
                S("Field of View", 0, 160, 70)
            }}
        }
    },

    {
        name = "Killer",
        features = {
            {name = "Killer Movement", controls = {
                T("Walk Speed"),
                S("Walk Speed Value", 0, 320, 160)
            }},
            {name = "Attack Menu", controls = {
                D("Attack Mode", {"Basic Attack", "Lunge"}, "Basic Attack"),
                T("One Hit"),
                T("Show Range"),
                S("Hit Radius", 0, 16, 8),
                S("Hit Delay", 0, 450, 225),
                T("Auto Aim Hidden")
            }},
            {name = "Skill Killer", controls = {
                T("Counter Parry"),
                T("Infinite Lunge"),
                T("Anti Blind"),
                T("Infinite Corrupt Abyssal"),
                T("Block Windows/Pallet"),
                T("Bypass Skill Gendong"),
                T("No Cooldown Stalker/Hidden")
            }},
            {name = "Skill Menu", controls = {
                S("Break Speed", 0, 11, 5),
                D("3rd Person Camera", {"Default", "3rd Person", "First Person"}, "Default"),
                D("Ganti Topeng Masked", {"Default", "Mask 1", "Mask 2", "Mask 3", "Mask 4"}, "Default")
            }},
            {name = "Auto Hook", controls = {T("Enable Auto Hook")}},
            {name = "Kill All Instant", controls = {T("Kill All (Risk Ban)")}},
            {name = "Auto Attack", controls = {
                T("Auto Attack (No Animation)"),
                I("Attack Range (studs)", 12)
            }},
            {name = "Killer Utility", controls = {
                T("No Flashlight (Anti Blind)")
            }},
            {name = "Drop All Pallet [OP]", controls = {
                T("Enable Drop Pallet Shortcut"),
                B("Drop All Pallets Instantly"),
                K("Hotkey PC", "H")
            }},
            {name = "No Cooldown Skill", controls = {
                T("No Cooldown (M2 & Q) [Hidden]"),
                T("No Cooldown (Q & M2) [Myers]"),
                T("No Cooldown (M2 & Q) [Abysswalker]"),
                T("Infinite Frenzy [Jeff]"),
                T("Infinite Pursuit & Invis [Jason]")
            }},
            {name = "Hidden M2 Aimbot", controls = {
                T("Hidden M2 Aimbot (Nearest Visible)")
            }},
            {name = "Mask Selection [The Masked]", controls = {
                T("Enable Mask Selection GUI"),
                K("Toggle Hotkey", "RightControl")
            }},
            {name = "Trigger Auto Parry", controls = {
                T("Trigger Auto Parry (Fake Hit)")
            }},
            {name = "Fake Perks & Attributes", controls = {
                T("Fake Containment (Instant Vault)"),
                T("Fake Murderous Acrobatics"),
                T("Instant Break (Pallet & Gen)"),
                T("Super Speed (Walk Faster)")
            }}
        }
    },

    {
        name = "Auto Farm [BETA]",
        features = {
            {name = "Anti AFK", controls = {
                T("Stay Active (Anti AFK)", true)
            }},
            {name = "Auto Farm", locked = true, controls = {
                T("Enable Auto Farm")
            }},
        }
    },

    {
        name = "ESP",
        features = {
            {name = "Enable ESP", controls = {
                T("Enable ESP")
            }},
            {name = "ESP Role", controls = {
                T("ESP Survivor", true),
                T("ESP Killer", true),
            }},
            {name = "ESP Object", controls = {
                T("ESP Generator", true),
                T("ESP Gate"),
                T("ESP Hook"),
                T("ESP Pallet"),
                T("ESP Window / Vault", true)
            }},
            {name = "ESP Settings", controls = {
                T("Show Name"),
                T("Show Distance"),
                T("Show Health"),
                S("ESP Range", 0, 600, 600),
                S("ESP Transparency", 0, 11, 2)
            }},
            {name = "Custom ESP Colors", controls = {
                C("Survivor Color", "Survivor"),
                C("Killer Color", "Killer"),
                C("Zombie Dummy Color", "Zombie"),
                C("Generator Color", "Generator"),
                C("Gate Color", "Gate"),
                C("Hook Color", "Hook"),
                C("Pallet Color", "Pallet"),
                TC("Window / Vault Color", "Blue")
            }},
            {name = "ESP Display", controls = {
                T("Show Next Map", true),
                T("Indikator Stun Killer"),
                T("Show (FPS & Spectator)", true),
                T("Info Perk")
            }},
            {name = "Target", controls = {
                T("Target SCP / Zombie"),
                TC("SCP / Zombie Color", "Purple"),
                T("Target Player"),
                TC("Player Color", "Cyan"),
                T("Target Killer"),
                TC("Target Killer Color", "Red"),
                T("Target Generator"),
                TC("Target Generator Color", "Yellow"),
                T("Target Pallet"),
                TC("Target Pallet Color", "Orange"),
                T("Target Window / Vault"),
                TC("Window / Vault Color", "Blue")
            }}
        }
    },

    {
        name = "Aimbot",
        features = {
            {name = "Aimbot & Crosshair", controls = {
                T("Enable Aimbot"),
                T("Hold RMB to Aim", true),
                T("Show FOV Circle"),
                D("Crosshair Style", {"Off", "Dot", "Cross", "Circle"}, "Off"),
                T("Show Aim Line (3D)"),
                I("FOV Radius (pixels)", 120)
            }},
            {name = "Silent Flask (The Cure)", controls = {
                T("Silent Flask (The Cure)")
            }},
            {name = "Auto Aim Flashlight", controls = {
                T("Auto Aim Senter ke Killer"),
                T("Tampilkan Jarak Senter (Ring)")
            }},
            {name = "Custom Crosshair", controls = {
                T("Crosshair"),
                TC("Crosshair Color", "Green"),
                D("Crosshair Type", {"Off", "Dot", "Cross", "Circle"}, "Cross"),
                S("Crosshair Size", 1, 30, 4)
            }},
            {name = "Crosshair Position", controls = {
                S("Crosshair X Offset", -100, 100, 0),
                S("Crosshair Y Offset", -100, 100, 0)
            }},
            {name = "Pistol", controls = {
                T("Pistol"),
                TC("Pistol Color", "Green"),
                K("Pistol Hotkey", "Q"),
                T("Block Aim Knocked", true),
                T("Show Laser", true),
                T("Aim Lock"),
                K("Auto Prediksi Hotkey", "E"),
                T("Auto Prediksi"),
                S("Prediction", 0, 50, 35),
                S("Aim Offset", -10, 10, -1),
                T("Sound TOF"),
                D("Pilih Sound", {"Sound 1", "Sound 2", "Sound 3", "Sound 4", "Sound 5"}, "Sound 1"),
                D("Target Aim", {"Head", "Torso", "Legs"}, "Torso"),
                D("Pistol Target", {"Killer", "Survivor", "Zombie"}, "Killer")
            }},
            {name = "Target Menu", controls = {
                K("Mobile Target Shortcut Key", "T"),
                T("Show Mobile Target Shortcut"),
                T("Pistol FOV Mode"),
                T("Pistol Show FOV", true),
                S("Pistol FOV Radius", 0, 300, 120),
                L("Target yang masuk lingkaran akan menjadi target aim; prediction memakai velocity target.", 38)
            }},
            {name = "Veil", controls = {
                T("Veil"),
                K("Veil Hotkey", "V"),
                T("Smart Predict Mode"),
                S("Smart Predict Lead", 0, 50, 17),
                T("Veil Show FOV", true),
                T("Snapline", true),
                S("Veil FOV Radius", 0, 300, 120),
                S("Veil Distance", 0, 500, 150),
                S("Spear Speed", 0, 200, 165),
                S("Spear Gravity", 0, 200, 103)
            }}
        }
    },

    {
        name = "MISC",
        features = {
            {name = "Screen", controls = {
                {type = "label", label = "━━━━━ Camera ━━━━━", height = 28},
                T("Camera DBD"),
                S("Camera Height", -10, 10, 0),
                S("Camera Stiffness", 0, 32, 16),
                {type = "label", label = "━━━━━ Screen ━━━━━", height = 28},
                T("Custom Resolution"),
                S("Resolution Scale", -4, 4, 0)
            }},
            {name = "Movement", controls = {
                T("Noclip"),
                S("Hit Radius Visual", 0, 32, 8),
                S("Fly Speed", 0, 600, 100)
            }},
            {name = "Visual Enchancements", controls = {
                T("Skip Cutscene"),
                T("FullBright"),
                S("Fullbright Time", 0, 32, 16)
            }},
            {name = "Tools", controls = {
                T("Fling"),
                S("Fling Power", 0, 200000, 50000)
            }},
            {name = "Spoofer Profil", controls = {
                T("Fake Name"),
                {type = "label", label = "━━━━━ Profil Menu ━━━━━", height = 28},
                T("Fake Profil"),
                I("Set Level", "", "Isi angka"),
                I("Set Gears", "", "Isi angka"),
                I("Set Screws", "", "Isi angka")
            }},
            {name = "GUI Mob", controls = {
                T("Infinite Zoom"),
                T("Invisible GUI"),
                T("Sky Changer"),
                T("Moonwalk GUI"),
                T("Emote GUI")
            }},
            {name = "Jump Mod", controls = {
                T("High Jump"),
                S("Jump Power", 0, 600, 50),
                T("Infinite Jump")
            }},
            {name = "Graphics", controls = {
                T("Smooth HDR Graphics"),
                T("Unlock FPS"),
                D("Target FPS", {"60", "120", "240", "Max"}, "60")
            }}
        }
    },

    {
        name = "Config",
        features = {
            {name = "Menu Setting", controls = {
                T("Single Execute / Keep Loaded", true),
                S("Corner Radius", 0, 20, 10),
                T("Open Keybind", true),
                T("Custom Cursor"),
                T("Lock GUI"),
                K("Menu Bind", "RightShift")
            }},
            {name = "Theme", controls = {
                T("Background Color", true),
                D("Background Color Value", {"Black", "Dark Purple", "Purple", "Navy", "Dark Blue", "Dark Gray"}, "Dark Purple"),
                T("Main Color", true),
                D("Main Color Value", {"Purple", "Violet", "Blue", "Cyan", "Pink", "Red", "Green", "Orange"}, "Purple"),
                T("Accent Color", true),
                D("Accent Color Value", {"Purple", "Violet", "Blue", "Cyan", "Pink", "Red", "Green", "Orange", "Yellow", "White"}, "Purple"),
                T("Outline Color", true),
                D("Outline Color Value", {"White", "Purple", "Violet", "Blue", "Cyan", "Pink", "Red", "Green", "Yellow", "Black"}, "White"),
                T("Font Color", true),
                D("Font Color Value", {"White", "Light Gray", "Gray", "Purple", "Cyan", "Pink", "Yellow"}, "White"),
                D("Font Face", {"Fantast", "Goth", "Jura", "Roboto", "RobotoMono", "SourceSans"}, "Roboto"),
                D("Theme List", {"PURPLE", "PINK", "YELLOW", "GREEN", "GOLD", "RED", "BLUE", "SILVER", "ORANGE", "RAIMBOW"}, "PURPLE")
            }},
            {name = "Configuration", controls = {
                I("Config Name", "", "Masukan Nama"),
                B("Create Config"),
                D("Config List", {"No Config"}, "No Config"),
                B("Load Config"),
                B("Overwrite Config"),
                B("Delete Config"),
                B("Refresh List"),
                B("Set as Autoload"),
                B("Reset Autoload"),
                T("Auto Save Config", true),
                B("Save Config Now")
            }}
        }
    },

    {
        name = "Settings",
        features = {
            {name = "Killer Prediction", controls = {
                T("Predict Killer"),
                D("Killer Prediction Mode", {"Detected Role", "Candidate"}, "Detected Role")
            }}
        }
    },

    {
        name = "Info",
        features = {
            {name = "Profil User", controls = {
                {type = "profile", label = "User Profile"},
                {type = "label", label = "Username  •  " .. player.Name, height = 26},
                {type = "label", label = "Status  •  FREE", height = 26},
                {type = "label", label = "Expired  •  Tidak tersedia / tidak ditentukan", height = 32}
            }},
            {name = "Sosial Media", controls = {
                {type = "label", label = "Discord  •  discord.gg/JGNVEK6s7", height = 30},
                B("Join Discord"),
                {type = "label", label = "TikTok  •  @alettamelindaw", height = 30},
                B("Open TikTok")
            }},
            {name = "Server Info", controls = {
                {type = "label", label = "Server ID  •  " .. (game.JobId ~= "" and game.JobId or "Studio / Reserved"), height = 32},
                B("Copy Server ID"),
                B("Rejoin Server"),
                B("Server Hop")
            }},
            {name = "Script Info", controls = {
                {type = "label", label = "Developer  •  Aletta", height = 26},
                {type = "label", label = "Version  •  Beta V1", height = 26},
                {type = "label", label = "Status  •  Non Stable & Update", height = 32}
            }},
            {name = "GUI", controls = {
                B("Destroy UI")
            }}
        }
    }
}

-- =========================================================
-- GUI HELPERS
-- =========================================================

local function new(className, props, parent)
    local object = Instance.new(className)

    for key, value in pairs(props or {}) do
        pcall(function()
            object[key] = value
        end)
    end

    object.Parent = parent
    return object
end

local cornerObjects = {}

local function corner(object, radius)
    local c = new("UICorner", {
        CornerRadius = UDim.new(0, radius)
    }, object)
    table.insert(cornerObjects, c)
    return c
end

local function isPress(input)
    return input.UserInputType == Enum.UserInputType.MouseButton1
        or input.UserInputType == Enum.UserInputType.Touch
end

local function isMove(input)
    return input.UserInputType == Enum.UserInputType.MouseMovement
        or input.UserInputType == Enum.UserInputType.Touch
end

-- =========================================================
-- MAIN WINDOW
-- =========================================================

local gui = new("ScreenGui", {
    Name = "AlettaCreatorGUI",
    ResetOnSpawn = false,
    IgnoreGuiInset = true,
    ZIndexBehavior = Enum.ZIndexBehavior.Sibling
}, playerGui)

-- Runtime marker: tetap aktif selama sesi/place yang sama.
if AlettaRuntime then
    AlettaRuntime.AlettaCreatorRuntime = {
        Gui = gui,
        StartedAt = os.clock(),
        SingleExecute = true
    }
end

local window = new("Frame", {
    Size = UDim2.fromOffset(480, 330),
    Position = UDim2.fromOffset(120, 80),
    Visible = false,
    BackgroundColor3 = BG,
    BorderSizePixel = 0,
    ClipsDescendants = true
}, gui)
corner(window, 10)

local wStroke = new("UIStroke", {
    Color = Color3.new(1, 1, 1),
    Thickness = 2
}, window)

local wGradient = new("UIGradient", {
    Color = ColorSequence.new({
        ColorSequenceKeypoint.new(0, Color3.fromRGB(120, 60, 255)),
        ColorSequenceKeypoint.new(0.5, Color3.fromRGB(200, 90, 255)),
        ColorSequenceKeypoint.new(1, Color3.fromRGB(90, 40, 200))
    }),
    Rotation = 45
}, wStroke)

--// Purple background + Aletta logo composition
local bgImg = new("ImageLabel", {
    Name = "AlettaBackgroundArt",
    Image = BACKGROUND_ID,
    ImageTransparency = 0.12,
    ScaleType = Enum.ScaleType.Crop,
    BackgroundTransparency = 1,
    Size = UDim2.fromScale(1, 1),
    Active = false,
    ZIndex = 0
}, window)
corner(bgImg, 10)

local bgDark = new("Frame", {
    Name = "AlettaBackgroundTint",
    Size = UDim2.fromScale(1, 1),
    BackgroundColor3 = Color3.fromRGB(8, 3, 18),
    BackgroundTransparency = 0.34,
    BorderSizePixel = 0,
    Active = false,
    ZIndex = 1
}, window)
corner(bgDark, 10)

local top = new("Frame", {
    Size = UDim2.new(1, 0, 0, 48),
    BackgroundTransparency = 1,
    ZIndex = 10
}, window)

-- Header bar: no image asset. Fully themeable.
local headerBar = new("Frame", {
    Name = "AlettaHeaderBar",
    Size = UDim2.fromScale(1, 1),
    Position = UDim2.fromScale(0, 0),
    BackgroundColor3 = PANEL,
    BackgroundTransparency = 0.12,
    BorderSizePixel = 0,
    ZIndex = 10,
    Active = false
}, top)
corner(headerBar, 10)

local headerStroke = new("UIStroke", {
    Color = ACCENT,
    Thickness = 1.5,
    Transparency = 0.05
}, headerBar)

local headerACLeft = new("ImageLabel", {
    Name = "HeaderACLeft",
    Image = LOGO_ID,
    ScaleType = Enum.ScaleType.Fit,
    BackgroundTransparency = 1,
    Position = UDim2.fromOffset(9, 4),
    Size = UDim2.fromOffset(42, 40),
    ZIndex = 12
}, top)

local headerLogo = new("TextLabel", {
    Name = "AlettaHeaderNotice",
    Text = "Aletta Script Free Fremium\nViolence District",
    Font = Enum.Font.GothamBold,
    TextSize = 12,
    TextColor3 = TEXT,
    TextWrapped = true,
    BackgroundTransparency = 1,
    AnchorPoint = Vector2.new(0.5, 0.5),
    Position = UDim2.new(0.5, 0, 0.5, 0),
    Size = UDim2.new(1, -116, 1, -4),
    TextXAlignment = Enum.TextXAlignment.Center,
    TextYAlignment = Enum.TextYAlignment.Center,
    ZIndex = 12
}, top)

local headerWarning = new("TextLabel", {
    Name = "AlettaHeaderWarning",
    Text = "Tidak di Perjual Belikan • Jika ada Yang Menjual Berarti PENIPU !!!",
    Font = Enum.Font.Gotham,
    TextSize = 8,
    TextScaled = true,
    TextColor3 = TEXT,
    TextTransparency = 0.08,
    BackgroundTransparency = 1,
    Position = UDim2.new(0, 58, 0, 33),
    Size = UDim2.new(1, -150, 0, 12),
    TextXAlignment = Enum.TextXAlignment.Center,
    TextYAlignment = Enum.TextYAlignment.Center,
    ZIndex = 12
}, top)

local headerACRight = new("ImageLabel", {
    Name = "HeaderACRight",
    Image = LOGO_ID,
    ScaleType = Enum.ScaleType.Fit,
    BackgroundTransparency = 1,
    AnchorPoint = Vector2.new(1, 0),
    Position = UDim2.new(1, -42, 0, 4),
    Size = UDim2.fromOffset(42, 40),
    ZIndex = 12
}, top)

local headerBarShade = new("Frame", {
    Name = "AlettaHeaderBarShade",
    Size = UDim2.fromScale(1, 1),
    BackgroundColor3 = Color3.new(0, 0, 0),
    BackgroundTransparency = 0.82,
    BorderSizePixel = 0,
    ZIndex = 11,
    Active = false
}, top)
corner(headerBarShade, 10)

local headerTitle = new("TextLabel", {
    Name = "AlettaCreatorTitle", Text = "", BackgroundTransparency = 1, Visible = false, ZIndex = 12
}, top)
local headerSubtitle = new("TextLabel", {
    Name = "AlettaCreatorSubtitle", Text = "", BackgroundTransparency = 1, Visible = false, ZIndex = 12
}, top)
local headerRightTitle = new("TextLabel", {
    Name = "AlettaHeaderRightTitle", Text = "", BackgroundTransparency = 1, Visible = false, ZIndex = 12
}, top)
local headerRightSubtitle = new("TextLabel", {
    Name = "AlettaHeaderRightSubtitle", Text = "", BackgroundTransparency = 1, Visible = false, ZIndex = 12
}, top)

local minBtn = new("TextButton", {
    Text = "–",
    Font = Enum.Font.GothamBold,
    TextSize = 20,
    TextColor3 = TEXT,
    BackgroundColor3 = PANEL,
    BackgroundTransparency = 0.3,
    Size = UDim2.fromOffset(28, 26),
    Position = UDim2.new(1, -38, 0, 7),
    ZIndex = 14
}, top)
corner(minBtn, 6)
local side = new("ScrollingFrame", {
    Position = UDim2.fromOffset(8, 48),
    Size = UDim2.fromOffset(150, 274),
    BackgroundTransparency = 1,
    ZIndex = 10,
    ScrollBarThickness = 0,
    BorderSizePixel = 0,
    CanvasSize = UDim2.new(),
    AutomaticCanvasSize = Enum.AutomaticSize.Y
}, window)

new("UIListLayout", {
    Padding = UDim.new(0, 4),
    SortOrder = Enum.SortOrder.LayoutOrder
}, side)

-- Tidak menggunakan emoji search.
local search = new("TextBox", {
    PlaceholderText = "Search feature...",
    Text = "",
    Font = Enum.Font.Gotham,
    TextSize = 13,
    TextColor3 = TEXT,
    PlaceholderColor3 = Color3.fromRGB(150, 150, 150),
    BackgroundColor3 = PANEL,
    BackgroundTransparency = 0.3,
    Size = UDim2.new(1, 0, 0, 32),
    ClearTextOnFocus = false,
    LayoutOrder = -1
}, side)
corner(search, 6)

local title = new("TextLabel", {
    Text = "",
    Font = Enum.Font.GothamBold,
    TextSize = 11,
    TextColor3 = TEXT,
    BackgroundTransparency = 1,
    Position = UDim2.fromOffset(172, 48),
    Size = UDim2.fromOffset(290, 28),
    TextXAlignment = Enum.TextXAlignment.Left,
    ZIndex = 10
}, window)

new("Frame", {
    Position = UDim2.fromOffset(166, 52),
    Size = UDim2.fromOffset(3, 20),
    BackgroundColor3 = ACCENT,
    BorderSizePixel = 0
}, window)

local popup = new("ScrollingFrame", {
    Size = UDim2.fromOffset(150, 40),
    Position = UDim2.fromOffset(322, 84),
    BackgroundColor3 = Color3.fromRGB(16, 12, 26),
    BorderSizePixel = 0,
    Visible = false,
    ZIndex = 20,
    ScrollBarThickness = 3,
    ScrollBarImageColor3 = ACCENT,
    CanvasSize = UDim2.new(),
    AutomaticCanvasSize = Enum.AutomaticSize.Y
}, window)
corner(popup, 8)
new("UIStroke", {Color = ACCENT, Thickness = 1}, popup)
new("UIListLayout", {Padding = UDim.new(0, 2)}, popup)
new("UIPadding", {
    PaddingTop = UDim.new(0, 6),
    PaddingBottom = UDim.new(0, 6),
    PaddingLeft = UDim.new(0, 6),
    PaddingRight = UDim.new(0, 6)
}, popup)

local popupOwner

local function closePopup()
    popup.Visible = false
    popupOwner = nil
end

local function openDropdown(owner, options, current, onPick)
    if popup.Visible and popupOwner == owner then
        closePopup()
        return
    end

    for _, child in ipairs(popup:GetChildren()) do
        if child:IsA("TextButton") then
            child:Destroy()
        end
    end

    for _, option in ipairs(options) do
        local button = new("TextButton", {
            Text = "  " .. tostring(option),
            Font = Enum.Font.GothamBold,
            TextSize = 13,
            TextColor3 = option == current and TEXT or GRAY,
            TextXAlignment = Enum.TextXAlignment.Left,
            BackgroundColor3 = ACCENT,
            BackgroundTransparency = option == current and 0.6 or 1,
            Size = UDim2.new(1, -4, 0, 30),
            ZIndex = 21
        }, popup)

        corner(button, 6)

        button.Activated:Connect(function()
            onPick(option)
            closePopup()
        end)
    end

    local height = math.min(#options * 32 + 12, 190)
    local rel = owner.AbsolutePosition - window.AbsolutePosition
    local x = math.clamp(
        rel.X + owner.AbsoluteSize.X - 150,
        8,
        math.max(8, window.AbsoluteSize.X - 158)
    )
    local y = rel.Y + owner.AbsoluteSize.Y + 2

    if y + height > window.AbsoluteSize.Y - 4 then
        y = rel.Y - height - 2
    end

    popup.Position = UDim2.fromOffset(x, math.max(y, 44))
    popup.Size = UDim2.fromOffset(150, height)
    popup.CanvasPosition = Vector2.zero
    popupOwner = owner
    popup.Visible = true
end

local pages = {}
local tabButtons = {}
local allRows = {}

local function showTab(name)
    closePopup()

    for tabName, page in pairs(pages) do
        page.Visible = tabName == name
    end

    for tabName, button in pairs(tabButtons) do
        button.TextColor3 = tabName == name and TEXT or GRAY
    end

    title.Text = name
end

local function commit(label, value)
    Values[label] = value

    local hook = Hooks[label]
    if hook then
        task.spawn(function()
            local ok, err = pcall(hook, value)
            if not ok then
                warn("[Aletta] " .. tostring(label) .. ": " .. tostring(err))
            end
        end)
    end
end

local function makeControl(parent, control, order)
    local frame = new("Frame", {
        Size = UDim2.new(1, 0, 0, 38),
        BackgroundTransparency = 1,
        LayoutOrder = order
    }, parent)

    Controls[control.label] = Controls[control.label] or {}

    if control.type ~= "button"
        and control.type ~= "label"
        and control.type ~= "slider" then

        new("TextLabel", {
            Text = "   " .. control.label,
            Font = Enum.Font.GothamBold,
            TextSize = 12,
            TextColor3 = Color3.fromRGB(220, 220, 220),
            BackgroundTransparency = 1,
            Size = UDim2.new(1, -118, 1, 0),
            TextXAlignment = Enum.TextXAlignment.Left,
            TextWrapped = true
        }, frame)
    end

    if control.type == "toggle" then
        local state = control.default == true
        Values[control.label] = state

        local switch = new("TextButton", {
            Text = "",
            Size = UDim2.fromOffset(40, 20),
            Position = UDim2.new(1, -52, 0.5, -10),
            AutoButtonColor = false,
            BackgroundColor3 = state and ACCENT or OFF
        }, frame)
        corner(switch, 10)

        local knob = new("Frame", {
            Size = UDim2.fromOffset(16, 16),
            Position = state and UDim2.fromOffset(22, 2) or UDim2.fromOffset(2, 2),
            BackgroundColor3 = TEXT
        }, switch)
        corner(knob, 8)

        local function setState(value, runHook)
            state = value == true

            TweenService:Create(
                switch,
                TweenInfo.new(0.15),
                {BackgroundColor3 = state and ACCENT or OFF}
            ):Play()

            TweenService:Create(
                knob,
                TweenInfo.new(0.15),
                {Position = state and UDim2.fromOffset(22, 2) or UDim2.fromOffset(2, 2)}
            ):Play()

            Values[control.label] = state

            if runHook then
                commit(control.label, state)
            end
        end

        Controls[control.label].set = function(value)
            setState(value, true)
        end

        switch.Activated:Connect(function()
            setState(not state, true)
        end)

    elseif control.type == "input" then
        Values[control.label] = tonumber(control.default) or control.default

        local box = new("TextBox", {
            Text = control.default,
            PlaceholderText = control.placeholder or "",
            PlaceholderColor3 = Color3.fromRGB(140, 140, 140),
            Font = Enum.Font.GothamBold,
            TextSize = 12,
            TextColor3 = TEXT,
            BackgroundColor3 = FIELD,
            Size = UDim2.fromOffset(96, 26),
            Position = UDim2.new(1, -106, 0.5, -13),
            ClearTextOnFocus = false,
            TextTruncate = Enum.TextTruncate.AtEnd
        }, frame)
        corner(box, 6)

        Controls[control.label].set = function(value)
            box.Text = tostring(value)
            commit(control.label, tonumber(value) or value)
        end

        box.FocusLost:Connect(function()
            commit(control.label, tonumber(box.Text) or box.Text)
        end)

    elseif control.type == "hotkey" then
        local keyName = tostring(control.default or "Unknown")
        local key = Enum.KeyCode[keyName] or Enum.KeyCode.Unknown
        Values[control.label] = key

        local button = new("TextButton", {
            Text = key.Name,
            Font = Enum.Font.GothamBold,
            TextSize = 12,
            TextColor3 = TEXT,
            BackgroundColor3 = FIELD,
            Size = UDim2.fromOffset(96, 26),
            Position = UDim2.new(1, -106, 0.5, -13)
        }, frame)
        corner(button, 6)

        local listening = false

        button.Activated:Connect(function()
            if listening then return end

            listening = true
            button.Text = "..."

            local connection
            connection = UIS.InputBegan:Connect(function(input, gameProcessed)
                if gameProcessed then return end

                if input.UserInputType == Enum.UserInputType.Keyboard then
                    button.Text = input.KeyCode.Name
                    commit(control.label, input.KeyCode)
                    listening = false

                    if connection then
                        connection:Disconnect()
                        connection = nil
                    end
                end
            end)
        end)

        Controls[control.label].set = function(value)
            local newKey

            if typeof(value) == "EnumItem" then
                newKey = value
            else
                newKey = Enum.KeyCode[tostring(value)] or Enum.KeyCode.Unknown
            end

            button.Text = newKey.Name
            commit(control.label, newKey)
        end

    elseif control.type == "dropdown" then
        Values[control.label] = control.default

        local button = new("TextButton", {
            Text = tostring(control.default),
            Font = Enum.Font.GothamBold,
            TextSize = 12,
            TextColor3 = TEXT,
            BackgroundColor3 = FIELD,
            Size = UDim2.fromOffset(96, 26),
            Position = UDim2.new(1, -106, 0.5, -13),
            TextTruncate = Enum.TextTruncate.AtEnd
        }, frame)
        corner(button, 6)

        button.Activated:Connect(function()
            openDropdown(
                button,
                control.options,
                Values[control.label],
                function(value)
                    button.Text = tostring(value)
                    commit(control.label, value)
                end
            )
        end)

        Controls[control.label].set = function(value)
            button.Text = tostring(value)
            commit(control.label, value)
        end

        Controls[control.label].setOptions = function(options, current)
            control.options = options or control.options
            if current ~= nil then
                button.Text = tostring(current)
                Values[control.label] = current
            end
        end

    elseif control.type == "slider" then
        frame.Size = UDim2.new(1, 0, 0, 48)
        Values[control.label] = control.default

        new("TextLabel", {
            Text = "   " .. control.label,
            Font = Enum.Font.GothamBold,
            TextSize = 12,
            TextColor3 = Color3.fromRGB(220, 220, 220),
            BackgroundTransparency = 1,
            Size = UDim2.new(1, -80, 0, 24),
            TextXAlignment = Enum.TextXAlignment.Left,
            TextTruncate = Enum.TextTruncate.AtEnd
        }, frame)

        local valueLabel = new("TextLabel", {
            Text = tostring(control.default) .. "/" .. tostring(control.max),
            Font = Enum.Font.GothamBold,
            TextSize = 12,
            TextColor3 = GRAY,
            BackgroundTransparency = 1,
            Size = UDim2.fromOffset(70, 24),
            Position = UDim2.new(1, -78, 0, 0),
            TextXAlignment = Enum.TextXAlignment.Right
        }, frame)

        local track = new("TextButton", {
            Text = "",
            AutoButtonColor = false,
            BackgroundColor3 = FIELD,
            Size = UDim2.new(1, -24, 0, 8),
            Position = UDim2.new(0, 12, 0, 32)
        }, frame)
        corner(track, 4)

        local fill = new("Frame", {
            BackgroundColor3 = ACCENT,
            BorderSizePixel = 0,
            Size = UDim2.fromScale(
                (control.default - control.min) / math.max(1, control.max - control.min),
                1
            )
        }, track)
        corner(fill, 4)

        local function setValue(value, runHook)
            local number = tonumber(value) or control.default
            number = math.clamp(
                math.floor(number + 0.5),
                control.min,
                control.max
            )

            Values[control.label] = number

            local alpha = (number - control.min) / math.max(1, control.max - control.min)
            fill.Size = UDim2.fromScale(alpha, 1)
            valueLabel.Text = tostring(number) .. "/" .. tostring(control.max)

            if runHook then
                commit(control.label, number)
            end
        end

        Controls[control.label].set = function(value)
            setValue(value, true)
        end

        local dragging = false

        local function setFromX(x)
            local width = math.max(1, track.AbsoluteSize.X)
            local alpha = math.clamp(
                (x - track.AbsolutePosition.X) / width,
                0,
                1
            )

            setValue(
                control.min + alpha * (control.max - control.min),
                true
            )
        end

        track.InputBegan:Connect(function(input)
            if isPress(input) then
                dragging = true
                setFromX(input.Position.X)
            end
        end)

        UIS.InputChanged:Connect(function(input)
            if dragging and isMove(input) then
                setFromX(input.Position.X)
            end
        end)

        UIS.InputEnded:Connect(function(input)
            if isPress(input) then
                dragging = false
            end
        end)

    elseif control.type == "profile" then
        frame.Size = UDim2.new(1, 0, 0, 92)

        local avatar = new("ImageLabel", {
            Name = "UserAvatar",
            BackgroundColor3 = FIELD,
            BackgroundTransparency = 0,
            Size = UDim2.fromOffset(72, 72),
            Position = UDim2.fromOffset(8, 8),
            Image = "",
            ScaleType = Enum.ScaleType.Crop
        }, frame)
        corner(avatar, 36)

        local nameLabel = new("TextLabel", {
            Text = player.DisplayName,
            Font = Enum.Font.GothamBold,
            TextSize = 15,
            TextColor3 = TEXT,
            BackgroundTransparency = 1,
            Position = UDim2.fromOffset(92, 12),
            Size = UDim2.new(1, -100, 0, 24),
            TextXAlignment = Enum.TextXAlignment.Left,
            TextTruncate = Enum.TextTruncate.AtEnd
        }, frame)

        local usernameLabel = new("TextLabel", {
            Text = "@" .. player.Name,
            Font = Enum.Font.Gotham,
            TextSize = 12,
            TextColor3 = GRAY,
            BackgroundTransparency = 1,
            Position = UDim2.fromOffset(92, 38),
            Size = UDim2.new(1, -100, 0, 20),
            TextXAlignment = Enum.TextXAlignment.Left,
            TextTruncate = Enum.TextTruncate.AtEnd
        }, frame)

        local statusLabel = new("TextLabel", {
            Text = "FREE  •  Beta V1",
            Font = Enum.Font.GothamBold,
            TextSize = 11,
            TextColor3 = ACCENT,
            BackgroundTransparency = 1,
            Position = UDim2.fromOffset(92, 60),
            Size = UDim2.new(1, -100, 0, 18),
            TextXAlignment = Enum.TextXAlignment.Left
        }, frame)

        task.spawn(function()
            local ok, content = pcall(function()
                return Players:GetUserThumbnailAsync(player.UserId, Enum.ThumbnailType.HeadShot, Enum.ThumbnailSize.Size100x100)
            end)
            if ok and content then
                avatar.Image = content
            end
        end)

    elseif control.type == "button" then
        frame.Size = UDim2.new(1, 0, 0, 38)

        local button = new("TextButton", {
            Text = control.label,
            Font = Enum.Font.GothamBold,
            TextSize = 13,
            TextColor3 = TEXT,
            BackgroundColor3 = FIELD,
            Size = UDim2.new(1, -16, 0, 32),
            Position = UDim2.fromOffset(8, 3)
        }, frame)
        corner(button, 6)

        button.Activated:Connect(function()
            local hook = Hooks[control.label]
            if hook then
                task.spawn(function()
                    local ok, err = pcall(hook)
                    if not ok then
                        warn("[Aletta] " .. control.label .. ": " .. tostring(err))
                    end
                end)
            end
        end)

    elseif control.type == "label" then
        frame.Size = UDim2.new(1, 0, 0, control.height or 30)

        local note = new("TextLabel", {
            Text = control.label,
            Font = Enum.Font.Gotham,
            TextSize = 11,
            TextColor3 = GRAY,
            BackgroundTransparency = 1,
            Size = UDim2.fromScale(1, 1),
            TextXAlignment = Enum.TextXAlignment.Left,
            TextYAlignment = Enum.TextYAlignment.Top,
            TextWrapped = true
        }, frame)

        new("UIPadding", {
            PaddingLeft = UDim.new(0, 12),
            PaddingRight = UDim.new(0, 12),
            PaddingTop = UDim.new(0, 6)
        }, note)
    end
end

local function makeRow(page, feature)
    local row = new("Frame", {
        Size = UDim2.new(1, -6, 0, 40),
        AutomaticSize = Enum.AutomaticSize.Y,
        BackgroundColor3 = PANEL,
        BackgroundTransparency = 0.3,
        BorderSizePixel = 0
    }, page)
    corner(row, 6)

    new("UIListLayout", {
        SortOrder = Enum.SortOrder.LayoutOrder
    }, row)

    -- Tidak ada emoji LOCK di sini.
    local head = new("TextButton", {
        Text = "   " .. feature.name,
        Font = Enum.Font.GothamBold,
        TextSize = 10,
        TextColor3 = TEXT,
        TextXAlignment = Enum.TextXAlignment.Left,
        BackgroundTransparency = 1,
        Size = UDim2.new(1, 0, 0, 40),
        LayoutOrder = 1,
        TextTruncate = Enum.TextTruncate.AtEnd
    }, row)

    new("TextLabel", {
        Text = "v",
        TextColor3 = GRAY,
        Font = Enum.Font.GothamBold,
        TextSize = 14,
        BackgroundTransparency = 1,
        Size = UDim2.fromOffset(32, 40),
        Position = UDim2.new(1, -36, 0, 0)
    }, head)

    local body = new("Frame", {
        Size = UDim2.new(1, 0, 0, 0),
        AutomaticSize = Enum.AutomaticSize.Y,
        BackgroundTransparency = 1,
        Visible = false,
        LayoutOrder = 2
    }, row)

    new("UIListLayout", {
        SortOrder = Enum.SortOrder.LayoutOrder
    }, body)

    new("UIPadding", {
        PaddingBottom = UDim.new(0, 6)
    }, body)

    for i, control in ipairs(feature.controls) do
        makeControl(body, control, i)
    end

    head.Activated:Connect(function()
        closePopup()
        body.Visible = not body.Visible
    end)

    table.insert(allRows, {
        frame = row,
        name = feature.name:lower(),
        page = page
    })
end

for index, tab in ipairs(CONFIG) do
    local button = new("TextButton", {
        Text = "  " .. tab.name,
        Font = Enum.Font.GothamBold,
        TextSize = 14,
        TextColor3 = TEXT,
        TextXAlignment = Enum.TextXAlignment.Left,
        BackgroundTransparency = 1,
        Size = UDim2.new(1, 0, 0, 36),
        LayoutOrder = index,
        TextTruncate = Enum.TextTruncate.AtEnd
    }, side)

    tabButtons[tab.name] = button

    local page = new("ScrollingFrame", {
        Position = UDim2.fromOffset(166, 82),
        Size = UDim2.fromOffset(306, 240),
        BackgroundTransparency = 1,
        BorderSizePixel = 0,
        ScrollBarThickness = 3,
        ScrollBarImageColor3 = ACCENT,
        Visible = false,
        CanvasSize = UDim2.new(),
        AutomaticCanvasSize = Enum.AutomaticSize.Y
    }, window)

    new("UIListLayout", {
        Padding = UDim.new(0, 6)
    }, page)

    pages[tab.name] = page

    for _, feature in ipairs(tab.features) do
        makeRow(page, feature)
    end

    button.Activated:Connect(function()
        showTab(tab.name)
    end)
end

showTab(CONFIG[1].name)

for key, value in pairs(Values) do
    Defaults[key] = value
end

search:GetPropertyChangedSignal("Text"):Connect(function()
    local query = search.Text:lower()

    for _, row in ipairs(allRows) do
        row.frame.Visible = query == "" or row.name:find(query, 1, true) ~= nil
    end
end)

-- =========================================================
-- OPEN/CLOSE BUTTON DENGAN ASSET 111827431469508
-- =========================================================

local icon = new("ImageButton", {
    Name = "AlettaFloatingLogo",
    Image = LOGO_ID,
    ScaleType = Enum.ScaleType.Fit,
    BackgroundColor3 = Color3.fromRGB(18, 8, 32),
    BackgroundTransparency = 0,
    Size = UDim2.fromOffset(44, 44),
    Position = UDim2.fromOffset(18, 120),
    Visible = true,
    Active = true,
    AutoButtonColor = false,
    ZIndex = 100
}, gui)
corner(icon, 22)

local iconStroke = new("UIStroke", {
    Color = ACCENT,
    Thickness = 2.5
}, icon)

local iconGradient = new("UIGradient", {
    Color = ColorSequence.new({
        ColorSequenceKeypoint.new(0, Color3.fromRGB(110, 50, 255)),
        ColorSequenceKeypoint.new(0.5, Color3.fromRGB(230, 110, 255)),
        ColorSequenceKeypoint.new(1, Color3.fromRGB(90, 40, 200))
    }),
    Rotation = 45
}, iconStroke)

local function draggable(handle, target, onTap)
    local dragging = false
    local moved = false
    local startMouse
    local startPosition

    handle.InputBegan:Connect(function(input)
        if Values["Lock GUI"] then return end
        if not isPress(input) then return end

        dragging = true
        moved = false
        startMouse = input.Position
        startPosition = target.Position

        input.Changed:Connect(function()
            if input.UserInputState == Enum.UserInputState.End then
                dragging = false

                if not moved and onTap then
                    onTap()
                end
            end
        end)
    end)

    UIS.InputChanged:Connect(function(input)
        if not dragging or not isMove(input) then return end

        local delta = input.Position - startMouse

        if delta.Magnitude > 6 then
            moved = true
        end

        if moved then
            target.Position = UDim2.fromOffset(
                startPosition.X.Offset + delta.X,
                startPosition.Y.Offset + delta.Y
            )
        end
    end)
end

local loadingGate = true

local function minimize()
    closePopup()
    window.Visible = false
    icon.Visible = true
end

local function restore()
    window.Visible = true
    icon.Visible = true
end

minBtn.Activated:Connect(minimize)
icon.Activated:Connect(function()
    if loadingGate then return end
    if window.Visible then
        minimize()
    else
        restore()
    end
end)

-- Panel dan logo mempunyai posisi/drag masing-masing.
draggable(top, window)
draggable(icon, icon)


-- =========================================================
-- RAIMBOW THEME ANIMATION - FULL GUI
-- =========================================================
local function paintRainbowTheme()
    local hue = (os.clock() * 0.10) % 1
    local main = Color3.fromHSV(hue, 0.72, 0.72)
    local accent = Color3.fromHSV((hue + 0.16) % 1, 0.88, 1)
    local outline = Color3.fromHSV((hue + 0.50) % 1, 0.45, 1)
    local field = main:Lerp(Color3.new(0,0,0), 0.48)
    local panel = main:Lerp(Color3.new(0,0,0), 0.66)

    ACCENT = accent
    PANEL = panel
    FIELD = field

    if window and window.Parent then
        -- Keep the Rainbow asset as the background; only the GUI colors animate.
        if bgImg then bgImg.Image = "rbxassetid://89672943739008" end
        if bgDark then bgDark.BackgroundColor3 = panel end
        window.BackgroundColor3 = Color3.new(0,0,0)
    end

    for _, obj in ipairs(window:GetDescendants()) do
        if obj:IsA("UIStroke") then
            obj.Color = outline
        elseif obj:IsA("UIGradient") and obj.Parent and obj.Parent:IsA("UIStroke") then
            obj.Color = ColorSequence.new({
                ColorSequenceKeypoint.new(0, Color3.fromHSV(hue,0.90,1)),
                ColorSequenceKeypoint.new(0.5, Color3.fromHSV((hue+0.33)%1,0.90,1)),
                ColorSequenceKeypoint.new(1, Color3.fromHSV((hue+0.66)%1,0.90,1))
            })
        elseif obj:IsA("TextLabel") or obj:IsA("TextButton") or obj:IsA("TextBox") then
            obj.TextColor3 = Color3.fromRGB(255,255,255)
        elseif obj:IsA("TextButton") or obj:IsA("ImageButton") then
            obj.BackgroundColor3 = field
        elseif obj:IsA("ScrollingFrame") then
            obj.BackgroundColor3 = panel
        elseif obj:IsA("Frame") and obj.BackgroundTransparency < 1 then
            local n = string.lower(obj.Name or "")
            local isBg = obj == bgImg or obj == bgDark or obj == headerBar or obj == headerBarShade
            if not isBg then
                if n:find("header") or n:find("top") then
                    obj.BackgroundColor3 = panel
                else
                    obj.BackgroundColor3 = field
                end
            end
        end
    end

    if wStroke then wStroke.Color = outline end
    if headerStroke then headerStroke.Color = outline end
    if iconStroke then iconStroke.Color = outline end
end

task.spawn(function()
    while gui and gui.Parent do
        if Values["Theme List"] == "RAIMBOW" then
            pcall(paintRainbowTheme)
        end
        task.wait(0.08)
    end
end)

-- =========================================================
-- LOAD NOTIFICATION
-- =========================================================

local function showLoadNotification()
    local notification = new("Frame", {
        Name = "AlettaLoadNotification",
        AnchorPoint = Vector2.new(1, 1),
        Position = UDim2.new(1, -18, 1, -18),
        Size = UDim2.fromOffset(250, 78),
        BackgroundColor3 = Color3.fromRGB(10, 10, 12),
        BackgroundTransparency = 0.14,
        BorderSizePixel = 0,
        ZIndex = 300,
    }, gui)
    corner(notification, 8)

    new("UIStroke", {
        Color = ACCENT,
        Thickness = 1.5,
        Transparency = 0.35,
    }, notification)

    new("TextLabel", {
        Text = "Sukses",
        Font = Enum.Font.GothamBold,
        TextSize = 17,
        TextColor3 = TEXT,
        BackgroundTransparency = 1,
        Position = UDim2.fromOffset(8, 7),
        Size = UDim2.new(1, -16, 0, 22),
        TextXAlignment = Enum.TextXAlignment.Center,
        ZIndex = 301,
    }, notification)

    new("TextLabel", {
        Text = "Berhasil memuat script untuk: [CURE]",
        Font = Enum.Font.Gotham,
        TextSize = 11,
        TextColor3 = TEXT,
        BackgroundTransparency = 1,
        Position = UDim2.fromOffset(8, 30),
        Size = UDim2.new(1, -16, 0, 20),
        TextXAlignment = Enum.TextXAlignment.Center,
        ZIndex = 301,
    }, notification)

    new("TextLabel", {
        Text = "Distrik Kekerasan",
        Font = Enum.Font.Gotham,
        TextSize = 10,
        TextColor3 = GRAY,
        BackgroundTransparency = 1,
        Position = UDim2.fromOffset(8, 51),
        Size = UDim2.new(1, -16, 0, 18),
        TextXAlignment = Enum.TextXAlignment.Center,
        ZIndex = 301,
    }, notification)

    local loadSound = Instance.new("Sound")
    loadSound.Name = "AlettaLoadSound"
    loadSound.SoundId = LOAD_SOUND_ID
    loadSound.Volume = 1
    loadSound.Parent = SoundService

    task.spawn(function()
        local ok = pcall(function()
            ContentProvider:PreloadAsync({loadSound})
        end)
        if loadSound.Parent then
            pcall(function()
                loadSound:Play()
            end)
        end
    end)

    -- Panel baru muncul 2 detik setelah notifikasi tampil.
    task.delay(2, function()
        if window and window.Parent then
            window.Visible = true
            icon.Visible = true
            loadingGate = false
        end
    end)

    task.delay(4, function()
        if notification and notification.Parent then
            local tween = TweenService:Create(notification, TweenInfo.new(0.25), {BackgroundTransparency = 1})
            tween:Play()
            task.delay(0.3, function()
                if notification and notification.Parent then notification:Destroy() end
            end)
        end
    end)
end

-- =========================================================
-- LOCAL TEST FEATURES
-- =========================================================

local originalWalkSpeed = 16
local originalFOV = camera and camera.FieldOfView or 70

local originalLighting = {
    Brightness = Lighting.Brightness,
    ClockTime = Lighting.ClockTime,
    FogEnd = Lighting.FogEnd,
    FogStart = Lighting.FogStart,
    GlobalShadows = Lighting.GlobalShadows
}

local particleCache = {}
local crosshairGui
local fpsLabel
local espFolder
local espGui
local mwGui
local mwButton

local function character()
    return player.Character
end

local function humanoid()
    local c = character()
    return c and c:FindFirstChildOfClass("Humanoid")
end

local function root()
    local c = character()
    return c and c:FindFirstChild("HumanoidRootPart")
end

-- =========================================================
-- PARRY DETECTION RANGE VISUAL
-- =========================================================
-- Visual Auto Parry mengikuti referensi: hanya ring tipis di tanah,
-- tanpa disc/lingkaran penuh. Radius langsung mengikuti slider
-- Survivor > Parry Menu > Parry Radius.
local parryRangeVisual = nil
local PARRY_RING_SEGMENTS = 72
local PARRY_RING_COLOR = Color3.fromRGB(110, 245, 235)
local PARRY_RING_WIDTH = 0.10

local function destroyParryRangeVisual()
    if parryRangeVisual and parryRangeVisual.folder then
        pcall(function() parryRangeVisual.folder:Destroy() end)
    end
    parryRangeVisual = nil
end

local function getParryGroundPosition(r)
    if not r then return nil end

    local params = RaycastParams.new()
    params.FilterType = Enum.RaycastFilterType.Exclude
    params.FilterDescendantsInstances = {character()}
    params.IgnoreWater = false

    local origin = r.Position + Vector3.new(0, 2, 0)
    local result = workspace:Raycast(origin, Vector3.new(0, -20, 0), params)

    if result then
        return result.Position + Vector3.new(0, 0.055, 0)
    end

    local h = humanoid()
    local hip = h and tonumber(h.HipHeight) or 2
    return r.Position - Vector3.new(0, hip + 1.5, 0)
end

local function makeParryRing()
    local folder = Instance.new("Folder")
    folder.Name = "AlettaParryDetectionRange"
    folder.Parent = workspace

    local data = {
        folder = folder,
        points = {},
        beams = {},
    }

    for i = 1, PARRY_RING_SEGMENTS do
        local a = Instance.new("Part")
        a.Name = "PointA"
        a.Anchored = true
        a.CanCollide = false
        a.CanTouch = false
        a.CanQuery = false
        a.CastShadow = false
        a.Transparency = 1
        a.Size = Vector3.new(0.05, 0.05, 0.05)
        a.Parent = folder

        local b = Instance.new("Part")
        b.Name = "PointB"
        b.Anchored = true
        b.CanCollide = false
        b.CanTouch = false
        b.CanQuery = false
        b.CastShadow = false
        b.Transparency = 1
        b.Size = Vector3.new(0.05, 0.05, 0.05)
        b.Parent = folder

        local att0 = Instance.new("Attachment")
        att0.Parent = a
        local att1 = Instance.new("Attachment")
        att1.Parent = b

        local beam = Instance.new("Beam")
        beam.Name = "ParryRing"
        beam.Attachment0 = att0
        beam.Attachment1 = att1
        beam.Width0 = PARRY_RING_WIDTH
        beam.Width1 = PARRY_RING_WIDTH
        beam.Color = ColorSequence.new(PARRY_RING_COLOR)
        beam.Transparency = NumberSequence.new(0.08)
        beam.LightEmission = 1
        beam.FaceCamera = true
        beam.Segments = 1
        beam.Parent = folder

        data.points[i] = {a, b}
        data.beams[i] = beam
    end

    return data
end

local function updateParryRangeVisual()
    local r = root()
    if not r then
        destroyParryRangeVisual()
        return
    end

    local radius = math.clamp(tonumber(Values["Parry Radius"]) or 13, 2, 100)
    local groundPos = getParryGroundPosition(r)
    if not groundPos then return end

    if not parryRangeVisual or not parryRangeVisual.folder or not parryRangeVisual.folder.Parent then
        destroyParryRangeVisual()
        parryRangeVisual = makeParryRing()
    end

    for i = 1, PARRY_RING_SEGMENTS do
        local pair = parryRangeVisual.points[i]
        if pair then
            local a0 = ((i - 1) / PARRY_RING_SEGMENTS) * math.pi * 2
            local a1 = (i / PARRY_RING_SEGMENTS) * math.pi * 2

            pair[1].Position = groundPos + Vector3.new(
                math.cos(a0) * radius,
                0,
                math.sin(a0) * radius
            )

            pair[2].Position = groundPos + Vector3.new(
                math.cos(a1) * radius,
                0,
                math.sin(a1) * radius
            )
        end
    end
end

local function setParryRangeVisual(enabled)
    if not enabled then
        destroyParryRangeVisual()
        return
    end
    updateParryRangeVisual()
end

Hooks["ESP Range"] = function(value)
    Values["ESP Range"] = tonumber(value) or 600
end

Hooks["Parry Radius"] = function(value)
    Values["Parry Radius"] = math.clamp(tonumber(value) or 13, 2, 100)
    if Values["Auto Parry"] or Values["Safety Parry"] or Values["Aggressive Parry"] then
        updateParryRangeVisual()
    end
end

-- =========================================================
-- MOVEMENT / CAMERA / LIGHTING
-- =========================================================

Hooks["Enable Run Speed"] = function(on)
    local h = humanoid()
    if not h then return end

    if on then
        h.WalkSpeed = tonumber(Values["Speed Value"]) or 20
    else
        h.WalkSpeed = originalWalkSpeed
    end
end

Hooks["Speed Value"] = function(value)
    if not Values["Enable Run Speed"] then return end

    local h = humanoid()
    if h then
        h.WalkSpeed = tonumber(value) or 20
    end
end

Hooks["Unlimited Zoom"] = function(on)
    player.CameraMaxZoomDistance = on and 1000 or 128
end

Hooks["Auto Sprint Mobile"] = function(on)
    local h = humanoid()
    if not h then return end

    -- Developer/test behavior: keep sprint state local and restore the
    -- original WalkSpeed when disabled. Server-side movement validation
    -- remains authoritative.
    if on then
        if Values["SpeedBoost"] then
            h.WalkSpeed = tonumber(Values["Speed Boost Value"]) or h.WalkSpeed
        else
            h.WalkSpeed = math.max(h.WalkSpeed, 20)
        end
    else
        h.WalkSpeed = originalWalkSpeed
    end
end


Hooks["Custom FOV"] = function(on)
    camera = workspace.CurrentCamera or camera
    if not camera then return end

    if on then
        camera.FieldOfView = tonumber(Values["Field of View"]) or 70
    else
        camera.FieldOfView = originalFOV
    end
end

Hooks["Field of View"] = function(value)
    if not Values["Custom FOV"] then return end

    camera = workspace.CurrentCamera or camera
    if camera then
        camera.FieldOfView = tonumber(value) or 70
    end
end

Hooks["Full Bright"] = function(on)
    if on then
        Lighting.Brightness = 2
        Lighting.ClockTime = 14
    else
        Lighting.Brightness = originalLighting.Brightness
        Lighting.ClockTime = originalLighting.ClockTime
    end
end

Hooks["No Fog"] = function(on)
    if on then
        Lighting.FogStart = 0
        Lighting.FogEnd = 1000000
    else
        Lighting.FogStart = originalLighting.FogStart
        Lighting.FogEnd = originalLighting.FogEnd
    end
end

Hooks["Disable Shadows"] = function(on)
    Lighting.GlobalShadows = not on
end

Hooks["No Clip"] = function(on)
    if not on then return end

    FeatureManager:Connect("No Clip", RunService.Stepped, function()
        local c = character()
        if not c then return end

        for _, part in ipairs(c:GetDescendants()) do
            if part:IsA("BasePart") then
                part.CanCollide = false
            end
        end
    end)
end

Hooks["Disable Particles"] = function(on)
    if on then
        particleCache = {}

        for _, object in ipairs(workspace:GetDescendants()) do
            if object:IsA("ParticleEmitter")
                or object:IsA("Trail")
                or object:IsA("Beam") then

                particleCache[object] = object.Enabled
                object.Enabled = false
            end
        end
    else
        for object, state in pairs(particleCache) do
            if object and object.Parent then
                object.Enabled = state
            end
        end

        particleCache = {}
    end
end

Hooks["Lower Graphics"] = function(on)
    if not on then return end

    pcall(function()
        settings().Rendering.QualityLevel = Enum.QualityLevel.Level01
    end)
end

Hooks["FPS Unlocker"] = function()
    -- Roblox client mengontrol frame cap.
end

Hooks["FPS Cap Value"] = function()
    -- Disimpan sebagai setting GUI.
end

-- =========================================================
-- FPS COUNTER
-- =========================================================

local fpsFrames = 0
local fpsTime = 0

Hooks["FPS Counter"] = function(on)
    if on then
        if fpsLabel then
            fpsLabel:Destroy()
            fpsLabel = nil
        end

        fpsLabel = new("TextLabel", {
            Name = "FPSCounter",
            Text = "FPS: --",
            Font = Enum.Font.GothamBold,
            TextSize = 14,
            TextColor3 = TEXT,
            BackgroundColor3 = PANEL,
            BackgroundTransparency = 0.2,
            Size = UDim2.fromOffset(100, 28),
            Position = UDim2.fromOffset(8, 8),
            ZIndex = 100
        }, gui)
        corner(fpsLabel, 6)

        fpsFrames = 0
        fpsTime = 0

        FeatureManager:Connect("FPS Counter", RunService.RenderStepped, function(dt)
            if not fpsLabel then return end

            fpsFrames += 1
            fpsTime += dt

            if fpsTime >= 0.5 then
                fpsLabel.Text = "FPS: " .. math.floor(fpsFrames / fpsTime)
                fpsFrames = 0
                fpsTime = 0
            end
        end)
    else
        if fpsLabel then
            fpsLabel:Destroy()
            fpsLabel = nil
        end
    end
end

-- =========================================================
-- CROSSHAIR
-- =========================================================

local function destroyCrosshair()
    if crosshairGui then
        crosshairGui:Destroy()
        crosshairGui = nil
    end
end

local function makeCrosshair()
    destroyCrosshair()

    crosshairGui = new("ScreenGui", {
        Name = "AlettaCrosshair",
        ResetOnSpawn = false,
        IgnoreGuiInset = true,
        ZIndexBehavior = Enum.ZIndexBehavior.Global
    }, playerGui)

    local frame = new("Frame", {
        BackgroundTransparency = 1,
        Size = UDim2.fromOffset(60, 60),
        AnchorPoint = Vector2.new(0.5, 0.5),
        Position = UDim2.new(
            0.5,
            tonumber(Values["Crosshair X Offset"]) or 0,
            0.5,
            tonumber(Values["Crosshair Y Offset"]) or 0
        )
    }, crosshairGui)

    local typeName = Values["Crosshair Type"] or "Cross"
    local size = tonumber(Values["Crosshair Size"]) or 4

    local colorMap = {
        Green = Color3.fromRGB(80, 255, 120),
        Cyan = Color3.fromRGB(60, 220, 255),
        Red = Color3.fromRGB(255, 70, 70),
        Yellow = Color3.fromRGB(255, 220, 50),
        Orange = Color3.fromRGB(255, 150, 50),
        Blue = Color3.fromRGB(80, 130, 255),
        Purple = ACCENT,
        White = TEXT,
        Pink = Color3.fromRGB(255, 100, 200)
    }

    local color = colorMap[Values["Crosshair Color"]] or colorMap.Green

    if typeName == "Dot" then
        local dot = new("Frame", {
            Size = UDim2.fromOffset(size, size),
            AnchorPoint = Vector2.new(0.5, 0.5),
            Position = UDim2.fromScale(0.5, 0.5),
            BackgroundColor3 = color,
            BorderSizePixel = 0
        }, frame)
        corner(dot, size)

    elseif typeName == "Cross" then
        new("Frame", {
            Size = UDim2.fromOffset(size * 4, size),
            AnchorPoint = Vector2.new(0.5, 0.5),
            Position = UDim2.fromScale(0.5, 0.5),
            BackgroundColor3 = color,
            BorderSizePixel = 0
        }, frame)

        new("Frame", {
            Size = UDim2.fromOffset(size, size * 4),
            AnchorPoint = Vector2.new(0.5, 0.5),
            Position = UDim2.fromScale(0.5, 0.5),
            BackgroundColor3 = color,
            BorderSizePixel = 0
        }, frame)

    elseif typeName == "Circle" then
        local circle = new("Frame", {
            Size = UDim2.fromOffset(size * 8, size * 8),
            AnchorPoint = Vector2.new(0.5, 0.5),
            Position = UDim2.fromScale(0.5, 0.5),
            BackgroundTransparency = 1
        }, frame)
        corner(circle, size * 4)

        new("UIStroke", {
            Color = color,
            Thickness = math.max(1, math.floor(size / 2))
        }, circle)
    end
end

Hooks["Crosshair"] = function(on)
    if on then
        makeCrosshair()
    else
        destroyCrosshair()
    end
end

Hooks["Crosshair Type"] = function()
    if Values["Crosshair"] then makeCrosshair() end
end

Hooks["Crosshair Color"] = function()
    if Values["Crosshair"] then makeCrosshair() end
end

Hooks["Crosshair Size"] = function()
    if Values["Crosshair"] then makeCrosshair() end
end

Hooks["Crosshair X Offset"] = function()
    if Values["Crosshair"] then makeCrosshair() end
end

Hooks["Crosshair Y Offset"] = function()
    if Values["Crosshair"] then makeCrosshair() end
end

-- =========================================================
-- ALETTA AIM SYSTEM V13 - LOCAL / VERIFIED TARGETING HOOKS
-- Uses the existing game/player structure and never invents server payloads.
-- =========================================================

local AimLock = {target=nil, player=nil, position=nil, score=math.huge}
_G.AlettaAimLock = AimLock

local aimFovGui, aimFovCircle, pistolFovCircle, veilFovCircle
local aimLinePart, aimLineAttachment, aimLineTargetPart, aimLineTargetAttachment, aimLineBeam
local laserPart, laserAttachment, laserTargetPart, laserTargetAttachment, laserBeam
local targetRing
local mobileAimButton
local rmbHeld = false
local mobileAimHeld = false
local lastTOF = 0

local function aimPartFor(characterModel)
    local targetMode = Values["Target Aim"] or "Torso"
    if targetMode == "Head" then
        return characterModel:FindFirstChild("Head") or characterModel:FindFirstChild("HumanoidRootPart")
    elseif targetMode == "Legs" then
        return characterModel:FindFirstChild("LeftFoot")
            or characterModel:FindFirstChild("LeftLowerLeg")
            or characterModel:FindFirstChild("HumanoidRootPart")
    end
    return characterModel:FindFirstChild("UpperTorso")
        or characterModel:FindFirstChild("Torso")
        or characterModel:FindFirstChild("HumanoidRootPart")
end

local function hasLineOfSight(origin, part, targetCharacter)
    local params = RaycastParams.new()
    params.FilterType = Enum.RaycastFilterType.Exclude
    params.FilterDescendantsInstances = {character(), targetCharacter}
    local result = workspace:Raycast(origin, part.Position - origin, params)
    return result == nil
end

local function isKnocked(targetCharacter, targetPlayer)
    if Values["Block Aim Knocked"] ~= true then return false end
    local names = {"Knocked", "Downed", "IsKnocked", "DBNO", "InjuredDown", "Unconscious"}
    for _, n in ipairs(names) do
        local a = targetCharacter and targetCharacter:GetAttribute(n)
        local b = targetPlayer and targetPlayer:GetAttribute(n)
        if a == true or b == true then return true end
        if tostring(a):lower() == "knocked" or tostring(b):lower() == "knocked" then return true end
    end
    local h = targetCharacter and targetCharacter:FindFirstChildOfClass("Humanoid")
    if h then
        local st = tostring(h:GetState())
        if st:find("PlatformStanding") or st:find("Physics") then
            -- Do not treat every physics state as knocked; only reject if an explicit marker exists.
        end
    end
    return false
end

local function detectAimRole(targetPlayer)
    if not targetPlayer then return nil end
    local c = targetPlayer.Character
    local function norm(v)
        if v == nil then return nil end
        local t = tostring(v):lower():gsub("%s+", "")
        if t:find("killer",1,true) then return "Killer" end
        if t:find("survivor",1,true) then return "Survivor" end
        if t:find("zombie",1,true) then return "Zombie" end
        if t:find("scp",1,true) then return "SCP" end
        return nil
    end
    local candidates = {
        c and c:GetAttribute("Role"), c and c:GetAttribute("RoleName"), c and c:GetAttribute("Team"),
        targetPlayer:GetAttribute("Role"), targetPlayer:GetAttribute("RoleName"), targetPlayer:GetAttribute("Team"),
        targetPlayer.Team and targetPlayer.Team.Name
    }
    for _, v in ipairs(candidates) do
        local r = norm(v)
        if r then return r end
    end
    return nil
end

local function getAimTarget()
    camera = workspace.CurrentCamera or camera
    local myRoot = root()
    if not camera or not myRoot then return nil end

    local maxPixels = math.clamp(tonumber(Values["Pistol FOV Radius"]) or 120, 10, 600)
    if Values["Pistol FOV Mode"] ~= true and Values["Enable Aimbot"] ~= true then
        maxPixels = math.max(maxPixels, 120)
    end
    local maxWorldDistance = 500
    local targetMode = Values["Pistol Target"] or "Killer"
    local bestPart, bestPlayer, bestScore = nil, nil, math.huge
    local center = Vector2.new(camera.ViewportSize.X/2, camera.ViewportSize.Y/2)

    for _, targetPlayer in ipairs(Players:GetPlayers()) do
        if targetPlayer ~= player then
            local tc = targetPlayer.Character
            local th = tc and tc:FindFirstChildOfClass("Humanoid")
            local tr = tc and tc:FindFirstChild("HumanoidRootPart")
            if tc and th and tr and th.Health > 0 and not isKnocked(tc, targetPlayer) then
                local role = detectAimRole(targetPlayer)
                local validRole = (targetMode == "Killer" and role == "Killer")
                    or (targetMode == "Survivor" and role == "Survivor")
                    or (targetMode == "Zombie" and (role == "Zombie" or role == "SCP"))
                if validRole then
                    local part = aimPartFor(tc)
                    if part then
                        local distance = (tr.Position - myRoot.Position).Magnitude
                        local screen, onScreen = camera:WorldToViewportPoint(part.Position)
                        if onScreen and screen.Z > 0 and distance <= maxWorldDistance then
                            local score = (Vector2.new(screen.X,screen.Y)-center).Magnitude
                            if score <= maxPixels and score < bestScore and hasLineOfSight(camera.CFrame.Position,part,tc) then
                                bestPart, bestPlayer, bestScore = part, targetPlayer, score
                            end
                        end
                    end
                end
            end
        end
    end
    return bestPart, bestPlayer, bestScore
end

local function predictedPosition(part, smart, leadOverride)
    if not part then return nil end
    local velocity = part.AssemblyLinearVelocity or Vector3.zero
    local lead = leadOverride
    if lead == nil then
        lead = math.clamp((tonumber(Values["Prediction"]) or 35) / 100, 0, 1.5)
    end
    if smart then
        local rootPart = part.Parent and part.Parent:FindFirstChild("HumanoidRootPart")
        local origin = rootPart and rootPart.Position or (camera and camera.CFrame.Position) or part.Position
        local speed = math.max((camera and (part.Position-origin).Magnitude or 0) / math.max(lead,0.05), 1)
        lead = math.clamp((part.Position-origin).Magnitude / speed * (tonumber(Values["Smart Predict Lead"]) or 17) / 100, 0, 1.5)
    end
    return part.Position + velocity * lead
end

local function refreshAimLock()
    local part, plr, score = getAimTarget()
    AimLock.target, AimLock.player, AimLock.score = part, plr, score or math.huge
    AimLock.position = part and predictedPosition(part, false) or nil
    return part, plr
end

function AimLock.GetTarget()
    local target = AimLock.target
    if target and target.Parent then
        local h = target.Parent:FindFirstChildOfClass("Humanoid")
        if h and h.Health > 0 and not isKnocked(target.Parent, AimLock.player) then return target end
    end
    return nil
end
function AimLock.Clear() AimLock.target=nil AimLock.player=nil AimLock.position=nil end

local function destroyAimVisuals()
    if aimFovGui then pcall(function() aimFovGui:Destroy() end) end
    aimFovGui, aimFovCircle, pistolFovCircle, veilFovCircle = nil,nil,nil,nil
    if targetRing then pcall(function() targetRing:Destroy() end) end
    targetRing=nil
end

local function makeCircle(parent,name)
    local f=Instance.new("Frame")
    f.Name=name; f.AnchorPoint=Vector2.new(.5,.5); f.BackgroundTransparency=1
    f.Position=UDim2.fromScale(.5,.5); f.Parent=parent
    local st=Instance.new("UIStroke"); st.Color=ACCENT; st.Thickness=2; st.Parent=f
    local cr=Instance.new("UICorner"); cr.CornerRadius=UDim.new(1,0); cr.Parent=f
    return f
end

local function updateAimFov()
    local need = Values["Show FOV Circle"] or Values["Pistol Show FOV"] or Values["Veil Show FOV"]
    if not need then destroyAimVisuals(); return end
    if not aimFovGui or not aimFovGui.Parent then
        aimFovGui=Instance.new("ScreenGui"); aimFovGui.Name="AlettaAimFOV"; aimFovGui.IgnoreGuiInset=true; aimFovGui.ResetOnSpawn=false; aimFovGui.Parent=playerGui
    end
    if Values["Show FOV Circle"] and not aimFovCircle then aimFovCircle=makeCircle(aimFovGui,"AimbotFOV") end
    if not Values["Show FOV Circle"] and aimFovCircle then aimFovCircle:Destroy(); aimFovCircle=nil end
    if Values["Pistol Show FOV"] and not pistolFovCircle then pistolFovCircle=makeCircle(aimFovGui,"PistolFOV") end
    if not Values["Pistol Show FOV"] and pistolFovCircle then pistolFovCircle:Destroy(); pistolFovCircle=nil end
    if Values["Veil Show FOV"] and not veilFovCircle then veilFovCircle=makeCircle(aimFovGui,"VeilFOV") end
    if not Values["Veil Show FOV"] and veilFovCircle then veilFovCircle:Destroy(); veilFovCircle=nil end
    local ar=math.clamp(tonumber(Values["FOV Radius (pixels)"]) or 120,10,600)
    local pr=math.clamp(tonumber(Values["Pistol FOV Radius"]) or 120,10,600)
    local vr=math.clamp(tonumber(Values["Veil FOV Radius"]) or 120,10,600)
    if aimFovCircle then aimFovCircle.Size=UDim2.fromOffset(ar*2,ar*2) end
    if pistolFovCircle then pistolFovCircle.Size=UDim2.fromOffset(pr*2,pr*2) end
    if veilFovCircle then veilFovCircle.Size=UDim2.fromOffset(vr*2,vr*2) end
end

local function destroyBeam(kind)
    if kind=="aim" then
        if aimLineBeam then pcall(function() aimLineBeam:Destroy() end) end
        if aimLinePart then pcall(function() aimLinePart:Destroy() end) end
        if aimLineTargetPart then pcall(function() aimLineTargetPart:Destroy() end) end
        aimLineBeam,aimLinePart,aimLineTargetPart=nil,nil,nil
    else
        if laserBeam then pcall(function() laserBeam:Destroy() end) end
        if laserPart then pcall(function() laserPart:Destroy() end) end
        if laserTargetPart then pcall(function() laserTargetPart:Destroy() end) end
        laserBeam,laserPart,laserTargetPart=nil,nil,nil
    end
end

local function makeBeam(kind)
    local isAim=kind=="aim"
    local beam=isAim and aimLineBeam or laserBeam
    if beam and beam.Parent then return beam end
    local a=Instance.new("Part"); a.Name=isAim and "AlettaAimOrigin" or "AlettaLaserOrigin"; a.Anchored=true; a.CanCollide=false; a.CanTouch=false; a.CanQuery=false; a.Transparency=1; a.Size=Vector3.new(.1,.1,.1); a.Parent=workspace
    local b=Instance.new("Part"); b.Name=isAim and "AlettaAimTarget" or "AlettaLaserTarget"; b.Anchored=true; b.CanCollide=false; b.CanTouch=false; b.CanQuery=false; b.Transparency=1; b.Size=Vector3.new(.1,.1,.1); b.Parent=workspace
    local aa=Instance.new("Attachment"); aa.Parent=a
    local ab=Instance.new("Attachment"); ab.Parent=b
    local bm=Instance.new("Beam"); bm.Attachment0=aa; bm.Attachment1=ab; bm.FaceCamera=true; bm.Width0=.035; bm.Width1=.035; bm.LightEmission=1; bm.Color=ColorSequence.new(ACCENT); bm.Transparency=NumberSequence.new(.1); bm.Parent=a
    if isAim then aimLinePart,aimLineAttachment,aimLineTargetPart,aimLineTargetAttachment,aimLineBeam=a,aa,b,ab,bm else laserPart,laserAttachment,laserTargetPart,laserTargetAttachment,laserBeam=a,aa,b,ab,bm end
    return bm
end

local function update3DVisuals(part)
    if not part then
        if not Values["Show Aim Line (3D)"] then destroyBeam("aim") end
        if not Values["Show Laser"] then destroyBeam("laser") end
        if targetRing then targetRing.Enabled=false end
        return
    end
    local pos=predictedPosition(part,Values["Smart Predict Mode"] and Values["Veil"])
    camera=workspace.CurrentCamera or camera
    if not camera or not pos then return end
    if Values["Show Aim Line (3D)"] then
        makeBeam("aim"); aimLinePart.CFrame=CFrame.new(camera.CFrame.Position); aimLineTargetPart.CFrame=CFrame.new(pos)
    else destroyBeam("aim") end
    if Values["Pistol"] and Values["Show Laser"] then
        makeBeam("laser"); laserPart.CFrame=CFrame.new(camera.CFrame.Position); laserTargetPart.CFrame=CFrame.new(pos)
    else destroyBeam("laser") end
end

local function updateTargetRing(part)
    if not Values["Tampilkan Jarak Senter (Ring)"] or not part then
        if targetRing then targetRing.Enabled=false end
        return
    end
    if not targetRing then
        targetRing=Instance.new("CylinderHandleAdornment"); targetRing.Name="AlettaFlashlightRangeRing"; targetRing.Color3=ACCENT; targetRing.Transparency=.45; targetRing.AlwaysOnTop=true; targetRing.Height=.12; targetRing.Radius=5; targetRing.Adornee=part; targetRing.Parent=part
    end
    targetRing.Adornee=part; targetRing.Radius=5; targetRing.Enabled=true
end

local function playTOF(part)
    if not Values["Sound TOF"] or not part or os.clock()-lastTOF<.12 then return end
    lastTOF=os.clock()
    local tool=character() and character():FindFirstChildOfClass("Tool")
    local sound=tool and tool:FindFirstChildWhichIsA("Sound",true)
    if sound then pcall(function() sound:Play() end) end
end

local function updateMobileAimButton()
    if not Values["Show Mobile Target Shortcut"] then
        if mobileAimButton then mobileAimButton.Visible=false end
        return
    end
    if not mobileAimButton then
        mobileAimButton=Instance.new("TextButton")
        mobileAimButton.Name="AlettaMobileTargetShortcut"; mobileAimButton.Size=UDim2.fromOffset(150,42); mobileAimButton.Position=UDim2.new(1,-165,1,-70)
        mobileAimButton.BackgroundColor3=PANEL; mobileAimButton.TextColor3=TEXT; mobileAimButton.Text="TARGET AIM: OFF"; mobileAimButton.TextSize=14; mobileAimButton.AutoButtonColor=true; mobileAimButton.Parent=playerGui
        local c=Instance.new("UICorner"); c.CornerRadius=UDim.new(0,10); c.Parent=mobileAimButton
        local s=Instance.new("UIStroke"); s.Color=ACCENT; s.Parent=mobileAimButton
        mobileAimButton.Activated:Connect(function()
            mobileAimHeld=not mobileAimHeld
            mobileAimButton.Text=mobileAimHeld and "TARGET AIM: ON" or "TARGET AIM: OFF"
        end)
    end
    mobileAimButton.Visible=true
end

Hooks["Enable Aimbot"] = function(on)
    disconnectList("Aimbot Runtime")
    updateAimFov()
    if not on then return end
    FeatureManager:Connect("Aimbot Runtime",RunService.RenderStepped,function()
        if Values["Hold RMB to Aim"] and not rmbHeld and not mobileAimHeld then return end
        local part=refreshAimLock()
        if part then
            local pos=predictedPosition(part,false)
            if pos and camera then camera.CFrame=CFrame.lookAt(camera.CFrame.Position,pos) end
            update3DVisuals(part); updateTargetRing(part); playTOF(part)
        end
    end)
end

Hooks["Hold RMB to Aim"] = function(on)
    Values["Hold RMB to Aim"]=on==true
end
Hooks["Show FOV Circle"] = function(on) Values["Show FOV Circle"]=on==true; updateAimFov() end
Hooks["FOV Radius (pixels)"] = function(v) Values["FOV Radius (pixels)"]=math.clamp(tonumber(v) or 120,10,600); updateAimFov() end
Hooks["Pistol Show FOV"] = function(on) Values["Pistol Show FOV"]=on==true; updateAimFov() end
Hooks["Pistol FOV Radius"] = function(v) Values["Pistol FOV Radius"]=math.clamp(tonumber(v) or 120,10,600); updateAimFov() end
Hooks["Tampilkan Jarak Senter (Ring)"] = function() end
Hooks["Show Aim Line (3D)"] = function(on) if not on then destroyBeam("aim") end end
Hooks["Show Laser"] = function(on) if not on then destroyBeam("laser") end end
Hooks["Pistol FOV Mode"] = function() updateAimFov() end
Hooks["Pistol Target"] = function() end
Hooks["Block Aim Knocked"] = function() end
Hooks["Prediction"] = function(v) Values["Prediction"]=math.clamp(tonumber(v) or 35,0,150) end

Hooks["Pistol"] = function(on)
    disconnectList("Pistol Runtime")
    updateAimFov(); updateMobileAimButton()
    if not on then destroyBeam("laser"); return end
    FeatureManager:Connect("Pistol Runtime",RunService.RenderStepped,function()
        local part=refreshAimLock()
        if part then
            local pos=predictedPosition(part,false)
            if pos and camera then camera.CFrame=CFrame.lookAt(camera.CFrame.Position,pos) end
            update3DVisuals(part); updateTargetRing(part); playTOF(part)
        end
    end)
end

Hooks["Aim Lock"] = function(on)
    disconnectList("Aim Lock Runtime")
    if not on then AimLock.Clear(); return end
    FeatureManager:Connect("Aim Lock Runtime",RunService.RenderStepped,function() refreshAimLock() end)
end

Hooks["Auto Prediksi"] = function(on)
    disconnectList("Auto Prediksi Runtime")
    if not on then return end
    FeatureManager:Connect("Auto Prediksi Runtime",RunService.RenderStepped,function()
        local part=refreshAimLock()
        if part and camera then
            local pos=predictedPosition(part,false)
            if pos then camera.CFrame=CFrame.lookAt(camera.CFrame.Position,pos) end
        end
    end)
end

Hooks["Auto Aim Senter ke Killer"] = function(on)
    disconnectList("Flashlight Aim")
    if not on then return end
    FeatureManager:Connect("Flashlight Aim",RunService.RenderStepped,function()
        local old=Values["Pistol Target"]; Values["Pistol Target"]="Killer"
        local part=refreshAimLock()
        Values["Pistol Target"]=old
        if part and camera then
            local pos=predictedPosition(part,false)
            if pos then camera.CFrame=CFrame.lookAt(camera.CFrame.Position,pos) end
            updateTargetRing(part); playTOF(part)
        end
    end)
end

Hooks["Silent Flask (The Cure)"] = function(on)
    disconnectList("Silent Flask")
    if not on then return end
    FeatureManager:Connect("Silent Flask",RunService.RenderStepped,function()
        local tool=character() and character():FindFirstChildOfClass("Tool")
        if not tool then return end
        local n=tool.Name:lower()
        if not (n:find("cure",1,true) or n:find("flash",1,true) or n:find("flask",1,true)) then return end
        for _,d in ipairs(tool:GetDescendants()) do
            if d:IsA("Sound") then d.Volume=0 end
        end
        local old=Values["Pistol Target"]; Values["Pistol Target"]="Killer"
        local part=refreshAimLock(); Values["Pistol Target"]=old
        if part and camera then camera.CFrame=CFrame.lookAt(camera.CFrame.Position,part.Position) end
    end)
end

Hooks["Show Mobile Target Shortcut"] = function() updateMobileAimButton() end

UIS.InputBegan:Connect(function(input,processed)
    if processed then return end
    if input.UserInputType==Enum.UserInputType.MouseButton2 then rmbHeld=true end
    if input.UserInputType==Enum.UserInputType.Keyboard and input.KeyCode==(Values["Mobile Target Shortcut Key"] or Enum.KeyCode.T) then
        if Values["Show Mobile Target Shortcut"] then mobileAimHeld=not mobileAimHeld end
    end
end)
UIS.InputEnded:Connect(function(input)
    if input.UserInputType==Enum.UserInputType.MouseButton2 then rmbHeld=false end
end)

-- =========================================================
-- END AIM SYSTEM
-- =========================================================

-- =========================================================
-- KILLER PREDICTION PANEL
-- =========================================================
local killerPredGui, killerPredLabel
local function updateKillerPrediction()
    if not Values["Predict Killer"] then
        if killerPredGui then killerPredGui.Enabled=false end
        return
    end
    if not killerPredGui then
        killerPredGui=Instance.new("ScreenGui"); killerPredGui.Name="AlettaKillerPrediction"; killerPredGui.IgnoreGuiInset=true; killerPredGui.ResetOnSpawn=false; killerPredGui.Parent=playerGui
        local box=Instance.new("Frame"); box.Size=UDim2.fromOffset(270,54); box.Position=UDim2.new(1,-285,0,86); box.BackgroundColor3=Color3.fromRGB(25,10,30); box.BackgroundTransparency=.15; box.Parent=killerPredGui
        local cr=Instance.new("UICorner"); cr.CornerRadius=UDim.new(0,8); cr.Parent=box
        local st=Instance.new("UIStroke"); st.Color=Color3.fromRGB(255,70,70); st.Thickness=2; st.Parent=box
        killerPredLabel=Instance.new("TextLabel"); killerPredLabel.Size=UDim2.new(1,-12,1,-8); killerPredLabel.Position=UDim2.fromOffset(6,4); killerPredLabel.BackgroundTransparency=1; killerPredLabel.TextColor3=TEXT; killerPredLabel.Font=Enum.Font.GothamBold; killerPredLabel.TextSize=13; killerPredLabel.TextXAlignment=Enum.TextXAlignment.Left; killerPredLabel.TextWrapped=true; killerPredLabel.Parent=box
    end
    killerPredGui.Enabled=true
    local names={}
    for _,p in ipairs(Players:GetPlayers()) do
        if p~=player then
            local c=p.Character
            local role=(c and (c:GetAttribute("Role") or c:GetAttribute("RoleName"))) or p:GetAttribute("Role") or p:GetAttribute("RoleName")
            if typeof(role)=="string" and string.lower(role):find("killer") then table.insert(names,p.DisplayName) end
        end
    end
    if #names>0 then killerPredLabel.Text="KILLER PREDICTION\n"..table.concat(names,", ") else killerPredLabel.Text="KILLER PREDICTION\nMenunggu role killer..." end
end
Hooks["Predict Killer"] = function(on)
    Values["Predict Killer"]=on==true
    disconnectList("Killer Prediction")
    if not on then updateKillerPrediction(); return end
    updateKillerPrediction()
    FeatureManager:Connect("Killer Prediction", RunService.Heartbeat, function()
        updateKillerPrediction()
    end)
end
Hooks["Killer Prediction Mode"] = function(v) Values["Killer Prediction Mode"]=tostring(v or "Detected Role") end

-- =========================================================
-- TOF SOUND SET
-- =========================================================

local TOF_SOUND_IDS = {
    ["Sound 1"] = "rbxassetid://139664063118995",
    ["Sound 2"] = "rbxassetid://115463636107842",
    ["Sound 3"] = "rbxassetid://133644366455575",
    ["Sound 4"] = "rbxassetid://114932123071822",
    ["Sound 5"] = "rbxassetid://83971611350325",
}

local tofSound

local function playTOFSound()
    local selected = Values["Pilih Sound"] or "Sound 1"
    local soundId = TOF_SOUND_IDS[selected] or TOF_SOUND_IDS["Sound 1"]

    if not tofSound or not tofSound.Parent then
        tofSound = Instance.new("Sound")
        tofSound.Name = "AlettaTOFSound"
        tofSound.Volume = 1
        tofSound.Parent = SoundService
    end

    tofSound.SoundId = soundId
    tofSound.TimePosition = 0
    task.spawn(function()
        pcall(function()
            ContentProvider:PreloadAsync({tofSound})
        end)
        pcall(function()
            tofSound:Play()
        end)
    end)
end

Hooks["Pilih Sound"] = function(value)
    Values["Pilih Sound"] = tostring(value or "Sound 1")
    if Values["Sound TOF"] then
        playTOFSound()
    end
end

Hooks["Sound TOF"] = function(on)
    Values["Sound TOF"] = on == true
    if Values["Sound TOF"] then
        playTOFSound()
    elseif tofSound then
        pcall(function() tofSound:Stop() end)
    end
end

-- =========================================================
-- ANTI AFK / SERVER
-- =========================================================

Hooks["Stay Active (Anti AFK)"] = function(on)
    if not on then return end

    FeatureManager:Connect("Stay Active (Anti AFK)", player.Idled, function()
        pcall(function()
            VirtualUser:CaptureController()
            VirtualUser:ClickButton2(Vector2.new())
        end)
    end)
end

Hooks["Rejoin Server"] = function()
    pcall(function()
        TeleportService:Teleport(game.PlaceId, player)
    end)
end

local sessionConfigs = {}
local autoloadConfig = nil

local colorPresets = {
    Black = Color3.fromRGB(8, 8, 10),
    ["Dark Purple"] = Color3.fromRGB(18, 10, 30),
    Purple = Color3.fromRGB(70, 35, 110),
    Violet = Color3.fromRGB(105, 55, 170),
    Blue = Color3.fromRGB(35, 90, 180),
    ["Dark Blue"] = Color3.fromRGB(18, 30, 60),
    Navy = Color3.fromRGB(15, 25, 45),
    ["Dark Gray"] = Color3.fromRGB(28, 28, 32),
    Cyan = Color3.fromRGB(30, 180, 200),
    Pink = Color3.fromRGB(220, 80, 180),
    Red = Color3.fromRGB(210, 60, 70),
    Green = Color3.fromRGB(65, 190, 100),
    Orange = Color3.fromRGB(230, 135, 45),
    Yellow = Color3.fromRGB(230, 200, 55),
    White = Color3.fromRGB(245, 245, 245),
    ["Light Gray"] = Color3.fromRGB(205, 205, 210),
    Gray = Color3.fromRGB(155, 155, 160),
}

local themePresets = {
    ["PURPLE"]  = {main=Color3.fromRGB(95,45,180),  accent=Color3.fromRGB(180,90,255),  outline=Color3.fromRGB(225,205,255), font=Color3.fromRGB(255,255,255), background=Color3.fromRGB(15,8,25), asset="rbxassetid://94003702624009"},
    ["PINK"]    = {main=Color3.fromRGB(145,45,105), accent=Color3.fromRGB(255,95,190),  outline=Color3.fromRGB(255,205,235), font=Color3.fromRGB(255,255,255), background=Color3.fromRGB(25,8,18), asset="rbxassetid://115489304339560"},
    ["YELLOW"]  = {main=Color3.fromRGB(145,105,25), accent=Color3.fromRGB(255,215,70),  outline=Color3.fromRGB(255,240,170), font=Color3.fromRGB(255,255,255), background=Color3.fromRGB(25,20,7), asset="rbxassetid://98915755062432"},
    ["GREEN"]   = {main=Color3.fromRGB(35,120,65),  accent=Color3.fromRGB(90,230,130),  outline=Color3.fromRGB(195,255,215), font=Color3.fromRGB(255,255,255), background=Color3.fromRGB(7,22,12), asset="rbxassetid://82044886382201"},
    ["GOLD"]    = {main=Color3.fromRGB(135,90,18),  accent=Color3.fromRGB(255,190,55),  outline=Color3.fromRGB(255,225,150), font=Color3.fromRGB(255,255,255), background=Color3.fromRGB(24,16,5), asset="rbxassetid://98915755062432"},
    ["RED"]     = {main=Color3.fromRGB(135,30,40),  accent=Color3.fromRGB(255,70,80),   outline=Color3.fromRGB(255,190,195), font=Color3.fromRGB(255,255,255), background=Color3.fromRGB(24,7,9), asset="rbxassetid://127084129735969"},
    ["BLUE"]    = {main=Color3.fromRGB(35,80,155),  accent=Color3.fromRGB(75,165,255),  outline=Color3.fromRGB(195,225,255), font=Color3.fromRGB(255,255,255), background=Color3.fromRGB(7,13,25), asset="rbxassetid://79416721033325"},
    ["SILVER"]  = {main=Color3.fromRGB(90,95,105),  accent=Color3.fromRGB(205,215,230), outline=Color3.fromRGB(245,248,255), font=Color3.fromRGB(255,255,255), background=Color3.fromRGB(16,17,20), asset="rbxassetid://125312830368472"},
    ["ORANGE"]  = {main=Color3.fromRGB(150,70,20),  accent=Color3.fromRGB(255,145,55),  outline=Color3.fromRGB(255,220,185), font=Color3.fromRGB(255,255,255), background=Color3.fromRGB(25,11,5), asset="rbxassetid://96825895417750"},
    ["RAIMBOW"] = {main=Color3.fromRGB(95,45,180),  accent=Color3.fromRGB(255,95,190),  outline=Color3.fromRGB(235,235,255), font=Color3.fromRGB(255,255,255), background=Color3.fromRGB(15,10,25), asset="rbxassetid://89672943739008"},
}

local fontMap = {
    Fantast = Enum.Font.Fantasy,
    Goth = Enum.Font.Gotham,
    Jura = Enum.Font.Gotham,
    Roboto = Enum.Font.Gotham,
    RobotoMono = Enum.Font.Code,
    SourceSans = Enum.Font.SourceSans,
}

local function applyConfigVisuals()
    local oldPanel = PANEL
    local oldField = FIELD
    local oldAccent = ACCENT
    local oldBG = BG

    local mainName = Values["Main Color Value"] or "Purple"
    local accentName = Values["Accent Color Value"] or "Purple"
    local outlineName = Values["Outline Color Value"] or "White"
    local fontName = Values["Font Color Value"] or "White"
    local bgName = Values["Background Color Value"] or "Dark Purple"

    local selectedTheme = themePresets[Values["Theme List"] or "PURPLE"]
    local mainColor = (selectedTheme and selectedTheme.main) or colorPresets[mainName] or ACCENT
    local accentColor = (selectedTheme and selectedTheme.accent) or colorPresets[accentName] or ACCENT
    local outlineColor = (selectedTheme and selectedTheme.outline) or colorPresets[outlineName] or Color3.new(1,1,1)
    local fontColor = (selectedTheme and selectedTheme.font) or colorPresets[fontName] or TEXT
    local bgColor = (selectedTheme and selectedTheme.background) or colorPresets[bgName] or BG

    if Values["Main Color"] ~= false then
        ACCENT = mainColor
        PANEL = mainColor:Lerp(Color3.new(0,0,0), 0.55)
        FIELD = mainColor:Lerp(Color3.new(0,0,0), 0.25)
    end
    if Values["Accent Color"] ~= false then
        ACCENT = accentColor
    end
    if Values["Background Color"] ~= false then
        BG = bgColor
    end

    window.BackgroundColor3 = BG
    wStroke.Color = Values["Outline Color"] == false and Color3.new(1,1,1) or outlineColor
    if bgDark then bgDark.BackgroundColor3 = BG:Lerp(Color3.new(0,0,0), 0.65) end
    if logoBadge then
        local stroke = logoBadge:FindFirstChildOfClass("UIStroke")
        if stroke then stroke.Color = ACCENT end
    end
    if iconStroke then iconStroke.Color = outlineColor end

    local selectedThemeName = Values["Theme List"] or "PURPLE"
    local selectedTheme = themePresets[selectedThemeName]
    if selectedTheme and selectedTheme.asset then
        -- header notice is text-only; no image asset
        icon.Image = selectedTheme.asset
    else
        -- header notice is text-only; no image asset
        icon.Image = LOGO_ID
    end

    for _, obj in ipairs(window:GetDescendants()) do
        if obj:IsA("TextLabel") or obj:IsA("TextButton") or obj:IsA("TextBox") then
            if obj.TextColor3 == TEXT or obj.TextColor3 == Color3.fromRGB(220,220,220) then
                obj.TextColor3 = fontColor
            end
        end
    end

    -- Repaint fixed/hard-coded GUI surfaces so theme changes are global.
    for _, obj in ipairs(window:GetDescendants()) do
        if obj:IsA("GuiObject") and obj.BackgroundTransparency < 1 then
            local n = string.lower(obj.Name or "")
            local isBackground = obj == bgImg or obj == bgDark or obj == headerBar or obj == headerBarShade
            if not isBackground then
                local c = obj.BackgroundColor3
                local maxc = math.max(c.R, c.G, c.B)
                local minc = math.min(c.R, c.G, c.B)
                local sat = maxc > 0 and ((maxc - minc) / maxc) or 0
                if obj:IsA("TextButton") or obj:IsA("ImageButton") then
                    -- Controls use the theme panel by default; active states are recolored by their handlers.
                    obj.BackgroundColor3 = PANEL
                elseif obj:IsA("ScrollingFrame") then
                    obj.BackgroundColor3 = PANEL
                elseif obj:IsA("Frame") then
                    -- Keep very bright accent-like surfaces as accents; dark neutral surfaces become themed panels.
                    if sat > 0.30 and maxc > 0.35 then
                        obj.BackgroundColor3 = ACCENT
                    elseif maxc < 0.35 or sat < 0.18 then
                        obj.BackgroundColor3 = FIELD
                    else
                        obj.BackgroundColor3 = PANEL
                    end
                end
            end
        end
    end

    -- Force every visible stroke/gradient in the GUI to follow the selected theme.
    for _, obj in ipairs(window:GetDescendants()) do
        if obj:IsA("UIStroke") then
            obj.Color = outlineColor
        elseif obj:IsA("UIGradient") and obj.Parent and obj.Parent:IsA("UIStroke") then
            obj.Color = ColorSequence.new({
                ColorSequenceKeypoint.new(0, outlineColor),
                ColorSequenceKeypoint.new(0.5, accentColor),
                ColorSequenceKeypoint.new(1, mainColor)
            })
        end
    end
    headerStroke.Color = outlineColor
    wStroke.Color = outlineColor

    local face = fontMap[Values["Font Face"] or "Roboto"] or Enum.Font.Gotham
    for _, obj in ipairs(window:GetDescendants()) do
        if obj:IsA("TextLabel") or obj:IsA("TextButton") or obj:IsA("TextBox") then
            obj.Font = face
        end
    end

    for _, obj in ipairs(cornerObjects) do
        if obj and obj.Parent then
            obj.CornerRadius = UDim.new(0, math.clamp(tonumber(Values["Corner Radius"]) or 10, 0, 20))
        end
    end

    for _, obj in ipairs(window:GetDescendants()) do
        if obj:IsA("GuiObject") then
            -- Recolor existing panels/fields created with the previous theme.
            if obj.BackgroundTransparency < 1 then
                if obj.BackgroundColor3 == oldPanel then
                    obj.BackgroundColor3 = PANEL
                elseif obj.BackgroundColor3 == oldField then
                    obj.BackgroundColor3 = FIELD
                elseif obj.BackgroundColor3 == oldAccent then
                    obj.BackgroundColor3 = ACCENT
                elseif obj.BackgroundColor3 == oldBG then
                    obj.BackgroundColor3 = BG
                end
            end

            if obj:IsA("ScrollingFrame") then
                obj.ScrollBarImageColor3 = ACCENT
            end
        end
    end

    -- Theme background: use the theme asset when one exists; PURPLE uses a clean tinted fill.
    if selectedTheme and selectedTheme.asset and selectedTheme.asset ~= "" then
        bgImg.Image = selectedTheme.asset
        bgImg.ImageTransparency = 0.16
    else
        bgImg.Image = ""
        bgImg.ImageTransparency = 1
    end
    bgDark.BackgroundColor3 = BG:Lerp(Color3.new(0,0,0), 0.58)

    -- Header follows the active theme completely.
    headerBar.BackgroundColor3 = PANEL
    headerStroke.Color = outlineColor
    local activeThemeAsset = selectedTheme and selectedTheme.asset or LOGO_ID
    if headerACLeft:IsA("ImageLabel") then headerACLeft.Image = activeThemeAsset end
    if headerACRight:IsA("ImageLabel") then headerACRight.Image = activeThemeAsset end
    headerLogo.TextColor3 = fontColor
    headerWarning.TextColor3 = outlineColor:Lerp(fontColor, 0.35)
    headerBarShade.BackgroundColor3 = BG:Lerp(Color3.new(0,0,0), 0.25)

    headerTitle.TextColor3 = fontColor
    headerSubtitle.TextColor3 = outlineColor:Lerp(fontColor, 0.25)
    headerRightTitle.TextColor3 = fontColor
    headerRightSubtitle.TextColor3 = outlineColor:Lerp(fontColor, 0.25)

    -- Gradient stroke follows the active theme instead of staying purple.
    local c1 = outlineColor
    local c2 = accentColor
    local c3 = mainColor
    if wGradient then
        wGradient.Color = ColorSequence.new({
            ColorSequenceKeypoint.new(0, c1),
            ColorSequenceKeypoint.new(0.5, c2),
            ColorSequenceKeypoint.new(1, c3)
        })
    end
    if iconGradient then
        iconGradient.Color = ColorSequence.new({
            ColorSequenceKeypoint.new(0, c1),
            ColorSequenceKeypoint.new(0.5, c2),
            ColorSequenceKeypoint.new(1, c3)
        })
    end
end

Hooks["Corner Radius"] = function(value)
    Values["Corner Radius"] = math.clamp(tonumber(value) or 10, 0, 20)
    applyConfigVisuals()
end

Hooks["Custom Cursor"] = function(on)
    pcall(function()
        UIS.MouseIconEnabled = not on
    end)
end

Hooks["Lock GUI"] = function(on)
    Values["Lock GUI"] = on == true
end

Hooks["Menu Bind"] = function(value)
    Values["Menu Bind"] = typeof(value) == "EnumItem" and value or (Enum.KeyCode[tostring(value)] or Enum.KeyCode.RightShift)
end

local function themeValue(name)
    return colorPresets[name] or ACCENT
end

for _, key in ipairs({"Background Color Value", "Main Color Value", "Accent Color Value", "Outline Color Value", "Font Color Value", "Font Face"}) do
    Hooks[key] = function() applyConfigVisuals() end
end

Hooks["Theme List"] = function(theme)
    local t = themePresets[theme]
    if not t then return end

    -- Tema memilih warna GUI + asset logo secara otomatis.
    Values["Theme List"] = theme

    -- Matikan override manual supaya tema benar-benar mengikuti preset.
    Values["Background Color"] = true
    Values["Main Color"] = true
    Values["Accent Color"] = true
    Values["Outline Color"] = true
    Values["Font Color"] = true

    -- Simpan warna preset sebagai nilai Color3 khusus tema.
    Values["_ThemeMainColor"] = t.main
    Values["_ThemeAccentColor"] = t.accent
    Values["_ThemeOutlineColor"] = t.outline
    Values["_ThemeFontColor"] = t.font
    Values["_ThemeBackgroundColor"] = t.background
    Values["_ThemeAsset"] = t.asset

    ACCENT = t.accent
    PANEL = t.main:Lerp(Color3.new(0,0,0), 0.55)
    FIELD = t.main:Lerp(Color3.new(0,0,0), 0.25)
    BG = t.background

    if icon then icon.Image = t.asset or "" end
    if bgImg then bgImg.Image = t.asset or "" end

    applyConfigVisuals()
end

local CONFIG_FILE = "AlettaCreator_Config.json"
local function canFileRead() return type(readfile)=="function" and type(isfile)=="function" end
local function canFileWrite() return type(writefile)=="function" end
local function encodeValue(v)
    local tv=typeof(v)
    if tv=="EnumItem" then return {__enum=tostring(v.EnumType),name=v.Name}
    if tv=="Color3" then return {__color3=true,r=v.R,g=v.B,b=v.B} end
    if type(v)=="table" then
        local t={}
        for k,x in pairs(v) do
            local ex=encodeValue(x)
            if ex~=nil then t[k]=ex end
        end
        return t
    end
    if type(v)=="string" or type(v)=="number" or type(v)=="boolean" then return v end
    return nil
end
local function decodeValue(v)
    if type(v)~="table" then return v end
    if v.__color3 then return Color3.new(tonumber(v.r) or 0,tonumber(v.g) or 0,tonumber(v.b) or 0) end
    if v.__enum then
        local et=v.__enum:gsub("Enum%.?","")
        local ok,en=pcall(function() return Enum[et] end)
        if ok and en and en[v.name] then return en[v.name] end
        return v.name
    end
    local t={}; for k,x in pairs(v) do t[k]=decodeValue(x) end; return t
end
local function configSnapshot()
    local snapshot={}
    -- Simpan hanya control yang benar-benar ada di GUI, bukan runtime objects.
    for key in pairs(Controls) do
        local v=encodeValue(Values[key])
        if v~=nil then snapshot[key]=v end
    end
    return snapshot
end
local function savePersistentConfig(name,snapshot)
    if not canFileWrite() then return false end
    local ok,json=pcall(function() return HttpService:JSONEncode({version=2,configs={[name]=snapshot}}) end)
    if not ok then return false end
    local old={}
    if canFileRead() and isfile(CONFIG_FILE) then
        local rok,r=pcall(readfile,CONFIG_FILE); if rok then local dok,d=pcall(HttpService.JSONDecode,HttpService,r); if dok and type(d)=="table" then old=d end end
    end
    old.version=2; old.configs=old.configs or {}; old.configs[name]=snapshot
    local wok,w=pcall(function() return HttpService:JSONEncode(old) end)
    if wok then return pcall(writefile,CONFIG_FILE,w) end
    return false
end
local function loadPersistentConfigs()
    if not (canFileRead() and isfile(CONFIG_FILE)) then return end
    local ok,data=pcall(readfile,CONFIG_FILE); if not ok then return end
    local dok,obj=pcall(HttpService.JSONDecode,HttpService,data)
    if not dok or type(obj)~="table" or type(obj.configs)~="table" then return end
    for name,snap in pairs(obj.configs) do sessionConfigs[name]=snap end
end
local function applySnapshot(snapshot)
    if type(snapshot)~="table" then return end
    for key, raw in pairs(snapshot) do
        local value=decodeValue(raw)
        local control=Controls[key]
        if control and control.set then pcall(function() control.set(value) end) else Values[key]=value end
    end
    applyConfigVisuals()
end
local function configNames()
    local names={}; for name in pairs(sessionConfigs) do table.insert(names,name) end
    table.sort(names); if #names==0 then names[1]="No Config" end; return names
end
local function refreshConfigDropdown(selected)
    local list=configNames(); local current=selected or Values["Config List"]
    if not sessionConfigs[current] and current~="No Config" then current=list[1] end
    Values["Config List"]=current
    local control=Controls["Config List"]
    if control and control.setOptions then control.setOptions(list,current) elseif control and control.set then control.set(current) end
    return list
end
Hooks["Create Config"] = function()
    local name=tostring(Values["Config Name"] or ""):gsub("^%s+",""):gsub("%s+$","")
    if name=="" then warn("[Aletta] Config Name masih kosong."); return end
    local snap=configSnapshot(); sessionConfigs[name]=snap; savePersistentConfig(name,snap); refreshConfigDropdown(name)
end
Hooks["Load Config"] = function()
    local name=Values["Config List"]; local snap=sessionConfigs[name]
    if snap then applySnapshot(snap); print("[Aletta] Config dimuat:",name) end
end
Hooks["Overwrite Config"] = function()
    local name=Values["Config List"]; if not sessionConfigs[name] then return end
    local snap=configSnapshot(); sessionConfigs[name]=snap; savePersistentConfig(name,snap)
end
Hooks["Delete Config"] = function()
    local name=Values["Config List"]; if name and sessionConfigs[name] then sessionConfigs[name]=nil; refreshConfigDropdown() end
end
Hooks["Refresh List"] = function() refreshConfigDropdown() end
Hooks["Set as Autoload"] = function()
    local name=Values["Config List"]; if sessionConfigs[name] then autoloadConfig=name end
end
Hooks["Reset Autoload"] = function() autoloadConfig=nil end
Hooks["Save Config Now"] = function()
    local name=tostring(Values["Config Name"] or "Session"); local snap=configSnapshot(); sessionConfigs[name]=snap; savePersistentConfig(name,snap); refreshConfigDropdown(name); print("[Aletta] Config disimpan:",name)
end
Hooks["Auto Save Config"] = function(on)
    Values["Auto Save Config"]=on==true
    if on then
        local name=tostring(Values["Config Name"] or "Session"); local snap=configSnapshot(); sessionConfigs[name]=snap; savePersistentConfig(name,snap)
    end
end
Hooks["Reset to Default"] = function()
    for name,default in pairs(Defaults) do local control=Controls[name]; if control and control.set then pcall(function() control.set(default) end) else Values[name]=default end end
    applyConfigVisuals()
end
Hooks["Delete Config File"] = function()
    if type(delfile)=="function" and type(isfile)=="function" and isfile(CONFIG_FILE) then pcall(delfile,CONFIG_FILE) end
    sessionConfigs={}; refreshConfigDropdown()
end

loadPersistentConfigs()
if Values["Auto Save Config"] then
    task.defer(function()
        local name=autoloadConfig or Values["Config List"]
        if name and sessionConfigs[name] then applySnapshot(sessionConfigs[name]) end
    end)
end

-- Single Execute / Keep Loaded
Hooks["Single Execute / Keep Loaded"] = function(on)
    if AlettaRuntime and AlettaRuntime.AlettaCreatorRuntime then
        AlettaRuntime.AlettaCreatorRuntime.SingleExecute = on == true
    end
end

-- =========================================================
-- INFO / SOCIAL / SERVER
-- =========================================================

local function openExternalUrl(url)
    local ok = pcall(function()
        GuiService:OpenBrowserWindow(url)
    end)
    if not ok then
        warn("[Aletta] Browser tidak dapat dibuka otomatis: " .. tostring(url))
    end
end

local function copyText(value)
    if type(setclipboard) == "function" then
        local ok = pcall(setclipboard, tostring(value))
        if ok then return true end
    end
    print("[Aletta] Copy value:", tostring(value))
    return false
end

Hooks["Join Discord"] = function()
    openExternalUrl("https://discord.gg/JGNVEK6s7")
end

Hooks["Open TikTok"] = function()
    openExternalUrl("https://www.tiktok.com/@alettamelindaw?_r=1&_t=ZS-9A37fLCEEYZ")
end

Hooks["Copy Server ID"] = function()
    copyText(game.JobId)
end

Hooks["Rejoin Server"] = function()
    pcall(function()
        TeleportService:Teleport(game.PlaceId, player)
    end)
end

Hooks["Server Hop"] = function()
    -- Tanpa HTTP/server-list eksternal: minta matchmaking Roblox membuat sesi baru.
    pcall(function()
        TeleportService:TeleportAsync(game.PlaceId, {player})
    end)
end

Hooks["Destroy UI"] = function()
    if gui and gui.Parent then
        gui:Destroy()
    end
end

-- =========================================================
-- EMOTE TEST
-- =========================================================

Hooks["Play Emote"] = function()
    local h = humanoid()
    if not h then return end

    local animator = h:FindFirstChildOfClass("Animator")
    if not animator then return end

    print("[Aletta] Selected emote:", Values["Select Emote"])
    print("[Aletta] Masukkan AnimationId resmi project jika ingin memainkan animasi.")
end

Hooks["Stop Emote"] = function()
    local h = humanoid()
    if not h then return end

    for _, track in ipairs(h:GetPlayingAnimationTracks()) do
        pcall(function()
            track:Stop(0.15)
        end)
    end
end

-- =========================================================
-- ESP - MATCH ONLY
-- =========================================================

espFolder = Instance.new("Folder")
espFolder.Name = "AlettaESP"
espFolder.Parent = workspace

espGui = Instance.new("ScreenGui")
espGui.Name = "AlettaESPLabels"
espGui.ResetOnSpawn = false
espGui.IgnoreGuiInset = true
espGui.Parent = playerGui

-- ESP sengaja tidak aktif di lobby/intermission.
-- Game.VD menyediakan BindableEvent Start/endgame/RoundEnd yang dipakai
-- sebagai sinyal match. Jika script dimuat di tengah match, heuristic
-- di bawah mencari Role yang benar-benar diberikan ke player + object map.
local espMatchActive = false
local espMatchConnections = {}
local espLastKnownState = false
local espWaitingForStart = false
local clearESP
local rebuildESP
local heuristicCacheTime = 0
local heuristicCacheResult = false

local function disconnectESPMatchSignals()
    for _, connection in ipairs(espMatchConnections) do
        pcall(function() connection:Disconnect() end)
    end
    table.clear(espMatchConnections)
end

local function setESPMatchActive(active)
    active = active == true
    espMatchActive = active
    espLastKnownState = active
    espWaitingForStart = not active
    if not active and clearESP then
        clearESP()
    elseif active and Values["Enable ESP"] and rebuildESP then
        task.defer(rebuildESP)
    end
end

local function findGameFolder()
    local replicated = game:GetService("ReplicatedStorage")
    local remotes = replicated:FindFirstChild("Remotes")
    if not remotes then return nil end
    return remotes:FindFirstChild("Game")
end

local function bindMatchSignals()
    disconnectESPMatchSignals()
    local gameFolder = findGameFolder()
    if not gameFolder then return end

    local startEvent = gameFolder:FindFirstChild("Start")
    local endEvent = gameFolder:FindFirstChild("endgame")
    local roundEndEvent = gameFolder:FindFirstChild("RoundEndEvent")
    local roundEnd = gameFolder:FindFirstChild("RoundEnd")
    local endScreen = gameFolder:FindFirstChild("EndScreenEvent")

    if startEvent and startEvent:IsA("BindableEvent") then
        table.insert(espMatchConnections, startEvent.Event:Connect(function()
            setESPMatchActive(true)
        end))
    end

    for _, event in ipairs({endEvent, roundEndEvent, roundEnd, endScreen}) do
        if event and event:IsA("BindableEvent") then
            table.insert(espMatchConnections, event.Event:Connect(function()
                setESPMatchActive(false)
            end))
        end
    end
end

bindMatchSignals()

local espColorMap = {
    Survivor = Color3.fromRGB(70, 255, 100),   -- green
    Killer = Color3.fromRGB(255, 60, 60),      -- red
    Zombie = Color3.fromRGB(190, 70, 255),
    SCP = Color3.fromRGB(190, 70, 255),
    Generator = Color3.fromRGB(70, 140, 255),  -- blue
    Gate = Color3.fromRGB(255, 255, 255),      -- white
    Hook = Color3.fromRGB(255, 60, 60),        -- red
    Pallet = Color3.fromRGB(255, 225, 60),     -- yellow
    Window = Color3.fromRGB(255, 225, 60)      -- yellow
}

clearESP = function()
    if espFolder then
        for _, object in ipairs(espFolder:GetChildren()) do
            object:Destroy()
        end
    end

    if espGui then
        for _, object in ipairs(espGui:GetChildren()) do
            object:Destroy()
        end
    end
end

local function normalizeESPText(value)
    if value == nil then return nil end
    local text = tostring(value):lower():gsub("%s+", "")
    if text:find("killer", 1, true) then return "Killer" end
    if text:find("survivor", 1, true) then return "Survivor" end
    if text:find("zombie", 1, true) then return "Zombie" end
    if text:find("scp", 1, true) then return "SCP" end
    return nil
end

-- Role detector yang lebih toleran. Build sebelumnya hanya membaca
-- Attribute("Role"), sehingga ESP mati jika game menyimpan role di
-- RoleName/Team/StringValue atau hanya Team player.
local function detectESPExplicitRole(targetPlayer)
    if not targetPlayer then return nil end
    local c = targetPlayer.Character

    local candidates = {
        c and c:GetAttribute("Role"),
        c and c:GetAttribute("RoleName"),
        c and c:GetAttribute("Team"),
        targetPlayer:GetAttribute("Role"),
        targetPlayer:GetAttribute("RoleName"),
        targetPlayer:GetAttribute("Team"),
        targetPlayer.Team and targetPlayer.Team.Name
    }

    for _, value in ipairs(candidates) do
        local role = normalizeESPText(value)
        if role then return role end
    end

    -- Beberapa build menyimpan role sebagai StringValue/Value object.
    local containers = {targetPlayer, c}
    for _, container in ipairs(containers) do
        if container then
            for _, name in ipairs({"Role", "RoleName", "Team"}) do
                local valueObject = container:FindFirstChild(name)
                if valueObject and valueObject:IsA("ValueBase") then
                    local role = normalizeESPText(valueObject.Value)
                    if role then return role end
                end
            end
        end
    end

    return nil
end

local function hasMatchRole(targetPlayer)
    local explicit = detectESPExplicitRole(targetPlayer)
    if explicit then return true end

    -- Jika role belum tereplikasi sebagai attribute, player dengan character
    -- aktif tetap dapat menjadi survivor candidate. Killer akan dicari lewat
    -- detector di atas saat addCharacterESP().
    local c = targetPlayer.Character
    local h = c and c:FindFirstChildOfClass("Humanoid")
    local r = c and c:FindFirstChild("HumanoidRootPart")
    return h ~= nil and r ~= nil and h.Health > 0
end

local function roleOf(targetPlayer)
    local explicit = detectESPExplicitRole(targetPlayer)
    if explicit then return explicit end

    -- Dalam match VD, player lain yang tidak terdeteksi sebagai Killer
    -- diperlakukan sebagai Survivor. Ini mencegah ESP hilang hanya karena
    -- attribute Role belum direplikasi ke client.
    return "Survivor"
end

local function espColor(role)
    if role == "Killer" then
        return Color3.fromRGB(255, 60, 60)
    elseif role == "Survivor" then
        return Color3.fromRGB(70, 255, 100)
    end
    return espColorMap[role] or ACCENT
end

local function distanceAllowed(part)
    local myRoot = root()
    if not myRoot or not part then return true end
    local maxDistance = tonumber(Values["ESP Distance"]) or 600
    if maxDistance <= 0 then return true end
    return (myRoot.Position - part.Position).Magnitude <= maxDistance
end

local function espTransparency()
    local value = tonumber(Values["ESP Transparency"]) or 2
    return math.clamp(value / 11, 0, 1)
end

local function addCharacterESP(targetPlayer)
    if not isMatchESPAllowed() then return end
    if targetPlayer == player then return end

    local c = targetPlayer.Character
    local h = c and c:FindFirstChildOfClass("Humanoid")
    local targetRoot = c and c:FindFirstChild("HumanoidRootPart")
    local role = roleOf(targetPlayer)

    -- Player lobby tanpa Role tidak boleh muncul.
    if not c or not h or not targetRoot or h.Health <= 0 or not role then return end
    if not distanceAllowed(targetRoot) then return end

    -- Name/Distance ESP hanya untuk Killer dan Survivor.
    -- Zombie/SCP tetap diberi highlight ungu, tetapi tanpa Name/Distance.
    local isZombie = role == "Zombie" or role == "Zombie Dummy" or role == "SCP"
    if role ~= "Killer" and role ~= "Survivor" and not isZombie then
        return
    end
    if role == "Killer" and not Values["ESP Killer"] then return end
    if role == "Survivor" and not Values["ESP Survivor"] then return end
    if isZombie and Values["Target SCP / Zombie"] == false then return end

    local color = isZombie and Color3.fromRGB(190, 70, 255) or espColor(role)
    local transparency = espTransparency()

    local highlight = Instance.new("Highlight")
    highlight.Adornee = c
    highlight.FillTransparency = math.max(0.82, transparency)
    highlight.OutlineTransparency = 0
    highlight.OutlineColor = color
    highlight.FillColor = color
    highlight.Parent = espFolder

    if not isZombie and (Values["Show Name"]
        or Values["Show Distance"]
        or Values["Show Health"]) then

        local billboard = Instance.new("BillboardGui")
        billboard.Adornee = targetRoot
        billboard.Size = UDim2.fromOffset(180, 45)
        billboard.StudsOffset = Vector3.new(0, 3, 0)
        billboard.AlwaysOnTop = true
        billboard.Parent = espGui

        local text = Instance.new("TextLabel")
        text.BackgroundTransparency = 1
        text.Size = UDim2.fromScale(1, 1)
        text.Font = Enum.Font.GothamBold
        text.TextSize = 12
        text.TextColor3 = color
        text.TextStrokeTransparency = 0.2
        text.Parent = billboard

        local parts = {}
        if Values["Show Name"] then table.insert(parts, targetPlayer.Name) end
        if Values["Show Health"] then
            table.insert(parts, "[" .. math.floor(h.Health) .. " HP]")
        end
        if Values["Show Distance"] then
            local myRoot = root()
            if myRoot then
                table.insert(parts, "[" .. math.floor(
                    (myRoot.Position - targetRoot.Position).Magnitude
                ) .. " M]")
            end
        end
        text.Text = table.concat(parts, " ")
    end
end

local function objectKind(object)
    local name = object.Name:lower()

    if name:find("generator") then
        return "Generator"
    elseif name:find("gate") or name:find("exit") then
        return "Gate"
    elseif name:find("hook") or name:find("scourge") then
        return "Hook"
    elseif name:find("pallet") then
        return "Pallet"
    elseif name:find("window") or name:find("vault") then
        return "Window"
    end

    return nil
end

local function gateDisplayName(object)
    local name = object.Name:lower()
    if name:find("gate%s*1") or name:find("gate_1") or name:find("gate%-1") then
        return "Gate 1"
    elseif name:find("gate%s*2") or name:find("gate_2") or name:find("gate%-2") then
        return "Gate 2"
    end
    return "Gate"
end

local function addObjectESP(object, kind, gateIndex)
    if not isMatchESPAllowed() then return end

    if kind == "Generator" and not Values["ESP Generator"] then return end
    if kind == "Gate" and not Values["ESP Gate"] then return end
    if kind == "Hook" and not Values["ESP Hook"] then return end
    if kind == "Pallet" and not Values["ESP Pallet"] then return end
    if kind == "Window" and not Values["ESP Window / Vault"] then return end

    local part = object:IsA("BasePart")
        and object
        or object:FindFirstChildWhichIsA("BasePart", true)
    if not part or not distanceAllowed(part) then return end

    -- Warna object ESP ditetapkan sesuai permintaan:
    -- Generator = biru, Window/Vault = kuning, Pallet = kuning,
    -- Hook = merah, Gate 1/2 = putih.
    local color = espColorMap[kind] or ACCENT
    local transparency = espTransparency()

    local highlight = Instance.new("Highlight")
    highlight.Adornee = object
    highlight.FillTransparency = math.max(0.82, transparency)
    highlight.OutlineTransparency = 0
    highlight.OutlineColor = color
    highlight.FillColor = color
    highlight.Parent = espFolder

    -- Object ESP tidak menampilkan Name/Distance.
    -- Name/Distance hanya dipakai oleh addCharacterESP untuk Killer/Survivor.
end

rebuildESP = function()
    clearESP()

    if not Values["Enable ESP"] then return end
    if not isMatchESPAllowed() then return end

    for _, targetPlayer in ipairs(Players:GetPlayers()) do
        addCharacterESP(targetPlayer)
    end

    local gateIndex = 0
    for _, object in ipairs(workspace:GetDescendants()) do
        local kind = objectKind(object)
        if kind and (object:IsA("Model") or object:IsA("BasePart")) then
            if kind == "Gate" then
                gateIndex += 1
                addObjectESP(object, kind, gateIndex)
            else
                addObjectESP(object, kind)
            end
        end
    end
end

Hooks["Enable ESP"] = function(on)
    disconnectList("Enable ESP")
    if on then
        bindMatchSignals()

        -- Jangan menunggu BindableEvent Start jika script di-load setelah
        -- ronde sudah berjalan. Jika ada player aktif + map object, izinkan ESP.
        if not espMatchActive and not espWaitingForStart and matchHeuristic() then
            espMatchActive = true
        end

        rebuildESP()

        local lastRebuild = 0
        FeatureManager:Connect("Enable ESP", RunService.Heartbeat, function()
            local now = os.clock()
            if now - lastRebuild >= 0.50 then
                lastRebuild = now
                if not espMatchActive and not espWaitingForStart and matchHeuristic() then
                    espMatchActive = true
                end
                rebuildESP()
            end
        end)
    else
        clearESP()
    end
end

for _, name in ipairs({
    "ESP Survivor",
    "ESP Killer",
    "ESP Generator",
    "ESP Gate",
    "ESP Hook",
    "ESP Pallet",
    "ESP Window / Vault",
    "Show Name",
    "Show Distance",
    "Show Health",
    "ESP Distance",
    "ESP Transparency",
    "Survivor Color",
    "Killer Color",
    "Zombie Dummy Color",
    "Generator Color",
    "Gate Color",
    "Hook Color",
    "Pallet Color",
    "Window / Vault Color"
}) do
    Hooks[name] = function()
        if Values["Enable ESP"] then
            rebuildESP()
        end
    end
end

-- Alias slider from Survivor > Parry Menu. It controls the same ESP distance.
Hooks["ESP Range"] = function(value)
    local n = math.clamp(tonumber(value) or 600, 0, 600)
    Values["ESP Range"] = n
    Values["ESP Distance"] = n
    if Values["Enable ESP"] then
        rebuildESP()
    end
end

-- Compatibility alias for older configs.
Hooks["Esp Range"] = Hooks["ESP Range"]

-- Rebuild ESP saat player/character/role muncul atau berubah.
local function queueESPRebuild()
    if Values["Enable ESP"] then
        task.defer(function()
            if Values["Enable ESP"] then rebuildESP() end
        end)
    end
end

Players.PlayerAdded:Connect(function(plr)
    plr.CharacterAdded:Connect(function()
        task.wait(0.25)
        queueESPRebuild()
    end)
    plr:GetPropertyChangedSignal("Team"):Connect(queueESPRebuild)
    pcall(function()
        plr:GetAttributeChangedSignal("Role"):Connect(queueESPRebuild)
        plr:GetAttributeChangedSignal("RoleName"):Connect(queueESPRebuild)
    end)
end)

for _, plr in ipairs(Players:GetPlayers()) do
    if plr ~= player then
        plr.CharacterAdded:Connect(function()
            task.wait(0.25)
            queueESPRebuild()
        end)
    end
end

-- =========================================================
-- MOONWALK
-- =========================================================

local function setMWIndicator(on)
    if not mwGui then
        mwGui = Instance.new("ScreenGui")
        mwGui.Name = "AlettaMWIndicator"
        mwGui.ResetOnSpawn = false
        mwGui.IgnoreGuiInset = true
        mwGui.Parent = playerGui

        mwButton = Instance.new("TextButton")
        mwButton.Size = UDim2.fromOffset(64, 42)
        mwButton.Position = UDim2.new(1, -86, 1, -190)
        mwButton.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
        mwButton.TextColor3 = TEXT
        mwButton.Font = Enum.Font.GothamBold
        mwButton.TextSize = 16
        mwButton.Text = "MW"
        mwButton.Visible = false
        mwButton.Parent = mwGui
        corner(mwButton, 21)

        local stroke = Instance.new("UIStroke")
        stroke.Thickness = 2
        stroke.Parent = mwButton

        mwButton.InputBegan:Connect(function(input)
            if isPress(input) and Values["Enable Moonwalk (Hold Hotkey/Button)"] then
                Values["Moonwalk Held"] = true
                mwButton.BackgroundColor3 = ACCENT
            end
        end)
        mwButton.InputEnded:Connect(function(input)
            if isPress(input) then
                Values["Moonwalk Held"] = false
                if Values["Enable Moonwalk (Hold Hotkey/Button)"] then
                    mwButton.BackgroundColor3 = Color3.fromRGB(30,30,30)
                end
            end
        end)
    end

    mwButton.Visible = on
    mwButton.BackgroundColor3 =
        on and ACCENT or Color3.fromRGB(30, 30, 30)
end

Hooks["Enable Moonwalk (Hold Hotkey/Button)"] = function(on)
    setMWIndicator(on)
    disconnectList("Moonwalk Render")

    if not on then
        Values["Moonwalk Held"] = false
        return
    end

    FeatureManager:Connect("Moonwalk Render", RunService.RenderStepped, function()
        if not Values["Moonwalk Held"] then return end
        local c = character()
        local h = humanoid()
        local r = root()
        if not c or not h or not r then return end

        camera = workspace.CurrentCamera or camera
        if not camera then return end
        local look = camera.CFrame.LookVector
        local flat = Vector3.new(look.X, 0, look.Z)
        if flat.Magnitude > 0.05 then
            r.CFrame = CFrame.lookAt(r.Position, r.Position + flat.Unit)
        end
    end)
end

-- Hold X / configured Moonwalk Hotkey.
UIS.InputBegan:Connect(function(input, processed)
    if processed then return end
    if not Values["Enable Moonwalk (Hold Hotkey/Button)"] then return end
    if input.UserInputType == Enum.UserInputType.Keyboard and input.KeyCode == (Values["Moonwalk Hotkey"] or Enum.KeyCode.X) then
        Values["Moonwalk Held"] = true
        setMWIndicator(true)
    end
end)

UIS.InputEnded:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.Keyboard and input.KeyCode == (Values["Moonwalk Hotkey"] or Enum.KeyCode.X) then
        Values["Moonwalk Held"] = false
        if Values["Enable Moonwalk (Hold Hotkey/Button)"] then setMWIndicator(false) end
    end
end)


-- =========================================================
-- SAFE GAME-SPECIFIC TEST HANDLERS
-- =========================================================

-- =========================================================
-- VEIL AUTO AIM + SMART PREDICTION + FOV / SNAPLINE
-- =========================================================
local veilSnapPart, veilSnapTarget, veilSnapBeam
local function destroyVeilSnap()
    if veilSnapBeam then pcall(function() veilSnapBeam:Destroy() end) end
    if veilSnapPart then pcall(function() veilSnapPart:Destroy() end) end
    if veilSnapTarget then pcall(function() veilSnapTarget:Destroy() end) end
    veilSnapBeam,veilSnapPart,veilSnapTarget=nil,nil,nil
end

local function getVeilTarget()
    local myRoot=root(); camera=workspace.CurrentCamera or camera
    if not myRoot or not camera then return nil end
    local best,bestScore=nil,math.huge
    local maxDistance=math.clamp(tonumber(Values["Veil Distance"]) or 150,10,500)
    local fovRadius=math.clamp(tonumber(Values["Veil FOV Radius"]) or 120,10,600)
    local center=Vector2.new(camera.ViewportSize.X/2,camera.ViewportSize.Y/2)
    for _,targetPlayer in ipairs(Players:GetPlayers()) do
        if targetPlayer~=player then
            local c=targetPlayer.Character; local h=c and c:FindFirstChildOfClass("Humanoid"); local r=c and getRootPart(c)
            if h and h.Health>0 and r and not isKnocked(c,targetPlayer) and detectESPExplicitRole(targetPlayer)=="Survivor" then
                local part=aimPartFor(c); local d=(r.Position-myRoot.Position).Magnitude
                if part and d<=maxDistance then
                    local vp,onScreen=camera:WorldToViewportPoint(part.Position)
                    if onScreen and vp.Z>0 then
                        local score=(Vector2.new(vp.X,vp.Y)-center).Magnitude
                        if score<=fovRadius and score<bestScore and hasLineOfSight(camera.CFrame.Position,part,c) then
                            bestScore=score; best={player=targetPlayer,character=c,root=r,part=part,distance=d}
                        end
                    end
                end
            end
        end
    end
    return best
end

local function getVeilPredictedPosition(target)
    if not target or not target.part then return nil end
    if not Values["Smart Predict Mode"] then return target.part.Position end
    local speed=math.max(tonumber(Values["Spear Speed"]) or 165,1)
    local lead=math.clamp((tonumber(Values["Smart Predict Lead"]) or 17)/100,0,1.5)
    local velocity=target.part.AssemblyLinearVelocity or target.root.AssemblyLinearVelocity or Vector3.zero
    local flight=math.clamp((target.distance or 0)/speed,0,2)
    return target.part.Position+velocity*flight*lead
end

local function updateVeilSnap(target,pos)
    if not Values["Snapline"] or not target or not pos or not camera then destroyVeilSnap(); return end
    if not veilSnapBeam then
        veilSnapPart=Instance.new("Part"); veilSnapPart.Name="AlettaVeilSnapOrigin"; veilSnapPart.Anchored=true; veilSnapPart.CanCollide=false; veilSnapPart.CanTouch=false; veilSnapPart.CanQuery=false; veilSnapPart.Transparency=1; veilSnapPart.Size=Vector3.new(.1,.1,.1); veilSnapPart.Parent=workspace
        veilSnapTarget=Instance.new("Part"); veilSnapTarget.Name="AlettaVeilSnapTarget"; veilSnapTarget.Anchored=true; veilSnapTarget.CanCollide=false; veilSnapTarget.CanTouch=false; veilSnapTarget.CanQuery=false; veilSnapTarget.Transparency=1; veilSnapTarget.Size=Vector3.new(.1,.1,.1); veilSnapTarget.Parent=workspace
        local a=Instance.new("Attachment",veilSnapPart); local b=Instance.new("Attachment",veilSnapTarget)
        veilSnapBeam=Instance.new("Beam"); veilSnapBeam.Attachment0=a; veilSnapBeam.Attachment1=b; veilSnapBeam.FaceCamera=true; veilSnapBeam.Width0=.025; veilSnapBeam.Width1=.025; veilSnapBeam.Color=ColorSequence.new(ACCENT); veilSnapBeam.Parent=veilSnapPart
    end
    veilSnapPart.CFrame=CFrame.new(camera.CFrame.Position); veilSnapTarget.CFrame=CFrame.new(pos)
end

Hooks["Veil"] = function(on)
    disconnectList("Veil Auto Aim")
    updateAimFov()
    if not on then _G.AlettaVeilPredictionTarget=nil; destroyVeilSnap(); return end
    FeatureManager:Connect("Veil Auto Aim",RunService.RenderStepped,function()
        local target=getVeilTarget(); if not target then destroyVeilSnap(); return end
        local predicted=getVeilPredictedPosition(target); if not predicted then return end
        camera=workspace.CurrentCamera or camera
        if camera then camera.CFrame=CFrame.lookAt(camera.CFrame.Position,predicted) end
        _G.AlettaVeilPredictionTarget={player=target.player,position=predicted,time=os.clock()}
        updateVeilSnap(target,predicted)
    end)
end
Hooks["Smart Predict Mode"] = function(on) Values["Smart Predict Mode"]=on==true end
Hooks["Smart Predict Lead"] = function(v) Values["Smart Predict Lead"]=math.clamp(tonumber(v) or 17,0,100) end
Hooks["Veil Show FOV"] = function(on) Values["Veil Show FOV"]=on==true; updateAimFov() end
Hooks["Snapline"] = function(on) Values["Snapline"]=on==true; if not on then destroyVeilSnap() end end
Hooks["Veil FOV Radius"] = function(v) Values["Veil FOV Radius"]=math.clamp(tonumber(v) or 120,10,600); updateAimFov() end
Hooks["Veil Distance"] = function(v) Values["Veil Distance"]=math.clamp(tonumber(v) or 150,10,500) end
Hooks["Spear Speed"] = function(v) Values["Spear Speed"]=math.clamp(tonumber(v) or 165,1,300) end

-- =========================================================
-- AUTO PARRY - PROJECT-LOCAL IMPLEMENTATION
-- Uses the project's Parrying Dagger remote when it exists, with the normal
-- Tool:Activate() path. Cooldown is fixed at 120 seconds.
-- Radius is controlled by Survivor > Parry Menu > Parry Radius.
-- The detection visualization is a flat ground circle under the player's feet.

local AutoParry = { last=0, cooldown=120, armed=false, lastResult=0, resultSeen=false }

local function getRootPart(model)
    return model and (model:FindFirstChild("HumanoidRootPart") or model:FindFirstChild("UpperTorso") or model:FindFirstChild("Torso"))
end

local function findRemotePath(names)
    local node=game:GetService("ReplicatedStorage")
    for _,name in ipairs(names) do node=node and node:FindFirstChild(name) end
    return node
end

local function findParryRemote()
    local rs=game:GetService("ReplicatedStorage")
    local r=findRemotePath({"Remotes","Items","Parrying Dagger","parry"})
    if r and r:IsA("RemoteEvent") then return r end
    for _,d in ipairs(rs:GetDescendants()) do
        if d:IsA("RemoteEvent") and string.lower(d.Name)=="parry" and d.Parent and string.lower(d.Parent.Name):find("parry") then return d end
    end
end
local function findParryResultRemote()
    local r=findRemotePath({"Remotes","Items","Parrying Dagger","parryResult"})
    return r and r:IsA("RemoteEvent") and r or nil
end
local function findParryTool()
    local function scan(c)
        if not c then return end
        for _,v in ipairs(c:GetChildren()) do
            if v:IsA("Tool") then
                local n=string.lower(v.Name)
                if n:find("parry") or n:find("dagger") then return v end
            end
        end
    end
    return scan(character()) or scan(player:FindFirstChildOfClass("Backpack"))
end
local function isKillerPlayer(p)
    if not p or p==player then return false end
    local c=p.Character
    local role=(c and (c:GetAttribute("Role") or c:GetAttribute("RoleName") or c:GetAttribute("Team"))) or p:GetAttribute("Role") or p:GetAttribute("RoleName")
    if typeof(role)=="string" and string.lower(role):find("killer") then return true end
    return p.Team and string.lower(p.Team.Name):find("killer")~=nil or false
end
local function attackTrackInfo(h)
    local best
    for _,t in ipairs(h:GetPlayingAnimationTracks()) do
        local n=string.lower(t.Name or "")
        local id=string.lower(t.Animation and t.Animation.AnimationId or "")
        if (n.." "..id):find("attack") or (n.." "..id):find("lunge") or (n.." "..id):find("slash") or (n.." "..id):find("swing") or (n.." "..id):find("m1") or (n.." "..id):find("m2") then
            local len=tonumber(t.Length) or 0; local pos=tonumber(t.TimePosition) or 0
            local progress=len>0 and pos/len or 1
            if not best or progress>best.progress then best={track=t,progress=progress,length=len} end
        end
    end
    return best
end
local function threatForKiller(p,myRoot,radius)
    if not isKillerPlayer(p) then return end
    local c=p.Character; local h=c and c:FindFirstChildOfClass("Humanoid"); local r=getRootPart(c)
    if not h or h.Health<=0 or not r then return end
    local delta=myRoot.Position-r.Position; local dist=delta.Magnitude
    if dist>radius then return end
    local toUs=dist>0 and delta.Unit or Vector3.zero
    local vel=r.AssemblyLinearVelocity; local speed=vel.Magnitude; local closing=vel:Dot(toUs)
    local facing=r.CFrame.LookVector:Dot(toUs)
    local attack=attackTrackInfo(h)
    local moving=speed>=7 and closing>=4
    if not attack and not moving then return end
    if facing < -0.35 and not moving then return end
    return {player=p,root=r,distance=dist,speed=speed,closing=closing,facing=facing,attack=attack}
end
local function getThreat()
    local mr=root(); if not mr then return end
    local radius=math.clamp(tonumber(Values["Parry Radius"]) or 13,2,100)
    if Values["Aggressive Parry"] then radius=math.max(radius,math.clamp(tonumber(Values["ESP Range"]) or radius,radius,60)) end
    local best
    for _,p in ipairs(Players:GetPlayers()) do
        local t=threatForKiller(p,mr,radius)
        if t and (not best or t.distance<best.distance) then best=t end
    end
    return best
end
local function sendParry()
    local now=os.clock()
    local remaining=AutoParry.cooldown-(now-AutoParry.last)
    if AutoParry.last>0 and remaining>0 then
        return false
    end

    local sent=false
    local h=humanoid()
    local tool=findParryTool()

    -- Satu trigger saja per siklus cooldown. Prioritaskan Tool:Activate()
    -- karena itu jalur aksi dagger yang paling dekat dengan gameplay normal.
    if tool and tool.Parent~=character() and h then
        pcall(function() h:EquipTool(tool) end)
        task.wait()
        tool=findParryTool()
    end

    if tool and tool.Parent==character() then
        local ok=pcall(function() tool:Activate() end)
        sent=ok
    else
        -- Fallback hanya jika Tool tidak tersedia.
        local remote=findParryRemote()
        if remote then
            local ok=pcall(function() remote:FireServer() end)
            sent=ok
        end
    end

    if sent then
        -- Mulai cooldown 120 detik segera setelah parry dikirim.
        AutoParry.last=os.clock()
    end
    return sent
end
local function stopAutoParry()
    disconnectList("Auto Parry"); disconnectList("Auto Parry Result"); AutoParry.armed=false
end
Hooks["Auto Parry"] = function(on)
    stopAutoParry(); setParryRangeVisual(on or Values["Safety Parry"] or Values["Aggressive Parry"])
    if not on then return end
    AutoParry.armed=true
    local result=findParryResultRemote()
    if result then FeatureManager:Connect("Auto Parry Result",result.OnClientEvent,function(...) AutoParry.lastResult=os.clock(); AutoParry.resultSeen=true end) end
    FeatureManager:Connect("Auto Parry",RunService.Heartbeat,function()
        if not AutoParry.armed then return end
        updateParryRangeVisual()
        local t=getThreat(); if not t then return end
        local radius=math.clamp(tonumber(Values["Parry Radius"]) or 13,2,100)
        local safety=Values["Safety Parry"]==true
        local aggressive=Values["Aggressive Parry"]==true
        local should=false
        if t.attack then
            local pr=t.attack.progress
            -- Trigger lebih awal agar tidak melewati white/perfect window.
            -- Normal/Legit: masuk fase wind-up sampai impact.
            -- Aggressive: mulai dari awal attack.
            if aggressive then
                should=pr>=.08 and pr<=.92
            else
                should=pr>=.20 and pr<=.96
            end
        end

        local closing=t.closing
        local reach=4.5
        local eta=closing>1 and math.max(0,(t.distance-reach)/closing) or math.huge

        -- Prioritaskan jarak impact. Ini membuat Auto Parry tidak hanya
        -- bergantung pada nama AnimationTrack.
        if eta<=.24 then
            should=true
        elseif aggressive and eta<=.45 then
            should=true
        end

        if safety and t.distance>radius then should=false end
        if aggressive and t.distance<=math.max(radius,tonumber(Values["ESP Range"]) or radius) then
            should=should or eta<=.55
        end

        if should then
            sendParry()
        end
    end)
end
Hooks["Safety Parry"] = function(on)
    Values["Safety Parry"]=on==true
    if on then Values["Aggressive Parry"]=false end
    setParryRangeVisual(Values["Auto Parry"] or Values["Safety Parry"] or Values["Aggressive Parry"])
end
Hooks["Aggressive Parry"] = function(on)
    Values["Aggressive Parry"]=on==true
    if on then Values["Safety Parry"]=false end
    setParryRangeVisual(Values["Auto Parry"] or Values["Safety Parry"] or Values["Aggressive Parry"])
end
Hooks["Auto Parry V1"]=Hooks["Auto Parry"]
Hooks["Auto Parry V2"]=Hooks["Auto Parry"]
Hooks["Aggressive Parry V1"]=Hooks["Aggressive Parry"]


-- =========================================================
-- MISC LOCAL/TEST HOOKS
-- =========================================================

local miscOriginal = {
    CameraMaxZoomDistance = player.CameraMaxZoomDistance,
    CameraMinZoomDistance = player.CameraMinZoomDistance,
    WalkSpeed = nil,
    JumpPower = nil,
    LightingBrightness = Lighting.Brightness,
    ClockTime = Lighting.ClockTime,
    FogEnd = Lighting.FogEnd,
    Ambient = Lighting.Ambient,
    OutdoorAmbient = Lighting.OutdoorAmbient,
    GlobalShadows = Lighting.GlobalShadows,
    CameraOffset = nil,
}

local miscRuntime = {
    noclipConn = nil,
    cameraConn = nil,
    moonwalkGui = nil,
    emoteGui = nil,
    emoteTrack = nil,
    skyObjects = {},
    fakeProfileGui = nil,
    originalDisplayName = nil,
    resolutionScale = nil,
}

local function getHumanoid()
    local c = player.Character
    return c and c:FindFirstChildOfClass("Humanoid")
end

local function setNoClipState(on)
    if miscRuntime.noclipConn then
        miscRuntime.noclipConn:Disconnect()
        miscRuntime.noclipConn = nil
    end
    if not on then
        local c = player.Character
        if c then
            for _,d in ipairs(c:GetDescendants()) do
                if d:IsA("BasePart") then
                    pcall(function() d.CanCollide = true end)
                end
            end
        end
        return
    end
    local function apply()
        local c = player.Character
        if not c then return end
        for _,d in ipairs(c:GetDescendants()) do
            if d:IsA("BasePart") then
                pcall(function() d.CanCollide = false end)
            end
        end
    end
    apply()
    miscRuntime.noclipConn = RunService.Stepped:Connect(function()
        if Values["Noclip"] then apply() end
    end)
end

local function applyDBDCamera()
    local h = getHumanoid()
    local cam = workspace.CurrentCamera
    if not h or not cam then return end
    local height = tonumber(Values["Camera Height"]) or 0
    local stiffness = tonumber(Values["Camera Stiffness"]) or 16
    h.CameraOffset = Vector3.new(2.25, 1.35 + height * 0.15, 0)
    player.CameraMinZoomDistance = math.max(5, stiffness * 0.35)
    player.CameraMaxZoomDistance = math.max(player.CameraMinZoomDistance + 0.5, stiffness * 0.75)
    cam.CameraType = Enum.CameraType.Custom
end

Hooks["Camera DBD"] = function(on)
    Values["Camera DBD"] = on == true
    if miscRuntime.cameraConn then miscRuntime.cameraConn:Disconnect(); miscRuntime.cameraConn=nil end
    local h = getHumanoid()
    if not on then
        if h then h.CameraOffset = miscOriginal.CameraOffset or Vector3.zero end
        player.CameraMinZoomDistance = miscOriginal.CameraMinZoomDistance or 0.5
        player.CameraMaxZoomDistance = miscOriginal.CameraMaxZoomDistance or 128
        return
    end
    applyDBDCamera()
    miscRuntime.cameraConn = RunService.RenderStepped:Connect(function()
        if Values["Camera DBD"] then applyDBDCamera() end
    end)
end

Hooks["Camera Height"] = function(value)
    Values["Camera Height"] = tonumber(value) or 0
    if Values["Camera DBD"] then applyDBDCamera() end
end

Hooks["Camera Stiffness"] = function(value)
    Values["Camera Stiffness"] = tonumber(value) or 16
    if Values["Camera DBD"] then applyDBDCamera() end
end

Hooks["Custom Resolution"] = function(on)
    Values["Custom Resolution"] = on == true
    local scale = math.clamp(tonumber(Values["Resolution Scale"]) or 0, -4, 4)
    if on then
        if not miscRuntime.resolutionScale then
            miscRuntime.resolutionScale = Instance.new("UIScale")
            miscRuntime.resolutionScale.Name = "AlettaCustomResolution"
            miscRuntime.resolutionScale.Parent = gui
        end
        miscRuntime.resolutionScale.Scale = math.clamp(1 + scale * 0.08, 0.68, 1.32)
    elseif miscRuntime.resolutionScale then
        miscRuntime.resolutionScale:Destroy(); miscRuntime.resolutionScale=nil
    end
end

Hooks["Resolution Scale"] = function(value)
    Values["Resolution Scale"] = tonumber(value) or 0
    if Values["Custom Resolution"] then Hooks["Custom Resolution"](true) end
end

Hooks["Noclip"] = function(on)
    Values["Noclip"] = on == true
    setNoClipState(on == true)
end

Hooks["Hit Radius Visual"] = function(value)
    Values["Hit Radius Visual"] = tonumber(value) or 8
end

Hooks["FullBright"] = function(on)
    if on then
        Lighting.Brightness = 3
        Lighting.ClockTime = tonumber(Values["Fullbright Time"]) or 14
        Lighting.FogEnd = 100000
        Lighting.Ambient = Color3.new(1,1,1)
        Lighting.OutdoorAmbient = Color3.new(1,1,1)
        Lighting.GlobalShadows = false
    else
        Lighting.Brightness = miscOriginal.LightingBrightness or Lighting.Brightness
        Lighting.ClockTime = miscOriginal.ClockTime or Lighting.ClockTime
        Lighting.FogEnd = miscOriginal.FogEnd or Lighting.FogEnd
        Lighting.Ambient = miscOriginal.Ambient or Lighting.Ambient
        Lighting.OutdoorAmbient = miscOriginal.OutdoorAmbient or Lighting.OutdoorAmbient
        Lighting.GlobalShadows = miscOriginal.GlobalShadows
    end
end

Hooks["Fullbright Time"] = function(value)
    Values["Fullbright Time"] = tonumber(value) or 16
    if Values["FullBright"] then Lighting.ClockTime = Values["Fullbright Time"] end
end

Hooks["Infinite Zoom"] = function(on)
    if on then
        player.CameraMaxZoomDistance = 100000
    else
        player.CameraMaxZoomDistance = miscOriginal.CameraMaxZoomDistance or 128
    end
end

Hooks["High Jump"] = function(on)
    local h = getHumanoid()
    if not h then return end
    if on then
        miscOriginal.JumpPower = h.JumpPower
        h.JumpPower = tonumber(Values["Jump Power"]) or 50
    else
        h.JumpPower = miscOriginal.JumpPower or 50
    end
end

Hooks["Jump Power"] = function(value)
    Values["Jump Power"] = tonumber(value) or 50
    if Values["High Jump"] then
        local h = getHumanoid()
        if h then h.JumpPower = Values["Jump Power"] end
    end
end

Hooks["Skip Cutscene"] = function(on)
    Values["Skip Cutscene"] = on == true
    if not on then return end
    -- Client-safe cutscene skip: stop local camera script and common cutscene tracks.
    local cam = workspace.CurrentCamera
    if cam then cam.CameraType = Enum.CameraType.Custom end
    local h = getHumanoid()
    if h then
        for _,track in ipairs(h:GetPlayingAnimationTracks()) do
            local n=string.lower(track.Name or "")
            if n:find("cut") or n:find("scene") or n:find("cinematic") then pcall(function() track:Stop(0) end) end
        end
    end
end

Hooks["Skip Cutscenes"] = Hooks["Skip Cutscene"]

Hooks["Invisible GUI"] = function(on)
    if gui then window.Visible = not on end
end

Hooks["Unlock FPS"] = function(on)
    Values["Unlock FPS"] = on == true
end
Hooks["Target FPS"] = function(value) Values["Target FPS"] = value end

-- -------------------- Sky / HDR --------------------
local function clearAlettaSky()
    for _,obj in ipairs(miscRuntime.skyObjects) do pcall(function() obj:Destroy() end) end
    miscRuntime.skyObjects = {}
end

Hooks["Sky Changer"] = function(on)
    if not on then clearAlettaSky(); return end
    clearAlettaSky()
    local cc=Instance.new("ColorCorrectionEffect")
    cc.Name="AlettaSkyChanger"
    cc.Brightness=0.05; cc.Contrast=0.12; cc.Saturation=-0.05
    cc.TintColor=Color3.fromRGB(210,200,255)
    cc.Parent=Lighting
    table.insert(miscRuntime.skyObjects,cc)
end

Hooks["Smooth HDR Graphics"] = function(on)
    local blur=Lighting:FindFirstChild("AlettaHDRBloom")
    local cc=Lighting:FindFirstChild("AlettaHDRColor")
    if on then
        if not blur then blur=Instance.new("BloomEffect"); blur.Name="AlettaHDRBloom"; blur.Intensity=0.25; blur.Size=24; blur.Threshold=1.1; blur.Parent=Lighting end
        if not cc then cc=Instance.new("ColorCorrectionEffect"); cc.Name="AlettaHDRColor"; cc.Contrast=0.08; cc.Saturation=0.05; cc.Parent=Lighting end
    else
        if blur then blur:Destroy() end
        if cc then cc:Destroy() end
    end
end

-- -------------------- Spoof Profile --------------------
local function destroyFakeProfile()
    if miscRuntime.fakeProfileGui then miscRuntime.fakeProfileGui:Destroy(); miscRuntime.fakeProfileGui=nil end
end

local function refreshFakeProfile()
    if not Values["Fake Profil"] then destroyFakeProfile(); return end
    destroyFakeProfile()
    local sg=Instance.new("ScreenGui"); sg.Name="AlettaFakeProfile"; sg.ResetOnSpawn=false; sg.IgnoreGuiInset=true; sg.Parent=playerGui
    miscRuntime.fakeProfileGui=sg
    local f=Instance.new("Frame"); f.Size=UDim2.fromOffset(230,110); f.Position=UDim2.fromOffset(18,90); f.BackgroundColor3=Color3.fromRGB(18,12,28); f.BackgroundTransparency=.12; f.Parent=sg; corner(f,10)
    local st=Instance.new("UIStroke"); st.Color=ACCENT; st.Thickness=2; st.Parent=f
    local name=Instance.new("TextLabel"); name.Size=UDim2.new(1,-20,0,28); name.Position=UDim2.fromOffset(10,8); name.BackgroundTransparency=1; name.Font=Enum.Font.GothamBold; name.TextSize=16; name.TextColor3=TEXT; name.TextXAlignment=Enum.TextXAlignment.Left; name.Text=tostring(Values["Spoof Username"] or Values["Fake Name"] or player.Name); name.Parent=f
    local info=Instance.new("TextLabel"); info.Size=UDim2.new(1,-20,0,60); info.Position=UDim2.fromOffset(10,40); info.BackgroundTransparency=1; info.Font=Enum.Font.Gotham; info.TextSize=12; info.TextColor3=GRAY; info.TextXAlignment=Enum.TextXAlignment.Left; info.TextYAlignment=Enum.TextYAlignment.Top; info.TextWrapped=true; info.Text="Level: "..tostring(Values["Set Level"] or "-").."\nGears: "..tostring(Values["Set Gears"] or "-").."  |  Screws: "..tostring(Values["Set Screws"] or "-"); info.Parent=f
end

Hooks["Fake Name"] = function(on)
    Values["Fake Name"] = on == true
    local h=getHumanoid()
    if h then
        if on then
            if miscRuntime.originalDisplayName==nil then miscRuntime.originalDisplayName=h.DisplayName end
            h.DisplayName=tostring(Values["Spoof Username"] or "Aletta")
        elseif miscRuntime.originalDisplayName then h.DisplayName=miscRuntime.originalDisplayName end
    end
    refreshFakeProfile()
end
Hooks["Fake Profil"] = function(on) Values["Fake Profil"]=on==true; refreshFakeProfile() end
Hooks["Set Level"] = function(v) Values["Set Level"]=tostring(v or ""); refreshFakeProfile() end
Hooks["Set Gears"] = function(v) Values["Set Gears"]=tostring(v or ""); refreshFakeProfile() end
Hooks["Set Screws"] = function(v) Values["Set Screws"]=tostring(v or ""); refreshFakeProfile() end
Hooks["Spoofer Profil"] = function(on) Values["Spoofer Profil"]=on==true; refreshFakeProfile() end
Hooks["Enable Spoof Stats & Streamer Mode"] = Hooks["Spoofer Profil"]
Hooks["Spoof Username"] = Hooks["Set Level"]
Hooks["Spoof Level"] = Hooks["Set Level"]
Hooks["Spoof Gears"] = Hooks["Set Gears"]
Hooks["Spoof Screws"] = Hooks["Set Screws"]

-- -------------------- Moonwalk GUI --------------------
Hooks["Moonwalk GUI"] = function(on)
    if not miscRuntime.moonwalkGui then
        local sg=Instance.new("ScreenGui"); sg.Name="AlettaMoonwalkGUI"; sg.ResetOnSpawn=false; sg.Parent=playerGui; miscRuntime.moonwalkGui=sg
        local b=Instance.new("TextButton"); b.Size=UDim2.fromOffset(72,40); b.Position=UDim2.new(1,-92,1,-145); b.Text="MOON"; b.Font=Enum.Font.GothamBold; b.TextSize=13; b.TextColor3=TEXT; b.BackgroundColor3=FIELD; b.Parent=sg; corner(b,20)
        b.Activated:Connect(function() Values["Moonwalk Held"]=not Values["Moonwalk Held"]; b.BackgroundColor3=Values["Moonwalk Held"] and ACCENT or FIELD end)
    end
    miscRuntime.moonwalkGui.Enabled=on==true
end

-- -------------------- Emote GUI --------------------
local emoteIds = {
    ["24 Hour Cinderella"]="138820116683928", ["/e fly"]="93511411593120", ["Asian Squat"]="87939646671209", ["Baby Queen - Air Guitar & Knee Slide"]="14353417553", ["Bored"]="5230661597", ["Cha Cha"]="6865013133", ["Cha-Cha"]="3696764866", ["Country Line Dance - Lil Nas X (LNX)"]="5915780563", ["Cute Sit"]="72947568152049", ["Deltarune Jevil idle"]="107246240129278", ["Dropkick"]="127764273000599", ["Effortless Aura Pose"]="101573394483995", ["Floating Aura Pose"]="88318250668110", ["Floss Dance"]="5917570207", ["Heisman Pose"]="3696763549", ["Hello"]="3576686446", ["Hype Dance"]="3696757129", ["Iconic Fashion Model Idle Pose"]="80004965633316", ["Invisible (work in game)"]="138820116683928", ["Nicki Minaj Boom Boom Boom"]="15571538346", ["Point2"]="3576823880", ["Salute"]="3360689775", ["Samba"]="6869813008", ["Shrug"]="3576968026", ["Skadoosh Emote - Kung Fu Panda 4"]="16371235025", ["Spider Hang"]="74280549351005", ["Stadium"]="3360686498", ["Sweet Hug Pose V2 [MATCHING]"]="79076692213299", ["TWICE The Feels"]="12874468267", ["Ud'zal's Summoning"]="3307604888", ["[AURA FARM] YN Wall Lean"]="71556328869803", ["d4vd - Backflip"]="15694504637", ["hip swing dance"]="110806766469743", ["pain and suffering"]="93195109588878", ["♡ : kawaii plushie hug idle pose"]="110116680249979"
}

local function stopAlettaEmote()
    if miscRuntime.emoteTrack then pcall(function() miscRuntime.emoteTrack:Stop(0.15) end); miscRuntime.emoteTrack=nil end
end
local function playAlettaEmote()
    local h=getHumanoid(); if not h then return end
    local id=emoteIds[tostring(Values["Select Emote"] or "")]
    if not id then return end
    local animator=h:FindFirstChildOfClass("Animator") or Instance.new("Animator",h)
    stopAlettaEmote()
    local anim=Instance.new("Animation"); anim.AnimationId="rbxassetid://"..id
    local ok,track=pcall(function() return animator:LoadAnimation(anim) end)
    if ok and track then track.Priority=Enum.AnimationPriority.Action; track.Looped=true; track:Play(.15,1,1); miscRuntime.emoteTrack=track end
end
Hooks["Emote GUI"] = function(on)
    if not miscRuntime.emoteGui then
        local sg=Instance.new("ScreenGui"); sg.Name="AlettaEmoteGUI"; sg.ResetOnSpawn=false; sg.Parent=playerGui; miscRuntime.emoteGui=sg
        local f=Instance.new("Frame"); f.Size=UDim2.fromOffset(260,86); f.Position=UDim2.new(.5,-130,1,-115); f.BackgroundColor3=Color3.fromRGB(18,12,28); f.BackgroundTransparency=.08; f.Parent=sg; corner(f,10)
        local play=Instance.new("TextButton"); play.Size=UDim2.fromOffset(110,34); play.Position=UDim2.fromOffset(10,42); play.Text="PLAY EMOTE"; play.Font=Enum.Font.GothamBold; play.TextSize=12; play.TextColor3=TEXT; play.BackgroundColor3=ACCENT; play.Parent=f; corner(play,7); play.Activated:Connect(playAlettaEmote)
        local stop=Instance.new("TextButton"); stop.Size=UDim2.fromOffset(110,34); stop.Position=UDim2.fromOffset(140,42); stop.Text="STOP"; stop.Font=Enum.Font.GothamBold; stop.TextSize=12; stop.TextColor3=TEXT; stop.BackgroundColor3=FIELD; stop.Parent=f; corner(stop,7); stop.Activated:Connect(stopAlettaEmote)
        local label=Instance.new("TextLabel"); label.Size=UDim2.new(1,-20,0,30); label.Position=UDim2.fromOffset(10,7); label.BackgroundTransparency=1; label.Text="Select Emote dari menu Animation"; label.Font=Enum.Font.GothamBold; label.TextSize=12; label.TextColor3=TEXT; label.Parent=f
    end
    miscRuntime.emoteGui.Enabled=on==true
end
Hooks["Select Emote"] = function(v) Values["Select Emote"]=v end
Hooks["Play Emote"] = playAlettaEmote
Hooks["Stop Emote"] = stopAlettaEmote

local gameSpecific = {
    "Invisible",
    "Speed Boost",
    "No Fall Damage",
    "Flee Killer (Auto TP Menjauh)",
    "Auto Gen Rush",
    "Bypass Generator",
    "Enable Auto Skillcheck Perfect",
    "King's Scourge",
    "Bypass Gate",
    "Instant Teleport (Gate)",
    "Perfect Vault",
    "Flowstate",
    "Quick Recovery",
    "Self Progress Heal",
    "Auto Heal Team",
    "Auto Parry V1",
    "Auto Parry V2",
    "Safety Parry",
    "Aggressive Parry V1",
    "Enable Auto Hook",
    "Kill All (Risk Ban)",
    "Auto Attack (No Animation)",
    "No Flashlight (Anti Blind)",
    "Drop All Pallets Instantly",
    "No Cooldown (M2 & Q) [Hidden]",
    "No Cooldown (Q & M2) [Myers]",
    "No Cooldown (M2 & Q) [Abysswalker]",
    "Infinite Frenzy [Jeff]",
    "Infinite Pursuit & Invis [Jason]",
    "Hidden M2 Aimbot (Nearest Visible)",
    "Trigger Auto Parry (Fake Hit)",
    "Instant Break (Pallet & Gen)",
    "Silent Flask (The Cure)",
    "Auto Aim Senter ke Killer",
    "Auto Prediksi",
    "Veil",
    "Enable Custom Animation",
    "Enable Avatar Changer",
    "Predict Killer",
    "Skip Cutscenes"
}

for _, name in ipairs(gameSpecific) do
    if not Hooks[name] then
        Hooks[name] = function(value)
            Values[name] = value

            if value == true then
                print("[Aletta] " .. name ..
                    " ON - menunggu integrasi resmi project/server.")
            end
        end
    end
end


-- =========================================================
-- KILLER FEATURE RUNTIME
-- Dibangun dari remote/object yang benar-benar ditemukan pada project.
-- Remote attack/hook/break tersedia, tetapi payload server tidak tersimpan
-- pada rbxlx; fitur client-side tidak memalsukan payload yang tidak terverifikasi.
-- =========================================================
local KillerRuntime = {
    walkOriginal = nil,
    cameraMode = "Default",
    rangeVisual = nil,
    attackConn = nil,
    aimConn = nil,
    collisionConn = nil,
    blindConn = nil,
    lastAttack = 0,
    mask = "Default",
}

local function killerRoot()
    return root()
end

local function nearestSurvivor(maxDistance)
    local r = killerRoot()
    if not r then return nil, math.huge end
    local best, bestDist = nil, maxDistance or math.huge
    for _, p in ipairs(Players:GetPlayers()) do
        if p ~= player and p.Character then
            local role = detectESPExplicitRole(p)
            local h = p.Character:FindFirstChildOfClass("Humanoid")
            local pr = p.Character:FindFirstChild("HumanoidRootPart")
            if h and pr and h.Health > 0 and role == "Survivor" then
                local d = (pr.Position - r.Position).Magnitude
                if d <= bestDist then
                    best, bestDist = p, d
                end
            end
        end
    end
    return best, bestDist
end

local function getAttackRemote(name)
    local remotes = ReplicatedStorage:FindFirstChild("Remotes")
    local attacks = remotes and remotes:FindFirstChild("Attacks")
    local remote = attacks and attacks:FindFirstChild(name)
    if remote and remote:IsA("RemoteEvent") then return remote end
    return nil
end

local function getEquippedAttackTool(mode)
    local c = character()
    if not c then return nil end
    local wanted = tostring(mode or Values["Attack Mode"] or "Basic Attack")
    local names = wanted == "Lunge"
        and {"Lunge", "BasicAttack", "Basic Attack"}
        or {"BasicAttack", "Basic Attack", "Lunge"}
    for _, n in ipairs(names) do
        local tool = c:FindFirstChild(n)
        if tool and tool:IsA("Tool") then return tool end
    end
    for _, obj in ipairs(c:GetChildren()) do
        if obj:IsA("Tool") and (obj.Name:lower():find("attack") or obj.Name:lower():find("lunge")) then
            return obj
        end
    end
    return nil
end

local function attackOnce(mode)
    local tool = getEquippedAttackTool(mode)
    if tool then
        local ok = pcall(function() tool:Activate() end)
        if ok then return true end
    end
    -- Remote names are verified, but their server payload is not present in
    -- the supplied project source, so no guessed FireServer arguments are sent.
    local remote = getAttackRemote(mode == "Lunge" and "Lunge" or "BasicAttack")
    if remote then
        print("[Aletta] Attack remote ditemukan:", remote:GetFullName(), "payload server belum terverifikasi")
    end
    return false
end

local function destroyKillerRange()
    if KillerRuntime.rangeVisual then
        pcall(function() KillerRuntime.rangeVisual:Destroy() end)
        KillerRuntime.rangeVisual = nil
    end
end

local function updateKillerRange()
    local r = killerRoot()
    if not r then destroyKillerRange(); return end
    local radius = math.max(1, tonumber(Values["Hit Radius"]) or 8)
    if not KillerRuntime.rangeVisual or KillerRuntime.rangeVisual.Parent ~= r then
        destroyKillerRange()
        local a = Instance.new("CylinderHandleAdornment")
        a.Name = "AlettaKillerHitRange"
        a.Adornee = r
        a.AlwaysOnTop = true
        a.ZIndex = 6
        a.Transparency = 0.78
        a.Height = 0.08
        a.Radius = radius
        a.CFrame = CFrame.new(0, -2.85, 0)
        a.Parent = r
        KillerRuntime.rangeVisual = a
    else
        KillerRuntime.rangeVisual.Radius = radius
    end
end

local function stopKillerAttackLoop()
    disconnectList("Auto Attack (No Animation)")
    KillerRuntime.attackConn = nil
end

local function startKillerAttackLoop()
    stopKillerAttackLoop()
    KillerRuntime.attackConn = FeatureManager:Connect("Auto Attack (No Animation)", RunService.Heartbeat, function()
        local range = math.max(1, tonumber(Values["Attack Range (studs)"]) or 12)
        local target, dist = nearestSurvivor(range)
        if not target then return end
        local delay = math.max(0.04, (tonumber(Values["Hit Delay"]) or 225) / 1000)
        if os.clock() - KillerRuntime.lastAttack < delay then return end
        local mode = tostring(Values["Attack Mode"] or "Basic Attack")
        if attackOnce(mode) then KillerRuntime.lastAttack = os.clock() end
    end)
end

Hooks["Walk Speed"] = function(on)
    local h = humanoid()
    if not h then return end
    if KillerRuntime.walkOriginal == nil then KillerRuntime.walkOriginal = h.WalkSpeed end
    if on then
        h.WalkSpeed = math.max(0, tonumber(Values["Walk Speed Value"]) or 16)
    else
        h.WalkSpeed = KillerRuntime.walkOriginal or 16
    end
end

Hooks["Walk Speed Value"] = function(value)
    Values["Walk Speed Value"] = math.clamp(tonumber(value) or 160, 0, 320)
    if Values["Walk Speed"] then
        local h = humanoid()
        if h then h.WalkSpeed = Values["Walk Speed Value"] end
    end
end

Hooks["Attack Mode"] = function(value)
    Values["Attack Mode"] = tostring(value or "Basic Attack")
end

Hooks["Show Range"] = function(on)
    if on then updateKillerRange() else destroyKillerRange() end
end

Hooks["Hit Radius"] = function(value)
    Values["Hit Radius"] = tonumber(value) or 8
    if Values["Show Range"] then updateKillerRange() end
end

Hooks["Hit Delay"] = function(value)
    Values["Hit Delay"] = tonumber(value) or 225
end

Hooks["Auto Aim Hidden"] = function(on)
    disconnectList("Auto Aim Hidden")
    if not on then return end
    FeatureManager:Connect("Auto Aim Hidden", RunService.RenderStepped, function()
        local target = nearestSurvivor(tonumber(Values["Hit Radius"]) or 8)
        if not target then return end
        local tr = target.Character and target.Character:FindFirstChild("HumanoidRootPart")
        local cam = workspace.CurrentCamera
        if cam and tr then
            cam.CFrame = CFrame.lookAt(cam.CFrame.Position, tr.Position)
        end
    end)
end

Hooks["One Hit"] = function(on)
    Values["One Hit"] = on == true
    -- One-hit damage is server-authoritative. Keep the control active and
    -- let Auto Attack use the real attack tool rather than inventing damage.
end

Hooks["Auto Attack (No Animation)"] = function(on)
    stopKillerAttackLoop()
    if on then startKillerAttackLoop() end
end

Hooks["Infinite Lunge"] = function(on)
    disconnectList("Infinite Lunge")
    if not on then return end
    FeatureManager:Connect("Infinite Lunge", RunService.Heartbeat, function()
        if tostring(Values["Attack Mode"] or "Basic Attack") ~= "Lunge" then return end
        local target = nearestSurvivor(tonumber(Values["Hit Radius"]) or 8)
        if target then attackOnce("Lunge") end
    end)
end

Hooks["Counter Parry"] = function(on)
    disconnectList("Counter Parry")
    if not on then return end
    FeatureManager:Connect("Counter Parry", RunService.Heartbeat, function()
        -- Uses the existing local parry tool path; no unverified server payload.
        local target = nearestSurvivor(tonumber(Values["Hit Radius"]) or 8)
        if not target then return end
        local tool
        local c = character()
        if c then
            tool = c:FindFirstChild("Parrying Dagger") or c:FindFirstChildWhichIsA("Tool")
        end
        if tool and tool:IsA("Tool") then pcall(function() tool:Activate() end) end
    end)
end

local function stripBlindEffects()
    for _, obj in ipairs(Lighting:GetChildren()) do
        if obj:IsA("BlurEffect") or obj:IsA("ColorCorrectionEffect") then
            local n = obj.Name:lower()
            if n:find("blind") or n:find("flash") or n:find("stun") then
                obj.Enabled = false
            end
        end
    end
end

Hooks["Anti Blind"] = function(on)
    disconnectList("Anti Blind")
    if not on then return end
    stripBlindEffects()
    FeatureManager:Connect("Anti Blind", RunService.Heartbeat, stripBlindEffects)
end
Hooks["No Flashlight (Anti Blind)"] = Hooks["Anti Blind"]

Hooks["Block Windows/Pallet"] = function(on)
    disconnectList("Block Windows/Pallet")
    if not on then return end
    FeatureManager:Connect("Block Windows/Pallet", RunService.Heartbeat, function()
        local r = killerRoot(); if not r then return end
        for _, obj in ipairs(workspace:GetDescendants()) do
            if obj:IsA("BasePart") then
                local n = obj.Name:lower()
                if n:find("pallet") or n:find("window") then
                    if (obj.Position - r.Position).Magnitude <= 7 then
                        obj.CanCollide = false
                    end
                end
            end
        end
    end)
end

Hooks["Bypass Skill Gendong"] = function(on)
    Values["Bypass Skill Gendong"] = on == true
    -- Carry remotes are verified in the project, but the required server
    -- payload/state transition is not available in the saved source.
end

local function resetNoCooldownConnections(name)
    disconnectList(name)
end

Hooks["No Cooldown Stalker/Hidden"] = function(on)
    Values["No Cooldown Stalker/Hidden"] = on == true
end
Hooks["No Cooldown (M2 & Q) [Hidden]"] = Hooks["No Cooldown Stalker/Hidden"]
Hooks["No Cooldown (Q & M2) [Myers]"] = Hooks["No Cooldown Stalker/Hidden"]
Hooks["No Cooldown (M2 & Q) [Abysswalker]"] = Hooks["No Cooldown Stalker/Hidden"]

Hooks["Break Speed"] = function(value)
    Values["Break Speed"] = tonumber(value) or 5
    local animator = humanoid() and humanoid():FindFirstChildOfClass("Animator")
    if animator then
        for _, track in ipairs(animator:GetPlayingAnimationTracks()) do
            local n = track.Name:lower()
            if n:find("break") or n:find("kick") then
                pcall(function() track:AdjustSpeed(math.max(0.1, Values["Break Speed"])) end)
            end
        end
    end
end

Hooks["3rd Person Camera"] = function(value)
    Values["3rd Person Camera"] = tostring(value or "Default")
    local cam = workspace.CurrentCamera
    if not cam then return end
    if value == "First Person" then
        player.CameraMode = Enum.CameraMode.LockFirstPerson
        player.CameraMaxZoomDistance = 0.5
    elseif value == "3rd Person" then
        player.CameraMode = Enum.CameraMode.Classic
        player.CameraMinZoomDistance = 8
        player.CameraMaxZoomDistance = 24
    else
        player.CameraMode = Enum.CameraMode.Classic
        player.CameraMinZoomDistance = 0.5
        player.CameraMaxZoomDistance = 128
    end
end

Hooks["Ganti Topeng Masked"] = function(value)
    KillerRuntime.mask = tostring(value or "Default")
    Values["Ganti Topeng Masked"] = KillerRuntime.mask
    -- Mask model/remote is not exposed in the supplied source, so the
    -- selection is stored without fabricating a server payload.
end

Hooks["Enable Auto Hook"] = function(on)
    disconnectList("Enable Auto Hook")
    if not on then return end
    FeatureManager:Connect("Enable Auto Hook", RunService.Heartbeat, function()
        -- The project exposes Carry/HookEvent and HookCommit. Their server
        -- payload is not present in the saved source, so we only detect a
        -- valid nearby survivor and leave the authoritative hook transition
        -- to the game's own carry controller.
        local target = nearestSurvivor(8)
        if target then
            Values["Auto Hook Target"] = target.Name
        else
            Values["Auto Hook Target"] = nil
        end
    end)
end

Hooks["Kill All (Risk Ban)"] = function(on)
    Values["Kill All (Risk Ban)"] = on == true
    -- No unverified damage/kill payload is fabricated. The toggle can be
    -- used by the project's own server-authorized kill controller.
end

Hooks["Drop All Pallets Instantly"] = function(on)
    if on == nil or on == true then task.spawn(dropAllPalletsOnce) end
end

Hooks["Hidden M2 Aimbot (Nearest Visible)"] = function(on)
    disconnectList("Hidden M2 Aimbot (Nearest Visible)")
    if not on then return end
    FeatureManager:Connect("Hidden M2 Aimbot (Nearest Visible)", RunService.RenderStepped, function()
        local target = nearestSurvivor(tonumber(Values["Hit Radius"]) or 8)
        local tr = target and target.Character and target.Character:FindFirstChild("HumanoidRootPart")
        local cam = workspace.CurrentCamera
        if cam and tr then cam.CFrame = CFrame.lookAt(cam.CFrame.Position, tr.Position) end
    end)
end

Hooks["Enable Mask Selection GUI"] = function(on)
    Values["Enable Mask Selection GUI"] = on == true
    if on then
        print("[Aletta] Mask Selection GUI aktif. Pilihan: Default / Mask 1 / Mask 2 / Mask 3 / Mask 4")
    end
end

Hooks["Fake Containment (Instant Vault)"] = function(on)
    disconnectList("Fake Containment (Instant Vault)")
    if not on then return end
    FeatureManager:Connect("Fake Containment (Instant Vault)", RunService.Heartbeat, function()
        local r = killerRoot(); if not r then return end
        -- Find the nearest vault prompt; triggering it uses Roblox's normal
        -- client interaction path instead of inventing a remote payload.
        local best, bestD
        for _, obj in ipairs(workspace:GetDescendants()) do
            if obj:IsA("ProximityPrompt") and obj.Enabled then
                local n = (obj.Name .. " " .. obj.ActionText .. " " .. obj.ObjectText):lower()
                if n:find("vault") or n:find("window") then
                    local part = obj.Parent and (obj.Parent:IsA("BasePart") and obj.Parent or obj.Parent:FindFirstChildWhichIsA("BasePart", true))
                    if part then
                        local d = (part.Position-r.Position).Magnitude
                        if d <= 7 and (not bestD or d < bestD) then best,bestD=obj,d end
                    end
                end
            end
        end
        if best then pcall(function() best:InputHoldBegin(); task.delay(math.max(0.05,best.HoldDuration), function() if best.Parent then best:InputHoldEnd() end end) end) end
    end)
end

Hooks["Instant Break (Pallet & Gen)"] = function(on)
    Values["Instant Break (Pallet & Gen)"] = on == true
    -- BreakGenCommit exists in the project, but its FireServer payload is not
    -- available in the saved source. No guessed payload is transmitted.
end

-- Re-apply selected killer movement/camera settings after respawn.
player.CharacterAdded:Connect(function()
    task.wait(0.25)
    if Values["Noclip"] then setNoClipState(true) end
    if Values["Camera DBD"] then applyDBDCamera() end
    if Values["Fake Name"] then Hooks["Fake Name"](true) end
    if Values["Emote GUI"] then Hooks["Emote GUI"](true) end
    if Values["Walk Speed"] then pcall(function() Hooks["Walk Speed"](true) end) end
    if Values["Show Range"] then pcall(updateKillerRange) end
    if Values["3rd Person Camera"] then pcall(function() Hooks["3rd Person Camera"](Values["3rd Person Camera"]) end) end
end)


-- =========================================================
-- SURVIVOR 1x CLICK ACTIONS
-- Auto Escape + Drop All Pallets.
-- Menggunakan struktur map/remotes yang terverifikasi dari project:
--   Map/Map1 -> Exit1/Exit2 -> Gate/ExitLever/Fininshline
--   Remotes.gate
--   Remotes.Pallet.PalletDropEvent
-- =========================================================
local function getRuntimeMap()
    return workspace:FindFirstChild("Map") or workspace:FindFirstChild("Map1")
end

local function getExitFolders()
    local map = getRuntimeMap()
    local exits = {}
    if not map then return exits end

    for _, name in ipairs({"Exit1", "Exit2"}) do
        local exit = map:FindFirstChild(name, true)
        if exit then
            table.insert(exits, exit)
        end
    end

    return exits
end

local function getObjectPart(obj, names)
    if not obj then return nil end

    if obj:IsA("BasePart") then
        return obj
    end

    for _, name in ipairs(names or {}) do
        local part = obj:FindFirstChild(name, true)
        if part and part:IsA("BasePart") then
            return part
        end
    end

    if obj:IsA("Model") and obj.PrimaryPart and obj.PrimaryPart:IsA("BasePart") then
        return obj.PrimaryPart
    end

    return obj:FindFirstChildWhichIsA("BasePart", true)
end

local function getNearestExit()
    local r = root()
    local best, bestPart, bestDist = nil, nil, math.huge

    for _, exitFolder in ipairs(getExitFolders()) do
        local finish = exitFolder:FindFirstChild("Fininshline", true)
        local gate = exitFolder:FindFirstChild("Gate", true)
        local part = getObjectPart(finish, {"Fininshline"})
            or getObjectPart(gate, {"Box", "Frame"})

        if part then
            local d = r and (part.Position - r.Position).Magnitude or 0
            if d < bestDist then
                best = exitFolder
                bestPart = part
                bestDist = d
            end
        end
    end

    return best, bestPart, bestDist
end

local function fireGateRemote(exitFolder)
    local remotes = ReplicatedStorage:FindFirstChild("Remotes")
    local gateRemote = remotes and remotes:FindFirstChild("gate")
    if not (gateRemote and gateRemote:IsA("RemoteEvent")) then
        return false, "Remotes.gate tidak ditemukan"
    end

    local gate = exitFolder and exitFolder:FindFirstChild("Gate", true)
    if not gate then
        return false, "Gate tidak ditemukan"
    end

    -- Payload utama: model Gate. Server tetap menentukan apakah gate
    -- memang boleh dibuka/escape pada state ronde saat ini.
    local ok, err = pcall(function()
        gateRemote:FireServer(gate)
    end)

    return ok, err
end

local function autoEscapeOnce()
    local r = root()
    if not r then
        warn("[Aletta] Auto Escape: HumanoidRootPart tidak ditemukan.")
        return
    end

    local exitFolder, targetPart = getNearestExit()
    if not exitFolder or not targetPart then
        warn("[Aletta] Auto Escape: Exit1/Exit2 tidak ditemukan di runtime map.")
        return
    end

    local oldCFrame = r.CFrame

    -- Coba trigger gate lebih dulu, lalu pindahkan player ke Finishline.
    fireGateRemote(exitFolder)
    task.wait(0.12)

    local finish = exitFolder:FindFirstChild("Fininshline", true)
    local destination = getObjectPart(finish, {"Fininshline"}) or targetPart

    if destination then
        -- Sedikit di atas finish line agar tidak tersangkut di geometry.
        r.CFrame = destination.CFrame + Vector3.new(0, 2.5, 0)
        task.wait(0.18)

        -- Satu kali retry gate setelah posisi sudah di area exit.
        fireGateRemote(exitFolder)
        task.wait(0.18)
    end

    -- Jangan langsung mengembalikan posisi. Biarkan karakter tetap di
    -- Finishline agar touch/exit validation server memiliki waktu diproses.
    -- Posisi lama hanya disimpan sebagai fallback informasi; ronde yang
    -- berhasil akan dipindahkan/diakhiri oleh server.
    if not r.Parent then
        return
    end
end

local function getRuntimePallets()
    local map = getRuntimeMap()
    local results = {}
    if not map then return results end

    local palletsFolder = map:FindFirstChild("Pallets", true)
    local source = palletsFolder or map

    for _, obj in ipairs(source:GetDescendants()) do
        if obj:IsA("Model") and obj.Name:lower():find("pallet") then
            local part = obj.PrimaryPart
                or obj:FindFirstChild("HumanoidRootPart", true)
                or obj:FindFirstChildWhichIsA("BasePart", true)
            if part then
                table.insert(results, {model = obj, part = part})
            end
        end
    end

    return results
end

local function dropAllPalletsOnce()
    local remotes = ReplicatedStorage:FindFirstChild("Remotes")
    local palletFolder = remotes and remotes:FindFirstChild("Pallet")
    local dropEvent = palletFolder and palletFolder:FindFirstChild("PalletDropEvent")

    if not (dropEvent and dropEvent:IsA("RemoteEvent")) then
        warn("[Aletta] Drop All Pallets: Remotes.Pallet.PalletDropEvent tidak ditemukan.")
        return
    end

    local r = root()
    if not r then
        warn("[Aletta] Drop All Pallets: HumanoidRootPart tidak ditemukan.")
        return
    end

    local pallets = getRuntimePallets()
    if #pallets == 0 then
        warn("[Aletta] Drop All Pallets: tidak ada pallet runtime yang ditemukan.")
        return
    end

    local oldCFrame = r.CFrame
    local dropped = 0

    -- Server game ini memiliki remote khusus drop pallet. Kita kirim
    -- model pallet sebagai target; tidak memakai remote commit client.
    for _, data in ipairs(pallets) do
        local pallet = data.model
        local part = data.part

        if pallet and pallet.Parent and part and part.Parent then
            -- Dekatkan karakter ke pallet supaya validasi jarak server
            -- tetap memiliki konteks interaksi normal.
            pcall(function()
                r.CFrame = part.CFrame + Vector3.new(0, 2.5, 0)
            end)

            task.wait(0.04)

            local ok = pcall(function()
                dropEvent:FireServer(pallet)
            end)

            if ok then
                dropped += 1
            end

            task.wait(0.04)
        end
    end

    if r and r.Parent then
        r.CFrame = oldCFrame
    end

    print(string.format("[Aletta] Drop All Pallets selesai: %d/%d remote drop terkirim.", dropped, #pallets))
end

Hooks["Auto Escape [ 1x Click ]"] = function()
    task.spawn(autoEscapeOnce)
end

Hooks["Drop All Pallets [ 1x Click ]"] = function()
    task.spawn(dropAllPalletsOnce)
end

Hooks["Drop All Pallets Instantly"] = function(on)
    -- Tetap dukung tombol OP lama; toggle tidak diperlukan.
    if on == nil or on == true then
        task.spawn(dropAllPalletsOnce)
    end
end

-- =========================================================
-- SURVIVOR SAFETY / PALLET SYSTEM
-- Anti Block Window, Pallet Save Team, Safe Mode, Radius Pallet.
-- Semua fitur di bawah memakai objek runtime yang memang ada di map.
-- Tidak menebak payload remote baru.
-- =========================================================
local PalletSafety = {
    antiBlock = false,
    saveTeam = false,
    safeMode = true,
    radius = 12,
    connection = nil,
    windowParts = {},
    lastSave = 0,
    lastWindowRefresh = 0,
}

local function getPalletRadius()
    return math.clamp(tonumber(Values["Radius Pallet"]) or PalletSafety.radius or 12, 2, 40)
end

local function isStandingPallet(model)
    if not model or not model.Parent then return false end
    if model:GetAttribute("Dropped") == true then return false end
    if model:GetAttribute("IsDropped") == true then return false end
    if model:GetAttribute("Down") == true then return false end

    -- Beberapa build memakai state/boolean Value.
    for _, n in ipairs({"Dropped", "IsDropped", "Down", "Broken"}) do
        local v = model:FindFirstChild(n, true)
        if v and v:IsA("BoolValue") and v.Value then
            return false
        end
    end

    return true
end

local function palletPart(model)
    if not model then return nil end
    return model.PrimaryPart
        or model:FindFirstChild("PrimaryPartPallet", true)
        or model:FindFirstChildWhichIsA("BasePart", true)
end

local function nearestStandingPallet(maxDistance)
    local r = root()
    if not r then return nil end

    local best, bestDist = nil, maxDistance or math.huge
    for _, data in ipairs(getRuntimePallets()) do
        local model = data.model
        local part = data.part or palletPart(model)
        if model and part and model.Parent and isStandingPallet(model) then
            local d = (part.Position - r.Position).Magnitude
            if d <= bestDist then
                best, bestDist = model, d
            end
        end
    end
    return best, bestDist
end

local function getNearestTeammate(maxDistance)
    local r = root()
    if not r then return nil end

    local myRole = detectESPExplicitRole(player)
    local myTeam = player.Team and player.Team.Name
    local best, bestDist = nil, maxDistance or math.huge

    for _, p in ipairs(Players:GetPlayers()) do
        if p ~= player and p.Character then
            local pr = p.Character:FindFirstChild("HumanoidRootPart")
            local ph = p.Character:FindFirstChildOfClass("Humanoid")
            if pr and ph and ph.Health > 0 then
                local sameTeam = false
                if player.Team and p.Team and player.Team == p.Team then
                    sameTeam = true
                elseif myTeam and p.Team and tostring(p.Team.Name) == tostring(myTeam) then
                    sameTeam = true
                else
                    local role = detectESPExplicitRole(p)
                    if myRole == "Survivor" and role == "Survivor" then
                        sameTeam = true
                    end
                end

                if sameTeam then
                    local d = (pr.Position - r.Position).Magnitude
                    if d <= bestDist then
                        best, bestDist = p, d
                    end
                end
            end
        end
    end
    return best, bestDist
end

local function killerNearPosition(position, radius)
    if not position then return nil end
    local best, bestDist = nil, radius or math.huge
    for _, p in ipairs(Players:GetPlayers()) do
        if p ~= player and isKillerPlayer(p) then
            local c = p.Character
            local pr = c and c:FindFirstChild("HumanoidRootPart")
            local h = c and c:FindFirstChildOfClass("Humanoid")
            if pr and h and h.Health > 0 then
                local d = (pr.Position - position).Magnitude
                if d <= bestDist then
                    best, bestDist = p, d
                end
            end
        end
    end
    return best, bestDist
end

local function fireDropPalletAt(model)
    local remotes = ReplicatedStorage:FindFirstChild("Remotes")
    local palletFolder = remotes and remotes:FindFirstChild("Pallet")
    local dropEvent = palletFolder and palletFolder:FindFirstChild("PalletDropEvent")
    if not (dropEvent and dropEvent:IsA("RemoteEvent")) then return false end
    if not (model and model.Parent) then return false end

    -- Payload yang sama dengan 1x Click Drop All Pallets.
    return pcall(function()
        dropEvent:FireServer(model)
    end)
end

local function runPalletSaveTeam()
    if not PalletSafety.saveTeam then return end
    if PalletSafety.safeMode ~= true then return end

    local now = os.clock()
    if now - PalletSafety.lastSave < 0.45 then return end

    local radius = getPalletRadius()
    local r = root()
    if not r then return end

    -- Safe Mode: hanya bekerja jika user sendiri berada dekat pallet.
    local pallet, palletDist = nearestStandingPallet(radius)
    if not pallet then return end

    local part = palletPart(pallet)
    if not part then return end

    -- Harus ada teammate dekat area pallet.
    local teammate = nil
    local teammateDist = math.huge
    for _, p in ipairs(Players:GetPlayers()) do
        if p ~= player and p.Character then
            local pr = p.Character:FindFirstChild("HumanoidRootPart")
            local ph = p.Character:FindFirstChildOfClass("Humanoid")
            if pr and ph and ph.Health > 0 then
                local sameTeam = (player.Team and p.Team and player.Team == p.Team)
                if not sameTeam then
                    local role = detectESPExplicitRole(p)
                    sameTeam = (role == "Survivor")
                end
                if sameTeam then
                    local d = (pr.Position - part.Position).Magnitude
                    if d <= radius and d < teammateDist then
                        teammate, teammateDist = p, d
                    end
                end
            end
        end
    end
    if not teammate then return end

    -- Killer harus benar-benar mendekati teammate/pallet agar pallet tidak
    -- terbuang sia-sia.
    local killer = killerNearPosition(teammate.Character.HumanoidRootPart.Position, radius * 1.5)
    if not killer then
        killer = killerNearPosition(part.Position, radius * 1.5)
    end
    if not killer then return end

    if fireDropPalletAt(pallet) then
        PalletSafety.lastSave = now
        print("[Aletta] Pallet Save Team: pallet dijatuhkan untuk teammate.")
    end
end

local function collectWindowParts()
    local map = getRuntimeMap()
    if not map then return {} end

    local results = {}
    for _, obj in ipairs(map:GetDescendants()) do
        if obj:IsA("BasePart") then
            local n = string.lower(obj.Name)
            local parentName = obj.Parent and string.lower(obj.Parent.Name) or ""
            if n == "window" or n == "window_b" or n == "window_c"
                or n == "window_c_glass" or n:find("window_glass", 1, true)
                or n:find("window_pane", 1, true)
                or parentName == "window" or parentName == "vault" then
                table.insert(results, obj)
            end
        end
    end
    return results
end

local function restoreWindowCollision()
    for part, oldValue in pairs(PalletSafety.windowParts) do
        if part and part.Parent then
            pcall(function()
                part.CanCollide = oldValue
            end)
        end
    end
    table.clear(PalletSafety.windowParts)
end

local function updateAntiBlockWindow()
    if not PalletSafety.antiBlock then
        restoreWindowCollision()
        return
    end

    local r = root()
    if not r then return end

    local radius = getPalletRadius()
    local now = os.clock()
    if now - PalletSafety.lastWindowRefresh < 0.12 then return end
    PalletSafety.lastWindowRefresh = now

    -- Bersihkan cache part yang sudah hilang.
    for part in pairs(PalletSafety.windowParts) do
        if not part or not part.Parent then
            PalletSafety.windowParts[part] = nil
        end
    end

    for _, part in ipairs(collectWindowParts()) do
        if part and part.Parent then
            local d = (part.Position - r.Position).Magnitude
            if d <= radius then
                if PalletSafety.windowParts[part] == nil then
                    PalletSafety.windowParts[part] = part.CanCollide
                end
                -- Local anti-block: window/vault geometry tidak menahan
                -- collision client ketika player berada di area interaksi.
                pcall(function()
                    part.CanCollide = false
                end)
            elseif PalletSafety.windowParts[part] ~= nil then
                local old = PalletSafety.windowParts[part]
                PalletSafety.windowParts[part] = nil
                pcall(function()
                    part.CanCollide = old
                end)
            end
        end
    end
end

local function stopPalletSafety()
    if PalletSafety.connection then
        pcall(function() PalletSafety.connection:Disconnect() end)
        PalletSafety.connection = nil
    end
    restoreWindowCollision()
end

local function startPalletSafety()
    stopPalletSafety()
    PalletSafety.connection = RunService.Heartbeat:Connect(function()
        updateAntiBlockWindow()
        runPalletSaveTeam()
    end)
end

Hooks["Anti Block Window"] = function(on)
    PalletSafety.antiBlock = on == true
    if PalletSafety.antiBlock or PalletSafety.saveTeam then
        startPalletSafety()
    else
        stopPalletSafety()
    end
end

Hooks["Pallet Save Team"] = function(on)
    PalletSafety.saveTeam = on == true
    if PalletSafety.antiBlock or PalletSafety.saveTeam then
        startPalletSafety()
    else
        stopPalletSafety()
    end
end

Hooks["Safe Mode"] = function(on)
    PalletSafety.safeMode = on == true
    if PalletSafety.antiBlock or PalletSafety.saveTeam then
        startPalletSafety()
    else
        stopPalletSafety()
    end
end

Hooks["Radius Pallet"] = function(value)
    PalletSafety.radius = math.clamp(tonumber(value) or 12, 2, 40)
    Values["Radius Pallet"] = PalletSafety.radius
end

-- =========================================================
-- SURVIVOR AUTO / FLEE / PERKS - V11
-- Menggunakan remote yang memang ada di project:
-- Healing, Window, Mechanics, Teleport, dan Vault.
-- Fitur movement/perk lokal tidak memalsukan state server.
-- =========================================================
local SurvivorRuntime = {
    fleeConnection = nil,
    sprintConnection = nil,
    healConnection = nil,
    autoHealTeamConnection = nil,
    crouchDodgeConnection = nil,
    bandageConnection = nil,
    crouchVeilConnection = nil,
    antiSlowConnection = nil,
    quickRecoveryConnection = nil,
    flowstateConnection = nil,
    perfectVaultConnection = nil,
    lastHeal = 0,
    lastBandage = 0,
    lastCrouch = 0,
    lastVault = 0,
    lastTeleport = 0,
    originalSpeed = nil,
    originalJump = nil,
}

local function disconnectRuntime(name)
    local c = SurvivorRuntime[name]
    if c then
        pcall(function() c:Disconnect() end)
        SurvivorRuntime[name] = nil
    end
end

local function disconnectAllSurvivorRuntime()
    for _, name in ipairs({
        "fleeConnection", "sprintConnection", "healConnection", "autoHealTeamConnection", "crouchDodgeConnection",
        "bandageConnection", "crouchVeilConnection", "antiSlowConnection",
        "quickRecoveryConnection", "flowstateConnection", "perfectVaultConnection"
    }) do
        disconnectRuntime(name)
    end
end

local function getRemote(path)
    local obj = ReplicatedStorage
    for part in string.gmatch(path, "[^/]+") do
        obj = obj and obj:FindFirstChild(part)
    end
    return obj
end

local function getHumanoidState()
    local h = humanoid()
    return h and h:GetState() or nil
end

local function isAliveCharacter(c)
    local h = c and c:FindFirstChildOfClass("Humanoid")
    return h and h.Health > 0
end

local function nearestKiller(maxDistance)
    local r = root()
    if not r then return nil, math.huge end
    local best, bestDist = nil, maxDistance or math.huge
    for _, p in ipairs(Players:GetPlayers()) do
        if p ~= player and isKillerPlayer(p) and p.Character and isAliveCharacter(p.Character) then
            local pr = p.Character:FindFirstChild("HumanoidRootPart")
            if pr then
                local d = (pr.Position - r.Position).Magnitude
                if d < bestDist then
                    best, bestDist = p, d
                end
            end
        end
    end
    return best, bestDist
end

local function setCrouch(state)
    local remote = getRemote("Remotes/Mechanics/Crouch")
    if not (remote and remote:IsA("RemoteEvent")) then return false end
    local ok = pcall(function()
        remote:FireServer(state == true)
    end)
    return ok
end

local function setLocalSpeed(value)
    local h = humanoid()
    if not h then return end
    if SurvivorRuntime.originalSpeed == nil then
        SurvivorRuntime.originalSpeed = h.WalkSpeed
    end
    h.WalkSpeed = math.max(0, tonumber(value) or 16)
end

local function restoreLocalSpeed()
    local h = humanoid()
    if h then
        h.WalkSpeed = SurvivorRuntime.originalSpeed or originalWalkSpeed or 16
    end
end

local function healRemote(targetPlayer)
    local remote = getRemote("Remotes/Healing/HealEvent")
    if not (remote and remote:IsA("RemoteEvent")) then return false end

    -- Build project menggunakan HealEvent sebagai server-side healing
    -- entry point. Target player dikirim untuk team-heal; self-heal tidak
    -- membutuhkan target tambahan.
    if targetPlayer and targetPlayer ~= player then
        return pcall(function() remote:FireServer(targetPlayer) end)
    end
    return pcall(function() remote:FireServer() end)
end

local function findLowHealthTeammate(maxDistance)
    local r = root()
    if not r then return nil, math.huge end
    local best, bestDist, bestHealth = nil, math.huge, math.huge
    for _, p in ipairs(Players:GetPlayers()) do
        if p ~= player and p.Character and isAliveCharacter(p.Character) then
            local ph = p.Character:FindFirstChildOfClass("Humanoid")
            local pr = p.Character:FindFirstChild("HumanoidRootPart")
            local same = player.Team and p.Team and player.Team == p.Team
            if not same then
                same = detectESPExplicitRole(p) == "Survivor"
            end
            if same and ph and pr and ph.Health < ph.MaxHealth then
                local d = (pr.Position - r.Position).Magnitude
                if d <= (maxDistance or 20) and (ph.Health < bestHealth or (ph.Health == bestHealth and d < bestDist)) then
                    best, bestDist, bestHealth = p, d, ph.Health
                end
            end
        end
    end
    return best, bestDist
end

local function getNearestTargetPartByName(names, maxDistance)
    local map = getRuntimeMap()
    local r = root()
    if not map or not r then return nil, math.huge end
    local best, bestDist = nil, maxDistance or math.huge
    for _, obj in ipairs(map:GetDescendants()) do
        local n = string.lower(obj.Name)
        local wanted = false
        for _, key in ipairs(names) do
            if n == string.lower(key) or n:find(string.lower(key), 1, true) then
                wanted = true
                break
            end
        end
        if wanted and obj:IsA("BasePart") then
            local d = (obj.Position - r.Position).Magnitude
            if d < bestDist then best, bestDist = obj, d end
        end
    end
    return best, bestDist
end

local function teleportToPart(part)
    local r = root()
    if not (r and part) then return false end
    if os.clock() - SurvivorRuntime.lastTeleport < 0.35 then return false end
    SurvivorRuntime.lastTeleport = os.clock()
    local ok = pcall(function()
        r.CFrame = part.CFrame + Vector3.new(0, 3, 0)
    end)
    return ok
end

local function getTeleportTarget()
    local destination = tostring(Values["Teleport Destination"] or "Gate")
    local map = getRuntimeMap()
    if not map then return nil end

    if destination == "Teammate" then
        local p = getNearestTeammate(1000)
        local c = p and p.Character
        return c and c:FindFirstChild("HumanoidRootPart")
    elseif destination == "Killer" then
        local p = nearestKiller(1000)
        local c = p and p.Character
        return c and c:FindFirstChild("HumanoidRootPart")
    elseif destination == "Generator" then
        return getNearestTargetPartByName({"Generator"}, 1000)
    elseif destination == "Pallet" then
        local pallet = nearestStandingPallet(1000)
        return pallet and palletPart(pallet)
    elseif destination == "Hook" then
        return getNearestTargetPartByName({"Hook"}, 1000)
    else
        local _, part = getNearestExit()
        return part
    end
end

local function instantTeleport()
    local part = getTeleportTarget()
    if not part then
        warn("[Aletta] Teleport: target tidak ditemukan.")
        return
    end
    teleportToPart(part)
end

Hooks["Self Proges Heal"] = function(on)
    Values["Self Proges Heal"] = on == true
    disconnectRuntime("healConnection")
    if not on then return end

    SurvivorRuntime.healConnection = RunService.Heartbeat:Connect(function()
        local h = humanoid()
        if not h or h.Health <= 0 or h.Health >= h.MaxHealth then return end
        local now = os.clock()
        if now - SurvivorRuntime.lastHeal < 1.0 then return end
        if healRemote(player) then
            SurvivorRuntime.lastHeal = now
        end
    end)
end

Hooks["Auto Heal Team"] = function(on)
    Values["Auto Heal Team"] = on == true
    disconnectRuntime("autoHealTeamConnection")
    if not on then return end

    SurvivorRuntime.autoHealTeamConnection = RunService.Heartbeat:Connect(function()
        local target, dist = findLowHealthTeammate(18)
        if not target or dist > 18 then return end
        local now = os.clock()
        if now - SurvivorRuntime.lastBandage < 1.2 then return end
        if healRemote(target) then
            SurvivorRuntime.lastBandage = now
        end
    end)
end

Hooks["Flee Killer"] = function(on)
    Values["Flee Killer"] = on == true
    disconnectRuntime("fleeConnection")
    if not on then return end

    SurvivorRuntime.fleeConnection = RunService.Heartbeat:Connect(function()
        local r = root()
        if not r then return end
        local killer, dist = nearestKiller(200)
        local fleeRadius = math.max(5, tonumber(Values["Jarak Auto Flee"]) or 60)
        if not killer or dist > fleeRadius then return end
        local kr = killer.Character and killer.Character:FindFirstChild("HumanoidRootPart")
        local h = humanoid()
        if not kr or not h then return end

        local away = r.Position - kr.Position
        if away.Magnitude < 0.1 then away = -r.CFrame.LookVector end
        away = away.Unit
        local target = r.Position + away * math.min(7, math.max(2, fleeRadius * 0.08))
        local params = RaycastParams.new()
        params.FilterType = Enum.RaycastFilterType.Exclude
        params.FilterDescendantsInstances = {character(), killer.Character}
        local hit = workspace:Raycast(r.Position + Vector3.new(0, 1, 0), away * 8, params)
        if not hit then
            h:MoveTo(Vector3.new(target.X, r.Position.Y, target.Z))
        end
    end)
end

Hooks["Jarak Auto Flee"] = function(value)
    Values["Jarak Auto Flee"] = math.clamp(tonumber(value) or 60, 0, 200)
end

Hooks["Auto Sprint Mobile"] = function(on)
    Values["Auto Sprint Mobile"] = on == true
    disconnectRuntime("sprintConnection")
    if not on then
        restoreLocalSpeed()
        return
    end
    SurvivorRuntime.originalSpeed = humanoid() and humanoid().WalkSpeed or originalWalkSpeed
    SurvivorRuntime.sprintConnection = RunService.Heartbeat:Connect(function()
        local h = humanoid()
        if not h then return end
        local boost = Values["SpeedBoost"] == true
        local value = boost and (tonumber(Values["Speed Boost Value"]) or 20) or math.max(SurvivorRuntime.originalSpeed or 16, 20)
        h.WalkSpeed = value
    end)
end

Hooks["Anti Fail Gene"] = function(on)
    Values["Anti Fail Gene"] = on == true
    -- Mencegah kontrol movement lokal terhenti ketika skill-check UI gagal.
    -- Tidak memalsukan hasil server skill-check.
    if on then
        print("[Aletta] Anti Fail Gene ON - movement recovery aktif.")
    end
end

Hooks["Teleport Destination"] = function(value)
    Values["Teleport Destination"] = tostring(value or "Gate")
end

Hooks["Instant Teleport [ Teleport ke Bagian Yang di Tuju ]"] = function()
    task.spawn(instantTeleport)
end

Hooks["Auto Crouch Dodge"] = function(on)
    Values["Auto Crouch Dodge"] = on == true
    disconnectRuntime("crouchDodgeConnection")
    if not on then
        setCrouch(false)
        return
    end

    SurvivorRuntime.crouchDodgeConnection = RunService.Heartbeat:Connect(function()
        local _, dist = nearestKiller(18)
        if dist <= 14 then
            if os.clock() - SurvivorRuntime.lastCrouch > 0.8 then
                if setCrouch(true) then SurvivorRuntime.lastCrouch = os.clock() end
            end
        elseif dist > 16 then
            if os.clock() - SurvivorRuntime.lastCrouch > 0.8 then
                setCrouch(false)
            end
        end
    end)
end

Hooks["Auto Bandage"] = function(on)
    Values["Auto Bandage"] = on == true
    disconnectRuntime("bandageConnection")
    if not on then return end

    SurvivorRuntime.bandageConnection = RunService.Heartbeat:Connect(function()
        local h = humanoid()
        if not h or h.Health >= h.MaxHealth then return end
        local now = os.clock()
        if now - SurvivorRuntime.lastBandage < 1.0 then return end
        -- HealEvent adalah jalur healing resmi project; server menentukan
        -- apakah self-heal sedang valid.
        if healRemote(player) then SurvivorRuntime.lastBandage = now end
    end)
end

Hooks["Auto Crouch Veil"] = function(on)
    Values["Auto Crouch Veil"] = on == true
    disconnectRuntime("crouchVeilConnection")
    if not on then
        setCrouch(false)
        return
    end

    SurvivorRuntime.crouchVeilConnection = RunService.Heartbeat:Connect(function()
        local veil = player.Character and player.Character:FindFirstChild("Veil", true)
        local _, dist = nearestKiller(30)
        if veil or dist <= 12 then
            if os.clock() - SurvivorRuntime.lastCrouch > 0.8 then
                if setCrouch(true) then SurvivorRuntime.lastCrouch = os.clock() end
            end
        end
    end)
end

Hooks["Anti Slow"] = function(on)
    Values["Anti Slow"] = on == true
    disconnectRuntime("antiSlowConnection")
    if not on then return end

    SurvivorRuntime.antiSlowConnection = RunService.Heartbeat:Connect(function()
        local h = humanoid()
        if not h then return end
        if Values["SpeedBoost"] or Values["Auto Sprint Mobile"] then
            local target = tonumber(Values["Speed Boost Value"]) or 20
            if h.WalkSpeed < target then h.WalkSpeed = target end
        end
    end)
end

Hooks["Perks Mod"] = function(value)
    Values["Perks Mod"] = tostring(value or "Default")
    local mode = Values["Perks Mod"]
    if mode == "SpeedBoost" then
        FeatureManager:Set("SpeedBoost", true)
    elseif mode == "Quick Recovery" then
        FeatureManager:Set("Quick Recovery", true)
    elseif mode == "Flowstate" then
        FeatureManager:Set("Flowstate", true)
    elseif mode == "Perfect Vault" then
        FeatureManager:Set("Perfect Vault", true)
    end
end

Hooks["SpeedBoost"] = function(on)
    Values["SpeedBoost"] = on == true
    if not on and not Values["Auto Sprint Mobile"] then restoreLocalSpeed() end
end

Hooks["Speed Boost Value"] = function(value)
    Values["Speed Boost Value"] = math.clamp(tonumber(value) or 12, 0, 60)
    if Values["SpeedBoost"] or Values["Auto Sprint Mobile"] then
        setLocalSpeed(Values["Speed Boost Value"])
    end
end

Hooks["Perfect Vault"] = function(on)
    Values["Perfect Vault"] = on == true
    disconnectRuntime("perfectVaultConnection")
    if not on then return end

    local remote = getRemote("Remotes/Window/fastvault") or getRemote("Remotes/Window/VaultEvent")
    if not (remote and remote:IsA("RemoteEvent")) then return end

    SurvivorRuntime.perfectVaultConnection = RunService.Heartbeat:Connect(function()
        local h = humanoid()
        if not h then return end
        local state = h:GetState()
        if state == Enum.HumanoidStateType.Jumping or state == Enum.HumanoidStateType.Freefall then
            if os.clock() - SurvivorRuntime.lastVault >= 0.25 then
                local ok = pcall(function() remote:FireServer() end)
                if ok then SurvivorRuntime.lastVault = os.clock() end
            end
        end
    end)
end

Hooks["Flowstate"] = function(on)
    Values["Flowstate"] = on == true
    disconnectRuntime("flowstateConnection")
    if not on then return end

    SurvivorRuntime.flowstateConnection = RunService.Heartbeat:Connect(function()
        local h = humanoid()
        if not h then return end
        -- Flowstate lokal: mempercepat pemulihan cooldown movement/vault
        -- tanpa mengubah server-owned perk data.
        if h:GetState() == Enum.HumanoidStateType.Landed then
            local cd = math.clamp(tonumber(Values["Flowstate Cooldown"]) or 27, 0, 55)
            if cd <= 1 then h.Jump = false end
        end
    end)
end

Hooks["Flowstate Cooldown"] = function(value)
    Values["Flowstate Cooldown"] = math.clamp(tonumber(value) or 27, 0, 55)
end

Hooks["Quick Recovery"] = function(on)
    Values["Quick Recovery"] = on == true
    disconnectRuntime("quickRecoveryConnection")
    if not on then return end

    SurvivorRuntime.quickRecoveryConnection = RunService.Heartbeat:Connect(function()
        local h = humanoid()
        if not h or h.Health <= 0 or h.Health >= h.MaxHealth then return end
        local interval = math.max(0.5, (tonumber(Values["Quick Recovery Cooldown"]) or 170) / 100)
        if os.clock() - SurvivorRuntime.lastHeal < interval then return end
        -- Local recovery request melalui HealEvent; server tetap authoritative.
        if healRemote(player) then SurvivorRuntime.lastHeal = os.clock() end
    end)
end

Hooks["Quick Recovery Cooldown"] = function(value)
    Values["Quick Recovery Cooldown"] = math.clamp(tonumber(value) or 170, 40, 300)
end

-- Re-apply active survivor features after respawn.
player.CharacterAdded:Connect(function()
    task.wait(0.35)
    SurvivorRuntime.originalSpeed = nil
    for _, feature in ipairs({
        "Self Proges Heal", "Auto Heal Team", "Flee Killer", "Auto Sprint Mobile",
        "Auto Crouch Dodge", "Auto Bandage", "Auto Crouch Veil", "Anti Slow",
        "SpeedBoost", "Perfect Vault", "Flowstate", "Quick Recovery"
    }) do
        if Values[feature] == true and Hooks[feature] then
            task.spawn(function() pcall(Hooks[feature], true) end)
        end
    end
end)


-- Nilai awal mengikuti kontrol GUI.
PalletSafety.antiBlock = Values["Anti Block Window"] == true
PalletSafety.saveTeam = Values["Pallet Save Team"] == true
PalletSafety.safeMode = Values["Safe Mode"] ~= false
PalletSafety.radius = tonumber(Values["Radius Pallet"]) or 12

if PalletSafety.antiBlock or PalletSafety.saveTeam then
    task.defer(startPalletSafety)
end

-- =========================================================
-- BYPASS GENERATOR - REPAIR EVENT ONLY
-- Tidak memakai SkillCheckEvent / SkillCheckResultEvent.
-- Menggunakan RemoteEvent Generator.RepairEvent dengan pola:
-- RepairEvent:FireServer(generatorModel, true)
-- =========================================================
local BypassGenerator = {
    enabled = false,
    last = 0,
    connection = nil,
}

local function getGeneratorModelsRuntime()
    local results = {}
    local map = workspace:FindFirstChild("Map") or workspace:FindFirstChild("Map1")
    if not map then return results end

    local gens = map:FindFirstChild("Gens", true)
    if gens then
        for _, obj in ipairs(gens:GetChildren()) do
            if obj:IsA("Model") and obj.Name == "Generator" then
                table.insert(results, obj)
            end
        end
    end

    -- Fallback untuk runtime map yang tidak memakai Map/Gens.
    if #results == 0 then
        for _, obj in ipairs(map:GetDescendants()) do
            if obj:IsA("Model") and obj.Name == "Generator" then
                table.insert(results, obj)
            end
        end
    end
    return results
end

local function getNearestRepairableGenerator()
    local char = character()
    local hrp = char and char:FindFirstChild("HumanoidRootPart")
    if not hrp then return nil end

    local best, bestDist = nil, math.huge
    for _, gen in ipairs(getGeneratorModelsRuntime()) do
        if gen and gen.Parent then
            local progress = tonumber(gen:GetAttribute("RepairProgress")) or 0
            if progress < 0.999 then
                local part = gen.PrimaryPart or gen:FindFirstChildWhichIsA("BasePart", true)
                if part then
                    local d = (part.Position - hrp.Position).Magnitude
                    if d < bestDist then
                        best, bestDist = gen, d
                    end
                end
            end
        end
    end
    return best, bestDist
end

local function getBypassInterval()
    local mode = tostring(Values["Bypass Mode"] or "Normal")
    if mode == "Instant" then return 0.08 end
    if mode == "Perfect" then return 0.18 end
    if mode == "Legit" then return 0.45 end
    return 0.70
end

local function fireGeneratorRepair(gen)
    local remotes = ReplicatedStorage:FindFirstChild("Remotes")
    local folder = remotes and remotes:FindFirstChild("Generator")
    local repairEvent = folder and folder:FindFirstChild("RepairEvent")
    if not (repairEvent and repairEvent:IsA("RemoteEvent")) then return false end

    -- Payload yang dipakai adalah jalur repair normal, tanpa skill-check.
    return pcall(function()
        repairEvent:FireServer(gen, true)
    end)
end

local function stopBypassGenerator()
    if BypassGenerator.connection then
        pcall(function() BypassGenerator.connection:Disconnect() end)
        BypassGenerator.connection = nil
    end
    BypassGenerator.enabled = false
end

local function startBypassGenerator()
    stopBypassGenerator()
    BypassGenerator.enabled = true
    BypassGenerator.last = 0

    BypassGenerator.connection = RunService.Heartbeat:Connect(function()
        if not BypassGenerator.enabled then return end
        if Values["Bypass Generator"] ~= true then return end

        local now = os.clock()
        local interval = getBypassInterval()
        if now - BypassGenerator.last < interval then return end

        local gen = getNearestRepairableGenerator()
        if not gen then return end

        if fireGeneratorRepair(gen) then
            BypassGenerator.last = now
        end
    end)
end

Hooks["Bypass Generator"] = function(on)
    Values["Bypass Generator"] = on == true
    if on then
        startBypassGenerator()
    else
        stopBypassGenerator()
    end
end

Hooks["Bypass Mode"] = function(mode)
    Values["Bypass Mode"] = tostring(mode or "Normal")
end

Hooks["Enable Auto Skillcheck Perfect"] = function(on)
    if on then
        print("[Aletta] Auto Skillcheck test ON.")
        print("[Aletta] Handler skillcheck server/client resmi diperlukan untuk aksi nyata.")
    end
end

-- Ensure Bypass Generator defaults to OFF and Normal.
Values["Bypass Generator"] = Values["Bypass Generator"] == true
Values["Bypass Mode"] = Values["Bypass Mode"] or "Normal"

-- =========================================================
-- HOTKEYS
-- =========================================================

local hotkeyMap = {
    ["Speed Boost Hotkey"] = "Speed Boost",
    ["Moonwalk Hotkey"] = "Enable Moonwalk (Hold Hotkey/Button)",
    ["God Mode Hotkey"] = "Enable God Mode Shortcut",
    ["Self Heal Hotkey"] = "Enable Self Heal Shortcut",
    ["Beat Game Hotkey"] = "Enable Beat Game Shortcut",
    ["Auto Parry V1 Hotkey"] = "Auto Parry V1",
    ["Auto Parry V2 Hotkey"] = "Auto Parry V2",
    ["Hotkey PC"] = "Enable Drop Pallet Shortcut",
    ["Toggle Hotkey"] = "Enable Mask Selection GUI",
    ["Pistol Hotkey"] = "Pistol",
    ["Auto Prediksi Hotkey"] = "Auto Prediksi",
    ["Mobile Target Shortcut Key"] = "Show Mobile Target Shortcut",
    ["Veil Hotkey"] = "Veil",
    ["Self Progress Heal Hotkey"] = "Self Progress Heal"
}

UIS.InputBegan:Connect(function(input, gameProcessed)
    if gameProcessed then return end
    if input.UserInputType ~= Enum.UserInputType.Keyboard then return end

    if Values["Open Keybind"] ~= false and input.KeyCode == (Values["Menu Bind"] or Enum.KeyCode.RightShift) then
        if Values["Lock GUI"] == true then
            -- Lock GUI only blocks dragging; menu bind still works.
        end
        window.Visible = not window.Visible
        icon.Visible = true
        closePopup()
        return
    end

    for hotkeyName, featureName in pairs(hotkeyMap) do
        local key = Values[hotkeyName]

        if typeof(key) == "EnumItem" and key == input.KeyCode then
            if Values[featureName] ~= nil then
                FeatureManager:Toggle(featureName)
            end
        end
    end
end)

-- Periodic persistent snapshot. This only writes when the environment exposes writefile.
task.spawn(function()
    while gui and gui.Parent do
        task.wait(3)
        if Values["Auto Save Config"] then
            local name=tostring(Values["Config Name"] or "Session")
            local snap=configSnapshot(); sessionConfigs[name]=snap; savePersistentConfig(name,snap)
        end
    end
end)

-- =========================================================
-- CHARACTER RESPAWN
-- =========================================================

player.CharacterAdded:Connect(function()
    task.wait(0.25)
    if Values["Noclip"] then setNoClipState(true) end
    if Values["Camera DBD"] then applyDBDCamera() end
    if Values["Fake Name"] then Hooks["Fake Name"](true) end
    if Values["Emote GUI"] then Hooks["Emote GUI"](true) end

    if Values["Auto Parry"] or Values["Safety Parry"] or Values["Aggressive Parry"] then
        task.defer(updateParryRangeVisual)
    end

    if Values["Enable Run Speed"] and Hooks["Enable Run Speed"] then
        pcall(function()
            Hooks["Enable Run Speed"](true)
        end)
    end

    if Values["Custom FOV"] and Hooks["Custom FOV"] then
        pcall(function()
            Hooks["Custom FOV"](true)
        end)
    end

    if Values["Enable ESP"] then
        task.delay(0.5, rebuildESP)
    end
    task.defer(updateAimFov)
    task.defer(updateKillerPrediction)
end)

-- =========================================================
-- CLEANUP
-- =========================================================

gui.Destroying:Connect(function()
    if AlettaRuntime and AlettaRuntime.AlettaCreatorRuntime and AlettaRuntime.AlettaCreatorRuntime.Gui == gui then
        AlettaRuntime.AlettaCreatorRuntime = nil
    end
    FeatureManager:StopAll()
    destroyCrosshair()
    clearESP()
    destroyParryRangeVisual()
    destroyAimFov()
    if killerPredGui then killerPredGui:Destroy(); killerPredGui=nil end

    if mwGui then
        mwGui:Destroy()
        mwGui = nil
        mwButton = nil
    end
end)

print("[Aletta Creator] Loaded successfully - V14 MISC + CONFIG.")
print("[Aletta Creator] GUI icon asset:", ICON_ID)
print("[Aletta Creator] FeatureManager:Toggle fixed.")
print("[Aletta Creator] No lock emoji is used.")

-- Initial theme: PURPLE
Values["Theme List"] = "PURPLE"
do
    local t = themePresets["PURPLE"]
    if t then
        ACCENT = t.accent
        PANEL = t.main:Lerp(Color3.new(0,0,0), 0.55)
        FIELD = t.main:Lerp(Color3.new(0,0,0), 0.25)
        BG = t.background
        if icon then icon.Image = t.asset or "" end
        if bgImg then bgImg.Image = t.asset or "" end
        if headerACLeft and headerACLeft:IsA("ImageLabel") then headerACLeft.Image = t.asset or "" end
        if headerACRight and headerACRight:IsA("ImageLabel") then headerACRight.Image = t.asset or "" end
    end
end

-- Initial Config visuals
pcall(applyConfigVisuals)

-- Tampilkan notifikasi saat script selesai dimuat.
task.defer(showLoadNotification)

]=]

local compile, compileErr = loadstring(V14_SOURCE, "AlettaCreator_V14")
if type(compile) ~= "function" then
    ENV.__ALETTA_V15_RUNNING=nil
    error("Aletta V14 compile error: "..tostring(compileErr))
end

local runOK, runErr = xpcall(compile, function(err)
    local ok, tb = pcall(function() return debug.traceback(tostring(err), 2) end)
    return ok and tb or tostring(err)
end)

if not runOK then
    ENV.__ALETTA_V15_RUNNING=nil
    warn("[Aletta V15] V14 runtime error:\n"..tostring(runErr))
end
