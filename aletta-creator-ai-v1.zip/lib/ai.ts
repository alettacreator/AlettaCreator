import { DEMO_REPLY, SYSTEM_PROMPT } from "./prompts";

type AIMessage = { role: "system" | "user" | "assistant"; content: string };

export async function askAI(messages: AIMessage[]) {
  const apiKey = process.env.AI_API_KEY;
  const url = process.env.AI_API_URL || "https://api.openai.com/v1/chat/completions";
  const model = process.env.AI_MODEL || "gpt-4o-mini";

  if (!apiKey) {
    return {
      mode: "demo" as const,
      content: DEMO_REPLY
    };
  }

  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`
    },
    body: JSON.stringify({
      model,
      messages: [{ role: "system", content: SYSTEM_PROMPT }, ...messages],
      temperature: 0.2
    })
  });

  if (!response.ok) {
    const detail = await response.text();
    throw new Error(`AI provider error ${response.status}: ${detail.slice(0, 500)}`);
  }

  const data = await response.json();
  const content = data?.choices?.[0]?.message?.content;

  if (!content) throw new Error("AI provider returned no message.");
  return { mode: "live" as const, content };
}
