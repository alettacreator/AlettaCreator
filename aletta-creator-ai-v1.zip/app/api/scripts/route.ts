import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(){
  const scripts=await db.script.findMany({orderBy:{updatedAt:"desc"}});
  return NextResponse.json(scripts);
}

export async function POST(req:Request){
  try{
    const {name,category="General",code=""}=await req.json();
    if(!name?.trim()) return NextResponse.json({error:"name required"},{status:400});
    const script=await db.script.create({data:{name,category,code}});
    return NextResponse.json(script,{status:201});
  }catch(e){return NextResponse.json({error:e instanceof Error?e.message:"Save failed"},{status:500})}
}
