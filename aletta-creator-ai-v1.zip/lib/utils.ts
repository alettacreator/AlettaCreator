export function cn(...classes: Array<string | false | null | undefined>) {
  return classes.filter(Boolean).join(" ");
}

export function clip(text: string, max = 500) {
  return text.length > max ? `${text.slice(0, max)}…` : text;
}
