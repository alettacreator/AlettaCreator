import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(){
  const projects=await db.project.findMany({orderBy:{updatedAt:"desc"},include:{_count:{select:{scripts:true}}}});
  return NextResponse.json(projects);
}

export async function POST(req:Request){
  try{
    const {name,description=""}=await req.json();
    if(!name?.trim()) return NextResponse.json({error:"name required"},{status:400});
    const project=await db.project.create({data:{name,description}});
    return NextResponse.json(project,{status:201});
  }catch(e){return NextResponse.json({error:e instanceof Error?e.message:"Create failed"},{status:500})}
}
