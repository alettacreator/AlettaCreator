"use client";

import { useState } from "react";
import { CodeEditor } from "@/components/editor/CodeEditor";
import { Button } from "@/components/ui/Button";

export default function Fixer() {
  const [code, setCode] = useState("");
  const [error, setError] = useState("");
  const [result, setResult] = useState("");
  const [loading, setLoading] = useState(false);

  async function fix() {
    setLoading(true);
    try {
      const res = await fetch("/api/fix", { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({code,error}) });
      const data = await res.json();
      setResult(data.analysis || data.error || "");
      if (data.code) setCode(data.code);
    } finally { setLoading(false); }
  }

  return <div className="p-5 md:p-8"><div className="mx-auto max-w-6xl">
    <h1 className="text-3xl font-black">Code Fixer</h1><p className="mb-6 mt-2 text-[#aaa3b5]">Masukkan Luau dan pesan error untuk dianalisis.</p>
    <div className="grid gap-5 lg:grid-cols-2">
      <div><CodeEditor value={code} onChange={setCode}/><textarea value={error} onChange={e=>setError(e.target.value)} placeholder="Error message (optional)" className="mt-4 min-h-28 w-full rounded-2xl border border-white/10 bg-[#14101e] p-4 text-sm outline-none focus:border-[#9650ff]"/><Button onClick={fix} disabled={loading} className="mt-4">{loading?"Analyzing…":"🔧 Fix Code"}</Button></div>
      <div className="rounded-2xl border border-white/10 bg-[#14101e] p-5"><h2 className="font-bold">Analysis</h2><pre className="mt-4 whitespace-pre-wrap text-sm leading-6 text-[#d8d0df]">{result || "Hasil analisis akan muncul di sini."}</pre></div>
    </div>
  </div></div>;
}
