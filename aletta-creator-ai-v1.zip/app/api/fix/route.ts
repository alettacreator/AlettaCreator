import { NextResponse } from "next/server";
import { askAI } from "@/lib/ai";

export async function POST(req:Request){
  try{
    const {code="",error=""}=await req.json();
    if(!code.trim()) return NextResponse.json({error:"Code is empty"},{status:400});
    const prompt=`Analyze this Roblox Luau code and error. Explain the likely problem and propose a corrected version. Error: ${error || "(not provided)"}\n\nCODE:\n${code}`;
    const result=await askAI([{role:"user",content:prompt}]);
    return NextResponse.json({analysis:result.content, mode:result.mode});
  }catch(e){return NextResponse.json({error:e instanceof Error?e.message:"Fix failed"},{status:500})}
}
