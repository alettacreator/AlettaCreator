"use client";

import { useEffect, useState } from "react";
import { Button } from "@/components/ui/Button";

type Script = { id:string; name:string; category:string; code:string; version:number };

export default function Library() {
  const [scripts,setScripts] = useState<Script[]>([]);
  const [name,setName] = useState("");
  const [code,setCode] = useState("-- Paste Luau here");

  async function load(){ const r=await fetch("/api/scripts"); setScripts(await r.json()); }
  useEffect(()=>{load()},[]);

  async function save(){
    if(!name.trim()) return;
    await fetch("/api/scripts",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name,category:"General",code})});
    setName(""); await load();
  }

  return <div className="p-5 md:p-8"><div className="mx-auto max-w-6xl">
    <h1 className="text-3xl font-black">Script Library</h1><p className="mb-6 mt-2 text-[#aaa3b5]">Simpan script Aletta Creator secara lokal di database.</p>
    <div className="mb-6 grid gap-3 md:grid-cols-[1fr_1fr_auto]"><input value={name} onChange={e=>setName(e.target.value)} placeholder="Script name" className="rounded-xl bg-[#261e36] p-3 outline-none"/><input value={code} onChange={e=>setCode(e.target.value)} placeholder="Code" className="rounded-xl bg-[#261e36] p-3 outline-none"/><Button onClick={save}>Save</Button></div>
    <div className="space-y-3">{scripts.map(s=><div key={s.id} className="rounded-2xl border border-white/10 bg-[#14101e] p-4"><div className="flex justify-between"><b>{s.name}</b><span className="text-xs text-[#aaa3b5]">{s.category} · v{s.version}</span></div><pre className="mt-3 max-h-36 overflow-auto whitespace-pre-wrap rounded-xl bg-[#0b0810] p-3 text-xs text-[#cfc1df]">{s.code}</pre></div>)}{!scripts.length&&<div className="rounded-2xl border border-dashed border-white/10 p-10 text-center text-[#aaa3b5]">Belum ada script.</div>}</div>
  </div></div>;
}
