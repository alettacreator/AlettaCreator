import { ChatWindow } from "@/components/ai/ChatWindow";

export default function AIPage() {
  return <div className="p-5 md:p-8"><div className="mx-auto max-w-5xl"><h1 className="mb-2 text-3xl font-black">Aletta AI</h1><p className="mb-6 text-[#aaa3b5]">Chat dengan AI untuk membantu pekerjaan Roblox/Luau.</p><ChatWindow /></div></div>;
}
