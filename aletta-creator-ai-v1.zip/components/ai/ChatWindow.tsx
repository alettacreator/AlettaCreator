"use client";

import { useState } from "react";
import { Send, Sparkles } from "lucide-react";

type Msg = { role: "user" | "assistant"; content: string };

export function ChatWindow() {
  const [messages, setMessages] = useState<Msg[]>([
    { role: "assistant", content: "Halo! Saya Aletta AI. Jelaskan fitur Roblox yang ingin kamu bangun." }
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);

  async function send() {
    const text = input.trim();
    if (!text || loading) return;
    const next = [...messages, { role: "user" as const, content: text }];
    setMessages(next);
    setInput("");
    setLoading(true);

    try {
      const res = await fetch("/api/ai", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: next })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Request failed");
      setMessages((m) => [...m, { role: "assistant", content: data.content }]);
    } catch (e) {
      setMessages((m) => [...m, { role: "assistant", content: `Error: ${e instanceof Error ? e.message : "Unknown error"}` }]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex h-[calc(100vh-170px)] min-h-[560px] flex-col rounded-2xl border border-white/10 bg-[#14101e]">
      <div className="flex items-center gap-3 border-b border-white/10 p-4">
        <div className="grid h-10 w-10 place-items-center rounded-xl bg-[#9650ff]/20"><Sparkles size={19} /></div>
        <div><div className="font-semibold">Aletta AI</div><div className="text-xs text-[#aaa3b5]">Roblox development assistant</div></div>
      </div>

      <div className="flex-1 space-y-4 overflow-y-auto p-5">
        {messages.map((m, i) => (
          <div key={i} className={`max-w-[88%] whitespace-pre-wrap rounded-2xl p-4 text-sm leading-6 ${m.role === "user" ? "ml-auto bg-[#9650ff] text-white" : "bg-[#21192e] text-[#e8e1ef]"}`}>
            {m.content}
          </div>
        ))}
        {loading && <div className="w-fit rounded-2xl bg-[#21192e] px-4 py-3 text-sm text-[#aaa3b5]">Aletta AI sedang berpikir…</div>}
      </div>

      <div className="border-t border-white/10 p-4">
        <div className="flex gap-2">
          <input value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => e.key === "Enter" && send()}
            placeholder="Contoh: buatkan sistem toggle GUI Roblox..."
            className="min-w-0 flex-1 rounded-xl border border-white/10 bg-[#261e36] px-4 py-3 text-sm outline-none focus:border-[#9650ff]" />
          <button onClick={send} disabled={loading} className="grid w-12 place-items-center rounded-xl bg-[#9650ff] disabled:opacity-50"><Send size={18}/></button>
        </div>
      </div>
    </div>
  );
}
