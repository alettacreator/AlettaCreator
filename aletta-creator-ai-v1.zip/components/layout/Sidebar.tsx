"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Bot, Code2, FolderOpen, Home, Library, Settings, Wrench, Sparkles } from "lucide-react";

const items = [
  ["/dashboard", Home, "Dashboard"],
  ["/ai", Bot, "AI Chat"],
  ["/code-generator", Sparkles, "Code Generator"],
  ["/code-fixer", Wrench, "Code Fixer"],
  ["/script-library", Library, "Script Library"],
  ["/project", FolderOpen, "Projects"],
  ["/settings", Settings, "Settings"]
] as const;

export function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 border-r border-white/10 bg-[#110d1a] p-4 md:block">
      <div className="mb-8 flex items-center gap-3 px-2">
        <div className="grid h-11 w-11 place-items-center rounded-2xl bg-gradient-to-br from-[#9650ff] to-[#c864ff] shadow-lg shadow-purple-900/30">
          <span className="text-xl font-black">A</span>
        </div>
        <div>
          <div className="font-black tracking-wide">ALETTA</div>
          <div className="text-xs text-[#a9a1b5]">CREATOR AI</div>
        </div>
      </div>

      <nav className="space-y-1">
        {items.map(([href, Icon, label]) => {
          const active = pathname === href;
          return (
            <Link key={href} href={href}
              className={`flex items-center gap-3 rounded-xl px-3 py-3 text-sm transition ${
                active ? "bg-[#9650ff]/20 text-white ring-1 ring-[#9650ff]/30" : "text-[#aaa3b5] hover:bg-white/5 hover:text-white"
              }`}>
              <Icon size={18} />
              {label}
            </Link>
          );
        })}
      </nav>

      <div className="absolute bottom-5 left-4 right-4 rounded-2xl border border-[#9650ff]/20 bg-[#9650ff]/10 p-4">
        <div className="flex items-center gap-2 text-sm font-semibold">
          <span className="h-2 w-2 rounded-full bg-emerald-400" />
          Aletta AI v1
        </div>
        <p className="mt-1 text-xs text-[#aaa3b5]">Developer workspace</p>
      </div>
    </aside>
  );
}
