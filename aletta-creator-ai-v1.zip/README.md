# Aletta Creator AI v1

Website AI developer workspace khusus Aletta Creator.

## Fitur
- Dashboard
- Aletta AI Chat
- Luau Code Generator
- Code Fixer / Analyzer
- Script Library
- Project Manager
- SQLite + Prisma
- Demo mode tanpa API key
- OpenAI-compatible AI provider melalui server-side API route

## Persyaratan
- Node.js 20+
- npm

## Menjalankan

```bash
npm install
cp .env.example .env.local
npx prisma generate
npx prisma db push
npm run dev
```

Buka:
http://localhost:3000

## Mengaktifkan AI

Edit `.env.local`:

```env
AI_API_KEY=your_api_key
AI_API_URL=https://api.openai.com/v1/chat/completions
AI_MODEL=gpt-4o-mini
DATABASE_URL="file:./dev.db"
```

Restart:

```bash
npm run dev
```

Jika `AI_API_KEY` kosong, website tetap berjalan menggunakan Demo Mode.

## Build production

```bash
npm run build
npm start
```

## Catatan
v1 sengaja tidak menyertakan sistem login/pembayaran. Itu dapat ditambahkan pada v2 setelah fondasi aplikasi stabil.
