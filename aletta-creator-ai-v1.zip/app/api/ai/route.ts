import { NextResponse } from "next/server";
import { askAI } from "@/lib/ai";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    if (!Array.isArray(body.messages)) return NextResponse.json({error:"messages must be an array"}, {status:400});
    const messages = body.messages
      .filter((m:any)=>m && (m.role==="user" || m.role==="assistant") && typeof m.content==="string")
      .slice(-20);
    const result = await askAI(messages);
    return NextResponse.json(result);
  } catch (e) {
    return NextResponse.json({error:e instanceof Error?e.message:"AI request failed"}, {status:500});
  }
}
