"use client";

export function CodeEditor({
  value,
  onChange,
  placeholder = "-- Paste Luau code here..."
}: {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
}) {
  return (
    <textarea
      value={value}
      onChange={(e) => onChange(e.target.value)}
      spellCheck={false}
      placeholder={placeholder}
      className="min-h-[420px] w-full resize-y rounded-2xl border border-white/10 bg-[#0b0810] p-5 font-mono text-sm leading-6 text-[#e7d9ff] outline-none focus:border-[#9650ff]/60"
    />
  );
}
