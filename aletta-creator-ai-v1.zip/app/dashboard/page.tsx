import Link from "next/link";
import { Bot, Code2, Wrench, Library, FolderOpen } from "lucide-react";
import { Card } from "@/components/ui/Card";

const cards = [
  ["/ai", Bot, "AI Chat", "Tanya Aletta AI tentang Roblox/Luau."],
  ["/code-generator", Code2, "Code Generator", "Buat template fitur dan script."],
  ["/code-fixer", Wrench, "Code Fixer", "Analisis dan perbaiki kode Luau."],
  ["/script-library", Library, "Script Library", "Kelola script yang tersimpan."],
  ["/project", FolderOpen, "Projects", "Organisasi project Aletta Creator."]
] as const;

export default function Dashboard() {
  return (
    <div className="p-5 md:p-8">
      <div className="mx-auto max-w-6xl">
        <div className="mb-8">
          <div className="mb-2 inline-flex items-center gap-2 rounded-full border border-[#9650ff]/30 bg-[#9650ff]/10 px-3 py-1 text-xs text-[#d8c3ff]">✦ Aletta Creator AI v1</div>
          <h1 className="text-3xl font-black md:text-4xl">Build something amazing.</h1>
          <p className="mt-2 text-[#aaa3b5]">Workspace AI untuk pengembangan Roblox dan Aletta Creator.</p>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {cards.map(([href, Icon, title, desc]) => (
            <Link href={href} key={href}>
              <Card className="h-full p-5 transition hover:-translate-y-0.5 hover:border-[#9650ff]/40">
                <div className="mb-5 grid h-11 w-11 place-items-center rounded-xl bg-[#9650ff]/15 text-[#c98dff]"><Icon size={21}/></div>
                <h2 className="font-bold">{title}</h2>
                <p className="mt-2 text-sm text-[#aaa3b5]">{desc}</p>
              </Card>
            </Link>
          ))}
        </div>

        <Card className="mt-6 p-6">
          <h2 className="font-bold">Quick Start</h2>
          <p className="mt-2 text-sm text-[#aaa3b5]">Mulai dari AI Chat untuk membuat ide menjadi struktur kode, lalu simpan hasilnya ke Script Library.</p>
          <Link href="/ai" className="mt-5 inline-flex rounded-xl bg-[#9650ff] px-4 py-2.5 text-sm font-semibold">Open Aletta AI</Link>
        </Card>
      </div>
    </div>
  );
}
