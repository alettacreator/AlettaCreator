export default function Settings() {
  return <div className="p-5 md:p-8"><div className="mx-auto max-w-4xl">
    <h1 className="text-3xl font-black">Settings</h1>
    <div className="mt-6 rounded-2xl border border-white/10 bg-[#14101e] p-6">
      <h2 className="font-bold">Aletta Creator AI</h2>
      <p className="mt-2 text-sm text-[#aaa3b5]">v1.0.0 · Purple developer workspace</p>
      <div className="mt-6 rounded-xl bg-[#21192e] p-4 text-sm leading-6 text-[#cfc5d8]">
        AI provider dikonfigurasi melalui <code>.env.local</code>. Jangan pernah menaruh API key di kode frontend.
      </div>
    </div>
  </div></div>;
}
