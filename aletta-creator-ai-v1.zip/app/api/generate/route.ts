import { NextResponse } from "next/server";
import { askAI } from "@/lib/ai";

const fallback = (name:string, category:string, description:string) => `-- Aletta Creator
-- Feature: ${name}
-- Category: ${category}
-- ${description || "Generated feature template"}

local ${name.replace(/[^A-Za-z0-9_]/g,"_")} = {}
local Feature = ${name.replace(/[^A-Za-z0-9_]/g,"_")}

Feature.Enabled = false

function Feature:Enable()
    self.Enabled = true
end

function Feature:Disable()
    self.Enabled = false
end

return Feature
`;

export async function POST(req:Request){
  try{
    const {name="AlettaFeature",category="General",description=""}=await req.json();
    const prompt=`Generate a Roblox Luau module template. Name: ${name}. Category: ${category}. Description: ${description}. Return code only.`;
    const result=await askAI([{role:"user",content:prompt}]);
    return NextResponse.json({code:result.mode==="live"?result.content:fallback(name,category,description), mode:result.mode});
  }catch(e){return NextResponse.json({error:e instanceof Error?e.message:"Generation failed"},{status:500})}
}
